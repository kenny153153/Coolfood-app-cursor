
import React, { useState, useEffect, useRef, useMemo, useCallback, Suspense, lazy } from 'react';
import { 
  ShoppingBag, Package, Truck, CreditCard, Settings, CheckCircle,
  AlertTriangle, X, ChevronRight, LogOut, Edit, Plus, Minus,
  Search, MessageCircle, Clock, ChevronLeft, BookOpen,
  Tag, Sparkles, User, Bell, Trash2, Lock, Cpu, Database, Wifi, 
  RefreshCw, BarChart3, Users, ClipboardList, ArrowUpRight, DollarSign,
  MoreHorizontal, MapPin, ShieldCheck, Key, Image as ImageIcon,
  Check, Filter, List, Video, FileText, ChevronUp, ChevronDown, GripVertical,
  Printer, ExternalLink, Calendar, Hash, UserCheck, CreditCard as CardIcon,
  Award, Smartphone, Mail, Save, PlusCircle, Download, Upload, Zap,
  Layers, Percent, Globe, Crosshair, Scissors, Phone, Square, CheckSquare, Coins,
  UtensilsCrossed, Play, CookingPot, Pencil, Star, Ticket, Gift, Store
} from 'lucide-react';
import { HK_DISTRICTS } from './constants';
import { SF_COLD_PICKUP_DISTRICTS, SF_COLD_DISTRICT_NAMES, getPointsByDistrict, findPointByCode, formatLockerAddress, SfColdPickupPoint } from './sfColdPickupPoints';
import { Product, CartItem, User as UserType, Order, OrderStatus, SupabaseOrderRow, SupabaseMemberRow, OrderLineItem, SiteConfig, Recipe, Category, UserAddress, GlobalPricingRules, WholesalePricingRules, WholesalePriceTier, DeliveryRules, DeliveryTier, BulkDiscount, SlideshowItem, ShippingConfig, PricingTier, CostItem, StandaloneRecipe, RecipeIngredientRaw, RecipeStep, SupabaseRecipeRow, RecipeCategory, Ingredient, SaleChannel, MemberType, IngredientCategory, AdminPermissions, AdminAccount, AdminRole, Workspace, AdminModuleId, ProcessingType, ProductType, ProductGroup, ProductClassification, PricingMode, StaffRoleTemplate, ModulePermission, CrudOp, Coupon, CouponType, MemberCoupon, PointsConfig, WelcomeCouponsConfig } from './types';
import { WorkspaceProvider } from './WorkspaceContext';
import { useSite } from './SiteContext';
import GHFoodsStorefront from './GHFoodsStorefront';
import AdminSidebar from './AdminSidebar';
import AdminTopbar from './AdminTopbar';
import SectionErrorBoundary from './SectionErrorBoundary';

const WholesalePricingPanel = lazy(() => import('./WholesalePricingPanel'));
// WholesaleClientsPanel removed — merged into members
const SalesRepPanel = lazy(() => import('./SalesRepPanel'));
const DispatchPanel = lazy(() => import('./DispatchPanel'));
const NewOrderPanel = lazy(() => import('./NewOrderPanel'));
const AccountingPanel = lazy(() => import('./AccountingPanel'));
const WarehousePanel = lazy(() => import('./WarehousePanel'));
const ProductionPanel = lazy(() => import('./ProductionPanel'));
const SalesAnalyticsPanel = lazy(() => import('./SalesAnalyticsPanel'));
const QuotationPanel = lazy(() => import('./QuotationPanel'));
const LegacyFeaturesPanel = lazy(() => import('./LegacyFeaturesPanel'));
import { buildPickingSlipHtml, buildAggregatePickingHtml, buildInvoiceHtml, getBusinessLabel } from './printUtils';
import type { PickingOrderData, AggregatePickingData, InvoiceOrderData } from './printUtils';
import { useI18n, Language } from './i18n';
import { supabase } from './supabaseClient';
import {
  mapProductRowToProduct,
  mapCategoryRowToCategory,
  mapMemberRowToUser,
  mapOrderRowToOrder,
  mapProductToRow,
  mapCategoryToRow,
  mapUserToMemberRow,
  mapSlideshowRowToItem,
  mapSlideshowItemToRow,
  normalizeOrderStatus,
  mapRecipeRowToRecipe,
  mapRecipeToRow,
  mapRecipeCategoryRow,
  mapIngredientRowToIngredient,
  mapIngredientToRow,
  mapIngredientCategoryRow,
  computeProductCost,
  computePackCost,
  mapProcessingTypeRow,
  mapProductGroupRow,
  mapProductGroupToRow,
  mapCouponRowToCoupon,
  mapCouponToRow,
  mapMemberCouponRow,
} from './supabaseMappers';
import { hashPassword } from './authHelpers';
import { uploadImage, uploadImages, deleteImage, isMediaUrl } from './imageUpload';

const LazySetupPage = lazy(() => import('./SetupPage'));
const AdminLanguagePanel = lazy(() => import('./AdminLanguagePanel'));

const AI_ENGINE_STATUS = 'Vertex_Paid_Live';

/** Format address for display using new required fields. */
const formatAddressLine = (addr: UserAddress): string => {
  const parts = [
    addr.district,
    addr.detail,
    addr.floor ? (addr.floor + '樓') : '',
    addr.flat ? (addr.flat + '室') : '',
  ].filter(Boolean);
  return parts.join(' ');
};

/** True if address meets SF requirement (contact + phone + district + address + floor/flat). */
const isAddressCompleteForOrder = (a: UserAddress): boolean => {
  if (!a.contactName?.trim() || !a.phone?.trim()) return false;
  if (!a.district?.trim()) return false;
  if (!a.detail?.trim()) return false;
  if (!a.floor?.trim() || !a.flat?.trim()) return false;
  return true;
};

/** Empty address with all detailed fields for forms. */
const emptyAddress = (): UserAddress => ({
  id: 'a-' + Date.now(),
  detail: '',
  district: '',
  floor: '',
  flat: '',
  contactName: '',
  phone: '',
  altContactName: '',
  altPhone: '',
  isDefault: false
});

function isMobileDevice(): boolean {
  if (typeof navigator === 'undefined' || typeof window === 'undefined') return false;
  return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)
    || ('ontouchstart' in window && window.innerWidth <= 768);
}

/** Detect app language for Google API calls. Returns 'zh-HK' or 'en'. */
function getAppLanguage(): 'zh-HK' | 'en' {
  if (typeof document !== 'undefined' && document.documentElement?.lang) {
    const lang = document.documentElement.lang.toLowerCase();
    if (lang.startsWith('zh')) return 'zh-HK';
    if (lang.startsWith('en')) return 'en';
  }
  if (typeof navigator !== 'undefined' && navigator.language) {
    const lang = navigator.language.toLowerCase();
    if (lang.startsWith('zh')) return 'zh-HK';
  }
  return 'en';
}

/** Smart parse: building (premise/point_of_interest), street (route+number), district (area). */
function parseAddressComponents(components: { long_name: string; short_name: string; types: string[] }[]): { district: string; street: string; building: string } {
  const get = (types: string[]) => {
    const c = components.find(x => types.some(t => x.types.includes(t)));
    return c?.long_name?.trim() ?? '';
  };
  const building = get(['premise', 'point_of_interest']) || get(['subpremise', 'establishment']);
  const route = get(['route']);
  const streetNumber = get(['street_number']);
  const street = [streetNumber, route].filter(Boolean).join(' ') || route || streetNumber;
  const district = get(['sublocality', 'sublocality_level_1']) || get(['locality', 'administrative_area_level_2', 'administrative_area_level_1']) || get(['neighborhood']);
  return { district, street, building };
}

/** From reverse-geocode results: street/district from first result; building from ANY result (Google often puts building name in a later result). */
function parseReverseGeocodeResults(
  results: { address_components?: { long_name: string; short_name: string; types: string[] }[]; formatted_address?: string }[]
): { district: string; street: string; building: string } {
  const first = results[0];
  const comps = first?.address_components;
  const formatted = first?.formatted_address ?? '';
  const parsedFirst = comps?.length ? parseAddressComponents(comps) : { district: '', street: '', building: '' };
  let { district, street, building } = parsedFirst;

  // Scan ALL results for richer data (Google spreads info across multiple results)
  for (let i = 1; i < Math.min(results.length, 6); i++) {
    const c = results[i]?.address_components;
    if (!c?.length) continue;
    const parsed = parseAddressComponents(c);
    if (!building && parsed.building) building = parsed.building;
    if (!street && parsed.street) street = parsed.street;
    if (!district && parsed.district) district = parsed.district;
    if (building && street && district) break;
  }

  // Fallback: parse formatted_address string (format: "building, street, district, city, country")
  if ((!district || !street || !building) && formatted) {
    const parts = formatted.split(/[,，]/).map((p: string) => p.trim()).filter(Boolean);
    // HK format is typically: "Building, Street Number, District, Hong Kong"
    if (!building && parts.length >= 3) {
      const candidate = parts[0];
      const looksLikeBuilding = candidate.length > 0 && candidate.length <= 80 && !/^\d+\s*[-–]?\s*$/.test(candidate);
      if (looksLikeBuilding) building = candidate;
    }
    if (!street && parts.length >= 2) {
      street = parts.length >= 3 ? parts[1] : parts[0];
    }
    if (!district) {
      // District is usually the 3rd-to-last segment (before city and country)
      const districtIdx = Math.max(0, parts.length - 3);
      if (parts[districtIdx] && parts[districtIdx] !== building && parts[districtIdx] !== street) {
        district = parts[districtIdx];
      }
    }
  }

  return { district, street, building };
}

/** Legacy alias for parseAddressComponents. */
function parseGeocodeResult(components: { long_name: string; short_name: string; types: string[] }[]): { district: string; street: string; building: string } {
  return parseAddressComponents(components);
}

/** Load Google Maps JS API with language and Places; idempotent. */
function loadGoogleMapsScript(apiKey: string, language: 'zh-HK' | 'en' = 'en'): Promise<void> {
  const win = typeof window !== 'undefined' ? (window as unknown as { google?: { maps?: unknown } }) : null;
  if (win?.google?.maps) return Promise.resolve();
  return new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&libraries=places&language=${language}`;
    script.async = true;
    script.defer = true;
    script.onload = () => resolve();
    script.onerror = () => reject(new Error('Failed to load Google Maps script'));
    document.head.appendChild(script);
  });
}

// --- Shared Components ---

const Toast: React.FC<{ message: string; type: 'success' | 'error'; onClose: () => void }> = ({ message, type, onClose }) => {
  useEffect(() => {
    const timer = setTimeout(onClose, 2500);
    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <div className={`fixed top-[env(safe-area-inset-top,12px)] left-1/2 -translate-x-1/2 mt-3 z-[9000] animate-slide-up px-5 py-2.5 rounded-full shadow-2xl flex items-center gap-2 text-white text-sm font-medium max-w-[90vw] ${type === 'success' ? 'bg-slate-900' : 'bg-rose-600'}`}>
      {type === 'success' ? <CheckCircle size={16} /> : <AlertTriangle size={16} />}
      <span className="truncate">{message}</span>
    </div>
  );
};

import { roundPrice, getEffectiveUnitPrice, getWholesaleUnitPrice } from './pricingEngine';
import { roundMoney, formatMoney } from './money';

const getOrderStatusLabel = (status: OrderStatus | string, t?: { orderStatus: Record<string, string> }) => {
  if (t) {
    const key = String(status) as keyof typeof t.orderStatus;
    if (t.orderStatus[key]) return t.orderStatus[key];
  }
  const labels: Record<string, string> = {
    [OrderStatus.PENDING_PAYMENT]: '待付款',
    [OrderStatus.PAYMENT_FAILED]: '付款失敗',
    [OrderStatus.CANCELLED]: '已取消',
    [OrderStatus.PAID]: '已付款',
    [OrderStatus.PREPARING]: '備貨中',
    [OrderStatus.SHIPPING]: '發貨中',
    [OrderStatus.SHIPPED]: '已發貨',
    [OrderStatus.DELIVERED]: '已到達',
    [OrderStatus.REFUNDED]: '退款',
    [OrderStatus.PARTIALLY_REFUNDED]: '部份退款',
  };
  return labels[status] ?? String(status);
};

const StatusBadge: React.FC<{ status: OrderStatus; t?: { orderStatus: Record<string, string> } }> = ({ status, t }) => {
  const configs: Record<string, { label: string; color: string }> = {
    [OrderStatus.PENDING_PAYMENT]: { label: getOrderStatusLabel(OrderStatus.PENDING_PAYMENT, t), color: 'bg-slate-50 text-slate-600 border-slate-100' },
    [OrderStatus.PAYMENT_FAILED]: { label: getOrderStatusLabel(OrderStatus.PAYMENT_FAILED, t), color: 'bg-rose-50 text-rose-700 border-rose-100' },
    [OrderStatus.CANCELLED]: { label: getOrderStatusLabel(OrderStatus.CANCELLED, t), color: 'bg-slate-100 text-slate-500 border-slate-200' },
    [OrderStatus.PAID]: { label: getOrderStatusLabel(OrderStatus.PAID, t), color: 'bg-green-50 text-green-700 border-green-100' },
    [OrderStatus.PREPARING]: { label: getOrderStatusLabel(OrderStatus.PREPARING, t), color: 'bg-blue-50 text-blue-700 border-blue-100' },
    [OrderStatus.SHIPPING]: { label: getOrderStatusLabel(OrderStatus.SHIPPING, t), color: 'bg-amber-50 text-amber-700 border-amber-100' },
    [OrderStatus.SHIPPED]: { label: getOrderStatusLabel(OrderStatus.SHIPPED, t), color: 'bg-indigo-50 text-indigo-700 border-indigo-100' },
    [OrderStatus.DELIVERED]: { label: getOrderStatusLabel(OrderStatus.DELIVERED, t), color: 'bg-emerald-50 text-emerald-700 border-emerald-100' },
    [OrderStatus.REFUNDED]: { label: getOrderStatusLabel(OrderStatus.REFUNDED, t), color: 'bg-orange-50 text-orange-700 border-orange-100' },
    [OrderStatus.PARTIALLY_REFUNDED]: { label: getOrderStatusLabel(OrderStatus.PARTIALLY_REFUNDED, t), color: 'bg-yellow-50 text-yellow-700 border-yellow-100' },
  };
  const config = configs[status] || { label: String(status), color: 'bg-slate-50 text-slate-600 border-slate-100' };
  return (
    <span className={`px-2.5 py-1 rounded-lg text-[10px] font-black uppercase border tracking-wider ${config.color}`}>
      {config.label}
    </span>
  );
};

const ORDER_TIMELINE = [
  OrderStatus.PAID,
  OrderStatus.PREPARING,
  OrderStatus.SHIPPING,
  OrderStatus.SHIPPED,
  OrderStatus.DELIVERED,
];

const getTimelineIndex = (status: OrderStatus | string) => {
  const idx = ORDER_TIMELINE.indexOf(status as OrderStatus);
  return idx === -1 ? -1 : idx;
};

const TierBadge: React.FC<{ tier: string }> = ({ tier }) => {
  const configs: Record<string, string> = {
    'Bronze': 'bg-orange-50 text-orange-700 border-orange-100',
    'Silver': 'bg-slate-100 text-slate-700 border-slate-200',
    'Gold': 'bg-amber-50 text-amber-700 border-amber-200',
    'VIP': 'bg-purple-50 text-purple-700 border-purple-200'
  };
  return (
    <span className={`px-2 py-0.5 rounded-md text-[9px] font-black uppercase border tracking-widest ${configs[tier] || configs['Bronze']}`}>
      {tier}
    </span>
  );
};

/** 第四部分：/success 頁面 — 抓取 URL 參數、發送確認請求、同步狀態、支援重整與手動重試 */
const SHOP_WHATSAPP = '85263611672';

const SuccessView: React.FC<{
  successWaybill: string | null;
  successWaybillLoading: boolean;
  setSuccessWaybill: (v: string | null) => void;
  setSuccessWaybillLoading: (v: boolean) => void;
  highlightOrderId: string | null;
  orders: Order[];
  onViewOrders: () => void;
  onRefreshOrders: () => void;
}> = ({ successWaybill, successWaybillLoading, setSuccessWaybill, setSuccessWaybillLoading, onViewOrders, onRefreshOrders }) => {
  const { t } = useI18n();
  const [confirmError, setConfirmError] = useState<string | null>(null);
  const [confirmSuccess, setConfirmSuccess] = useState(false);

  const runConfirmPayment = useCallback(async () => {
    const win = typeof window !== 'undefined' ? window : null;
    if (!win) return;
    const params = new URLSearchParams(win.location.search);
    const rawOrderId = params.get('order');
    const orderIdFromUrl = rawOrderId ? rawOrderId.trim() : '';
    const sessionId = params.get('session_id') ?? win.sessionStorage?.getItem?.('stripe_session_id') ?? null;
    const orderId = orderIdFromUrl || null;
    if (!orderId && !sessionId) {
      setConfirmError(t.success.missingParams);
      setSuccessWaybillLoading(false);
      return;
    }
    setConfirmError(null);
    setSuccessWaybillLoading(true);
    const apiUrl = `${win.location.origin}/api/confirm-payment`;
    try {
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orderId, session_id: sessionId ?? null }),
      });
      const text = await response.text();
      if (!response.ok) {
        let errData: { error?: string; code?: string; details?: string } | null = null;
        try {
          errData = text ? JSON.parse(text) : null;
        } catch {
          errData = null;
        }
        // Client-side fallback removed for security: only the server can mark orders as paid
        setSuccessWaybillLoading(false);
        setConfirmError(`錯誤 ${response.status}${text ? `: ${text.slice(0, 100)}` : ''}`);
        setConfirmSuccess(false);
        return;
      }
      let data: { success?: boolean; waybillNo?: string; waybill_no?: string; error?: string; code?: string };
      try {
        data = text ? JSON.parse(text) : {};
      } catch {
        setSuccessWaybillLoading(false);
        setConfirmError(`後端回傳非 JSON (${response.status})`);
        setConfirmSuccess(false);
        return;
      }
      setSuccessWaybillLoading(false);
      if (data.success) {
        setConfirmSuccess(true);
        setSuccessWaybill(data.waybill_no ?? data.waybillNo ?? null);
        setConfirmError(null);
        onRefreshOrders();
        if (sessionId) try { win.sessionStorage?.removeItem?.('stripe_session_id'); } catch { /* ignore */ }
      } else {
        setConfirmError(data.error ?? '確認付款時發生錯誤');
        setConfirmSuccess(false);
      }
    } catch (e) {
      setSuccessWaybillLoading(false);
      setConfirmError((e as Error)?.message ?? '網路錯誤，請稍後再試');
      setConfirmSuccess(false);
    }
  }, [setSuccessWaybill, setSuccessWaybillLoading]);

  useEffect(() => {
    runConfirmPayment();
  }, [runConfirmPayment]);

  return (
    <div className="flex-1 bg-slate-50 min-h-screen flex flex-col items-center justify-center p-6 pb-24 animate-fade-in">
      <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-lg p-10 max-w-md w-full text-center space-y-6">
        {successWaybillLoading ? (
          <>
            <div className="w-20 h-20 mx-auto rounded-full bg-blue-50 flex items-center justify-center">
              <RefreshCw className="w-10 h-10 text-blue-500 animate-spin" />
            </div>
            <h2 className="text-xl font-black text-slate-900">{t.success.verifyingPayment}</h2>
            <p className="text-slate-400 text-sm font-bold">請稍候...</p>
          </>
        ) : confirmError && !confirmSuccess ? (
          <>
            <div className="w-20 h-20 mx-auto rounded-full bg-amber-50 flex items-center justify-center">
              <AlertTriangle className="w-10 h-10 text-amber-500" />
            </div>
            <h2 className="text-xl font-black text-slate-900">支付確認中</h2>
            <p className="text-slate-500 text-sm font-bold">支付已記錄，但確認過程稍有延遲。你的訂單不會受影響。</p>
            <p className="text-rose-500 text-xs font-bold">{confirmError}</p>
            <button type="button" onClick={runConfirmPayment} className="w-full py-3 bg-slate-100 text-slate-700 rounded-2xl font-black text-sm hover:bg-slate-200 transition-all">
              {t.success.retryManual}
            </button>
            <button type="button" onClick={onViewOrders} className="w-full py-4 bg-slate-900 text-white rounded-2xl font-black text-sm">{t.success.viewOrders}</button>
          </>
        ) : (
          <>
            <div className="w-20 h-20 mx-auto rounded-full bg-emerald-100 flex items-center justify-center">
              <CheckCircle className="w-12 h-12 text-emerald-600" />
            </div>
            <h2 className="text-2xl font-black text-slate-900">{t.success.paymentConfirmed}</h2>
            <p className="text-slate-500 font-bold text-sm">{t.success.waybillGenerating}</p>

            {successWaybill && (
              <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">{t.success.sfWaybill}</p>
                <p className="text-lg font-black text-slate-900 tracking-wide">{successWaybill}</p>
              </div>
            )}

            <button type="button" onClick={onViewOrders} className="w-full py-4 bg-slate-900 text-white rounded-2xl font-black text-sm">{t.success.viewOrders}</button>
          </>
        )}
      </div>
    </div>
  );
};


// Default advertisement slideshow when Supabase has no data
const DEFAULT_SLIDESHOW: SlideshowItem[] = [
  { id: 'slide-1', type: 'image', url: 'https://placehold.co/800x320/slate-800/white?text=歡迎光臨+冷凍肉專門店', title: '歡迎光臨', sortOrder: 0 },
  { id: 'slide-2', type: 'image', url: 'https://placehold.co/800x320/blue-900/white?text=新鮮急凍+直送到家', title: '新鮮急凍 直送到家', sortOrder: 1 },
];

// --- Admin Auth Constants ---

const FULL_ACCESS: ModulePermission = { read: true, create: true, update: true, delete: true, export: true };
const NO_ACCESS: ModulePermission = { read: false, create: false, update: false, delete: false, export: false };
const READ_ONLY: ModulePermission = { read: true, create: false, update: false, delete: false, export: false };

const CRUD_OPS: CrudOp[] = ['read', 'create', 'update', 'delete', 'export'];
const CRUD_OP_LABELS: Record<CrudOp, string> = {
  read: '讀取', create: '新增', update: '修改', delete: '刪除', export: '匯出',
};
const PRIVILEGED_ADMIN_PHONE = '91111111';

/** Convert legacy boolean or ModulePermission to normalized ModulePermission */
const normalizePermValue = (val: boolean | ModulePermission | undefined | null): ModulePermission => {
  if (!val) return { ...NO_ACCESS };
  if (typeof val === 'boolean') return val ? { ...FULL_ACCESS } : { ...NO_ACCESS };
  return { read: !!val.read, create: !!val.create, update: !!val.update, delete: !!val.delete, export: !!val.export };
};

/** Check if a ModulePermission grants any access (read=true) */
const hasAnyAccess = (perm: ModulePermission | undefined | null): boolean => !!perm?.read;

const DEFAULT_ADMIN_PERMISSIONS: AdminPermissions = {
  global_dashboard: { ...FULL_ACCESS },
  new_order: { ...FULL_ACCESS },
  orders: { ...FULL_ACCESS },
  dispatch: { ...FULL_ACCESS },
  warehouse_ops: { ...FULL_ACCESS },
  production: { ...FULL_ACCESS },
  accounting: { ...FULL_ACCESS },
  wholesale_clients: { ...FULL_ACCESS },
  sales_reps: { ...FULL_ACCESS },
  quotations: { ...FULL_ACCESS },
  inventory: { ...FULL_ACCESS },
  pricing: { ...FULL_ACCESS },
  dashboard: { ...FULL_ACCESS },
  members: { ...FULL_ACCESS },
  slideshow: { ...FULL_ACCESS },
  recipes: { ...FULL_ACCESS },
  ingredients: { ...FULL_ACCESS },
  costs: { ...FULL_ACCESS },
  language: { ...FULL_ACCESS },
  settings: { ...FULL_ACCESS },
  admin_management: { ...NO_ACCESS },
};

const ALL_STAFF_ROLES: AdminRole[] = ['super_admin', 'admin', 'customer_service', 'buyer', 'accountant', 'factory', 'sales_rep'];

const ADMIN_ROLE_LABELS: Record<AdminRole, string> = {
  super_admin: '超級管理員',
  admin: '管理員',
  customer_service: '客服',
  buyer: '採購',
  accountant: '會計',
  factory: '工場',
  sales_rep: '銷售員',
};

const ADMIN_ROLE_COLORS: Record<AdminRole, { bg: string; text: string }> = {
  super_admin: { bg: 'bg-violet-100', text: 'text-violet-700' },
  admin: { bg: 'bg-blue-100', text: 'text-blue-700' },
  customer_service: { bg: 'bg-emerald-100', text: 'text-emerald-700' },
  buyer: { bg: 'bg-amber-100', text: 'text-amber-700' },
  accountant: { bg: 'bg-cyan-100', text: 'text-cyan-700' },
  factory: { bg: 'bg-orange-100', text: 'text-orange-700' },
  sales_rep: { bg: 'bg-pink-100', text: 'text-pink-700' },
};

const ADMIN_ROLE_ICONS: Record<AdminRole, string> = {
  super_admin: '👑',
  admin: '🛡️',
  customer_service: '🎧',
  buyer: '📦',
  accountant: '📊',
  factory: '🏭',
  sales_rep: '💼',
};

const ADMIN_MODULE_PERMISSION_MAP: Record<string, keyof AdminPermissions> = {
  global_dashboard: 'global_dashboard',
  new_order: 'new_order',
  orders: 'orders',
  dispatch: 'dispatch',
  warehouse_ops: 'warehouse_ops',
  production: 'production',
  accounting: 'accounting',
  wholesale_clients: 'wholesale_clients',
  sales_reps: 'sales_reps',
  quotations: 'quotations',
  inventory: 'inventory',
  pricing: 'pricing',
  dashboard: 'dashboard',
  members: 'members',
  slideshow: 'slideshow',
  recipes: 'recipes',
  ingredients: 'ingredients',
  costs: 'costs',
  language: 'language',
  settings: 'settings',
  admin_management: 'admin_management',
};

const ADMIN_PERMISSION_LABELS: Record<keyof AdminPermissions, string> = {
  global_dashboard: '總儀表版',
  new_order: '新訂單',
  orders: '訂單管理',
  dispatch: '派車表',
  warehouse_ops: '材料與倉務',
  production: '工場',
  accounting: '會計',
  wholesale_clients: '批發客資料庫',
  sales_reps: '銷售員',
  quotations: '報價單',
  inventory: '產品/分類',
  pricing: '價錢設定',
  dashboard: '零售儀表板',
  members: '會員管理',
  slideshow: '廣告輪播',
  recipes: '食譜',
  ingredients: '原材料',
  costs: '成本管理',
  language: '語言翻譯',
  settings: '系統設定',
  admin_management: '員工與權限管理',
};

const PERMISSION_GROUPS: { label: string; keys: (keyof AdminPermissions)[] }[] = [
  { label: '通用', keys: ['global_dashboard', 'new_order'] },
  { label: '批發', keys: ['orders', 'wholesale_clients', 'sales_reps', 'quotations', 'pricing'] },
  { label: '零售', keys: ['dashboard', 'members', 'slideshow', 'recipes', 'language'] },
  { label: '營運', keys: ['dispatch', 'warehouse_ops', 'production', 'inventory', 'ingredients'] },
  { label: '財務', keys: ['accounting', 'costs'] },
  { label: '系統', keys: ['settings', 'admin_management'] },
];

/** Build auth headers for admin-only API calls, with optional module + operation for CRUD enforcement */
function buildAdminHeaders(admin: { id: string; role: string } | null, module?: string, op?: CrudOp): Record<string, string> {
  if (!admin) return { 'Content-Type': 'application/json' };
  let sessionToken = '';
  try { sessionToken = localStorage.getItem('coolfood_admin_session_token') ?? ''; } catch { /* ignore */ }
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    'x-admin-id': admin.id,
    'x-admin-role': admin.role,
    'x-session-token': sessionToken,
  };
  if (module) headers['x-admin-module'] = module;
  if (op) headers['x-admin-op'] = op;
  return headers;
}

// --- Main App ---

const App: React.FC = () => {
  const { lang, setLang, t } = useI18n();
  const { site, isGHFoods } = useSite();
  const pName = useCallback((p: Product) => (lang === 'en' && p.nameEn) ? p.nameEn : p.name, [lang]);
  const pDesc = useCallback((p: Product) => (lang === 'en' && p.descriptionEn) ? p.descriptionEn : (p.description || ''), [lang]);

  // --- Routing & Auth Logic ---
  const [isAdminRoute, setIsAdminRoute] = useState(window.location.hash === '#admin');
  const [isSetupRoute, setIsSetupRoute] = useState(window.location.hash === '#setup');
  const [isWholesaleRoute, setIsWholesaleRoute] = useState(() => {
    if (typeof window === 'undefined') return false;
    if (window.location.pathname.startsWith('/wholesale')) return true;
    return isGHFoods;
  });
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [adminLoginForm, setAdminLoginForm] = useState({ username: '', password: '' });
  const [isAppLoading, setIsAppLoading] = useState(true);
  
  const [view, setView] = useState<'store' | 'orders' | 'coupons' | 'profile' | 'checkout' | 'success'>(
    () => (typeof window !== 'undefined' && (window.location.pathname === '/success' || window.location.hash === '#success') ? 'success' : 'store')
  );
  const [isRedirectingToPayment, setIsRedirectingToPayment] = useState(false);
  const [adminModule, setAdminModule] = useState<AdminModuleId>('global_dashboard');
  const [moduleWorkspace, setModuleWorkspace] = useState<Workspace | null>(null);
  const [adminWholesaleBrand, setAdminWholesaleBrand] = useState<'GHFOODS' | 'COOLFOOD'>('GHFOODS');
  const [adminUser, setAdminUser] = useState<AdminAccount | null>(null);
  const [adminAccounts, setAdminAccounts] = useState<AdminAccount[]>([]);
  const [editingAdminAccount, setEditingAdminAccount] = useState<(Partial<AdminAccount> & { isNew?: boolean; newPhone?: string }) | null>(null);
  const [staffRoles, setStaffRoles] = useState<StaffRoleTemplate[]>([]);
  const [editingStaffRole, setEditingStaffRole] = useState<(Partial<StaffRoleTemplate> & { isNew?: boolean }) | null>(null);
  const [staffMgmtTab, setStaffMgmtTab] = useState<'staff' | 'roles'>('staff');
  const [mustChangePassword, setMustChangePassword] = useState(false);
  const [passwordChangeForm, setPasswordChangeForm] = useState({ newPassword: '', confirmPassword: '' });
  const [expandedPermModules, setExpandedPermModules] = useState<Set<string>>(new Set());
  const [inventorySubTab, setInventorySubTab] = useState<'products' | 'categories' | 'rules'>('products');
  const [pricingSubTab, setPricingSubTab] = useState<'retail' | 'wholesale'>('retail');
  const [inventoryChannelFilter, setInventoryChannelFilter] = useState<'all' | 'retail' | 'wholesale'>('all');
  // costsChannelFilter moved to ProductionPanel
  const [ordersStatusFilter, setOrdersStatusFilter] = useState<'all' | OrderStatus>('all');
  const [ordersTypeFilter, setOrdersTypeFilter] = useState<'all' | 'retail' | 'wholesale'>('all');
  const [isAdminSidebarOpen, setIsAdminSidebarOpen] = useState(false);

  // --- Data State ---
  const [user, setUser] = useState<UserType | null>(null);
  const [siteConfig, setSiteConfig] = useState<SiteConfig>({ 
    logoText: 'Fridge-Link', 
    logoIcon: '❄️',
    accentColor: 'blue',
    pricingRules: {
      targetMarginFactor: 0.88,
      autoApplyMemberPrice: true,
      roundToNearest: 1,
      excludedProductIds: [],
      excludedCategoryIds: [],
      markupPercent: 0
    },
    wholesalePricingRules: {
      targetMarginFactor: 0.88,
      priceTiers: [],
    },
    deliveryRules: {
      freeThreshold: 500,
      baseFee: 50,
      coldChainSurcharge: 20,
      lockerDiscount: 10,
      residentialSurcharge: 30,
      tieredFees: [
        { min: 0, fee: 80 },
        { min: 200, fee: 50 },
        { min: 400, fee: 30 }
      ]
    },
    inventoryEnforcementEnabled: false,
  });
  
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [members, setMembers] = useState<UserType[]>([]);
  const [slideshowItems, setSlideshowItems] = useState<SlideshowItem[]>(DEFAULT_SLIDESHOW);
  const [editingSlideshow, setEditingSlideshow] = useState<SlideshowItem | null>(null);
  const [cart, setCart] = useState<CartItem[]>(() => {
    try { const saved = localStorage.getItem('coolfood_cart'); return saved ? JSON.parse(saved) : []; } catch { return []; }
  });
  const [storeSearch, setStoreSearch] = useState('');
  const [deliveryMethod, setDeliveryMethod] = useState<'home' | 'sf_locker' | 'own_van'>(() =>
    typeof window !== 'undefined' && window.location.pathname.startsWith('/wholesale') ? 'own_van' : 'home'
  );
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'fps' | 'cod'>(() =>
    typeof window !== 'undefined' && window.location.pathname.startsWith('/wholesale') ? 'fps' : 'card'
  );
  const [wholesaleDeliveryDate, setWholesaleDeliveryDate] = useState('');
  const [wholesaleDeliveryNote, setWholesaleDeliveryNote] = useState('');

  // ── 動態運費管理 ──
  const SHIPPING_FALLBACKS: Record<string, ShippingConfig> = {
    sf_delivery: { id: 'sf_delivery', label: '順豐冷鏈上門', fee: 50, threshold: 300 },
    sf_locker:   { id: 'sf_locker',   label: '順豐凍櫃自取', fee: 30, threshold: 200 },
  };
  const [shippingConfigs, setShippingConfigs] = useState<Record<string, ShippingConfig>>(SHIPPING_FALLBACKS);
  const [upsellProductIds, setUpsellProductIds] = useState<string[]>([]);

  // ── 優惠券 & 積分系統 ──
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [memberCoupons, setMemberCoupons] = useState<MemberCoupon[]>([]);
  const [selectedCoupon, setSelectedCoupon] = useState<MemberCoupon | null>(null);
  const [editingCoupon, setEditingCoupon] = useState<Coupon | null>(null);
  const [pointsConfig, setPointsConfig] = useState<PointsConfig>({ dollarsPerPoint: 10 });
  const [welcomeCouponsConfig, setWelcomeCouponsConfig] = useState<WelcomeCouponsConfig>({ enabled: false, couponTemplateIds: [] });
  const [couponAdminTab, setCouponAdminTab] = useState<'coupons' | 'distribute' | 'points' | 'welcome'>('coupons');
  const [couponDistributeSearch, setCouponDistributeSearch] = useState('');
  const [couponDistributeSelected, setCouponDistributeSelected] = useState<Set<string>>(new Set());
  const [couponDistributeCouponId, setCouponDistributeCouponId] = useState('');
  const [frontendCouponTab, setFrontendCouponTab] = useState<'my' | 'shop'>('my');
  
  // ── 食譜系統 ──
  const [recipes, setRecipes] = useState<StandaloneRecipe[]>([]);
  const [recipeCategories, setRecipeCategories] = useState<RecipeCategory[]>([]);
  const [editingRecipe, setEditingRecipe] = useState<StandaloneRecipe | null>(null);
  const [editingRecipeCategory, setEditingRecipeCategory] = useState<RecipeCategory | null>(null);
  const [storeMode, setStoreMode] = useState<'shop' | 'recipes'>('shop');
  const [selectedRecipe, setSelectedRecipe] = useState<StandaloneRecipe | null>(null);
  const [recipeProductExpanded, setRecipeProductExpanded] = useState<string | null>(null);
  const [recipeCategoryFilter, setRecipeCategoryFilter] = useState<string[]>([]);
  const [recipeAdminSubTab, setRecipeAdminSubTab] = useState<'recipes' | 'categories'>('recipes');
  const [recipeProductSearch, setRecipeProductSearch] = useState('');
  const [adminRecipeSearch, setAdminRecipeSearch] = useState('');
  const [adminRecipeCategoryFilter, setAdminRecipeCategoryFilter] = useState<string[]>([]);
  const [adminRecipeProductFilter, setAdminRecipeProductFilter] = useState<'all' | 'linked' | 'unlinked'>('all');
  const [aiRecipeLoading, setAiRecipeLoading] = useState(false);
  const [aiBatchProgress, setAiBatchProgress] = useState<{ current: number; total: number; label: string } | null>(null);
  const [selectedLockerDistrict, setSelectedLockerDistrict] = useState('');
  const [selectedLockerCode, setSelectedLockerCode] = useState('');
  const lockerPointsForDistrict = useMemo(() => getPointsByDistrict(selectedLockerDistrict), [selectedLockerDistrict]);
  const selectedLockerPoint: SfColdPickupPoint | undefined = useMemo(() => findPointByCode(selectedLockerCode), [selectedLockerCode]);
  
  // UI State
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  const [activeCategory, setActiveCategory] = useState('hot');
  const [adminProductSearch, setAdminProductSearch] = useState('');
  const [adminOrderSearch, setAdminOrderSearch] = useState('');
  const [adminMemberSearch, setAdminMemberSearch] = useState('');
  const [adminMemberTypeFilter, setAdminMemberTypeFilter] = useState<'all' | 'retail' | 'wholesale' | 'pending' | 'approved' | 'rejected'>('all');
  const [selectedOrderIds, setSelectedOrderIds] = useState<Set<string>>(new Set());
  const [batchProcessing, setBatchProcessing] = useState(false);
  const [sfValidationModal, setSfValidationModal] = useState<{ problematic: { id: string; reason: string }[]; valid: SupabaseOrderRow[] } | null>(null);
  const [refundModal, setRefundModal] = useState<{ orderId: string; total: number } | null>(null);
  const [refundType, setRefundType] = useState<'full' | 'partial'>('full');
  const [refundAmount, setRefundAmount] = useState('');
  const [refundProcessing, setRefundProcessing] = useState(false);
  
  // ── 一鍵回購 ──
  const [reorderModalOpen, setReorderModalOpen] = useState(false);
  const [reorderPhone, setReorderPhone] = useState('');
  const [reorderHint, setReorderHint] = useState<{ type: 'none' | 'guest' | 'member'; text: string }>({ type: 'none', text: '' });
  const [reorderLoading, setReorderLoading] = useState(false);
  const [reorderNotification, setReorderNotification] = useState<{
    type: 'success' | 'partial' | 'fail';
    successCount: number;
    failedNames: string[];
  } | null>(null);

  // Drag-and-drop state for category reordering
  const dragProdCatIdx = useRef<number | null>(null);
  const dragIngCatIdx = useRef<number | null>(null);
  const dragRecipeMethodCatIdx = useRef<number | null>(null);
  const dragRecipeMeatCatIdx = useRef<number | null>(null);
  const [dragOverProdCat, setDragOverProdCat] = useState<number | null>(null);
  const [dragOverIngCat, setDragOverIngCat] = useState<number | null>(null);
  const [dragOverRecipeMethodCat, setDragOverRecipeMethodCat] = useState<number | null>(null);
  const [dragOverRecipeMeatCat, setDragOverRecipeMeatCat] = useState<number | null>(null);

  // Modals
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [editingMember, setEditingMember] = useState<UserType | null>(null);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [inspectingOrder, setInspectingOrder] = useState<Order | null>(null);
  const [inspectingOrderDetails, setInspectingOrderDetails] = useState<SupabaseOrderRow | null>(null);
  const [orderStatusDraft, setOrderStatusDraft] = useState<OrderStatus | null>(null);
  const [trackingDraft, setTrackingDraft] = useState('');
  const [addressEditor, setAddressEditor] = useState<{ address: UserAddress, isNew: boolean, ownerId: string } | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [confirmation, setConfirmation] = useState<{ title: string, message: string, onConfirm: () => void } | null>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [authForm, setAuthForm] = useState({ email: '', password: '', name: '', phone: '', companyName: '', businessType: '', branchCount: '1', storefrontPreparing: false });
  const [wholesaleRegFiles, setWholesaleRegFiles] = useState<{ brDoc: File | null; storefrontPhoto: File | null }>({ brDoc: null, storefrontPhoto: null });
  const [wholesaleRegUploading, setWholesaleRegUploading] = useState(false);
  const [claimStep, setClaimStep] = useState<'idle' | 'email' | 'confirm' | 'credentials' | 'success'>('idle');
  const [claimEmail, setClaimEmail] = useState('');
  const [claimPhone, setClaimPhone] = useState('');
  const [claimPassword, setClaimPassword] = useState('');
  const [claimData, setClaimData] = useState<{ name: string; hasRealPhone: boolean; existingPhone: string | null; shoplineJoinDate: string | null; shoplineOrders: string } | null>(null);
  const [claimLoading, setClaimLoading] = useState(false);
  const [editingMemberPassword, setEditingMemberPassword] = useState('');
  const [aiDescLoading, setAiDescLoading] = useState(false);
  const [aiFieldLoading, setAiFieldLoading] = useState<string | null>(null);
  const [aiPromptModal, setAiPromptModal] = useState<{ title: string; placeholder: string; onConfirm: (instruction: string) => void } | null>(null);
  const [aiPromptText, setAiPromptText] = useState('');

  // Address UI States
  const [showAddressDropdown, setShowAddressDropdown] = useState(false);
  const [showCheckoutAddressForm, setShowCheckoutAddressForm] = useState(false);
  const [checkoutAddressDraft, setCheckoutAddressDraft] = useState<UserAddress | null>(null);
  const [checkoutSelectedAddressId, setCheckoutSelectedAddressId] = useState<string | null>(null);
  const [checkoutGuestPhone, setCheckoutGuestPhone] = useState('');
  const [isChangingAddress, setIsChangingAddress] = useState(false);
  const [checkoutSaveNewAddressAsDefault, setCheckoutSaveNewAddressAsDefault] = useState(true);
  const [isLocatingAddress, setIsLocatingAddress] = useState(false);

  // Highlight the order card on 記錄 after payment success
  const [highlightOrderId, setHighlightOrderId] = useState<string | null>(null);
  // Success page: 順豐單號（從 confirm-payment 取得）
  const [successWaybill, setSuccessWaybill] = useState<string | null>(null);
  const [successWaybillLoading, setSuccessWaybillLoading] = useState(false);

  // Slideshow (store-front ad carousel)
  const [slideshowIndex, setSlideshowIndex] = useState(0);

  // Cost management
  const [costItems, setCostItems] = useState<CostItem[]>([]);
  const [showCostColumns, setShowCostColumns] = useState(false);
  // Retail price override tracking (products whose prices were manually changed)
  const [retailOverrideIds, setRetailOverrideIds] = useState<Set<string>>(new Set());
  // Wholesale per-product P0 overrides: productId → override price
  const [wholesalePriceOverrides, setWholesalePriceOverrides] = useState<Record<string, number>>({});
  // Pending apply confirmation: which tab has a queued "apply factor" action
  const [pendingApplyTab, setPendingApplyTab] = useState<null | 'retail' | 'wholesale'>(null);

  // Ingredients (原材料) management
  const [ingredients, setIngredients] = useState<Ingredient[]>([]);
  const [editingIngredient, setEditingIngredient] = useState<Ingredient | null>(null);
  const [ingredientSubTab, setIngredientSubTab] = useState<'list' | 'units' | 'categories'>('list');
  const [ingredientCategoryList, setIngredientCategoryList] = useState<IngredientCategory[]>([]);

  // Processing Types (加工方式) for product editing
  const [processingTypes, setProcessingTypes] = useState<ProcessingType[]>([]);
  const [editingIngredientCategory, setEditingIngredientCategory] = useState<IngredientCategory | null>(null);

  // Product Groups (產品群組)
  const [productGroups, setProductGroups] = useState<ProductGroup[]>([]);

  const deriveVariantLabel = (
    processingTypeId: string | undefined,
    pricingMode: string | undefined,
    packSize: string | undefined,
    classification: string | undefined,
  ): string => {
    if (classification === 'raw_material') {
      const pt = processingTypeId ? processingTypes.find(p => p.id === processingTypeId) : null;
      const ptName = pt?.name || '原件';
      if (pricingMode === 'by_piece') return `${ptName} 抄碼`;
      return packSize ? `${ptName} ${packSize}` : ptName;
    }
    return packSize || '';
  };

  interface WizardSpec {
    pricingMode: PricingMode;
    processingTypeId?: string;
    processingSpec?: string;
    packSize: string;
    price: number;
    packWeightLb?: number;
  }

  const [newProductWizard, setNewProductWizard] = useState<{
    classification: ProductClassification | null;
    ingredientId: string;
    pricingMode: PricingMode;
    packSize: string;
    productName: string;
    specs: WizardSpec[];
  } | null>(null);
  const [customUnits, setCustomUnits] = useState<{ id: string; label: string; value: string }[]>([]);
  const [selectedIngredientIds, setSelectedIngredientIds] = useState<Set<string>>(new Set());
  const [selectedProductIds, setSelectedProductIds] = useState<Set<string>>(new Set());
  const [ingredientCategoryFilter, setIngredientCategoryFilter] = useState<string>('all');
  const DEFAULT_UNITS = [{ value: 'lb', label: '磅 (lb)' }, { value: 'kg', label: '公斤 (kg)' }, { value: 'pc', label: '件 (pc)' }, { value: 'box', label: '箱 (box)' }, { value: 'pack', label: '包 (pack)' }];
  const allUnits = useMemo(() => [...DEFAULT_UNITS, ...customUnits.filter(u => u.value && u.label).map(u => ({ value: u.value, label: u.label }))], [customUnits]);
  // ingredientCategories: driven solely by the Supabase ingredient_categories
  // table. Empty until the admin creates categories in the '類別管理' sub-tab.
  const ingredientCategories = ingredientCategoryList.map(c => c.name);
  const filteredIngredients = useMemo(() => {
    const filtered = ingredients.filter(ing => {
      if (ingredientCategoryFilter === 'uncategorized') {
        if (ing.category) return false;
      } else if (ingredientCategoryFilter !== 'all' && ing.category !== ingredientCategoryFilter) {
        return false;
      }
      return true;
    });
    return filtered.sort((a, b) => {
      const aCat = a.category || '';
      const bCat = b.category || '';
      if (!aCat && bCat) return -1;
      if (aCat && !bCat) return 1;
      if (!aCat && !bCat) return 0;
      const aOrder = ingredientCategoryList.find(c => c.name === aCat)?.sortOrder ?? 9999;
      const bOrder = ingredientCategoryList.find(c => c.name === bCat)?.sortOrder ?? 9999;
      return aOrder - bOrder;
    });
  }, [ingredients, ingredientCategoryFilter, ingredientCategoryList]);

  // AI State
  const [aiAnalysis, setAiAnalysis] = useState<string>('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const listRef = useRef<HTMLDivElement>(null);
  const catRefs = useRef<Record<string, HTMLDivElement | null>>({});
  const streetInputRef = useRef<HTMLInputElement | null>(null);
  const placesAutocompleteRef = useRef<unknown>(null);

  const showToast = (message: string, type: 'success' | 'error' = 'success') => setToast({ message, type });

  // Handle Hash / path navigation (admin, success → 記錄 with highlight)
  useEffect(() => {
    const syncViewFromUrl = () => {
      const hash = window.location.hash;
      const path = window.location.pathname;
      const search = window.location.search || '';
      setIsAdminRoute(hash === '#admin');
      setIsSetupRoute(hash === '#setup');
      setIsWholesaleRoute(path.startsWith('/wholesale') || isGHFoods);
      if (path === '/success' || hash === '#success') {
        const params = new URLSearchParams(search);
        const orderId = params.get('order');
        setView('success');
        if (orderId) {
          setHighlightOrderId(orderId);
          setToast({ message: '多謝惠顧', type: 'success' });
        }
      }
      // /recipes route: switch to recipes view
      if (path === '/recipes' || path.startsWith('/recipes/')) {
        setView('store');
        setStoreMode('recipes');
        const recipeIdMatch = path.match(/^\/recipes\/(.+)$/);
        if (recipeIdMatch) {
          const rid = recipeIdMatch[1];
          // Will be resolved after recipes load
          setTimeout(() => {
            setRecipes(prev => {
              const found = prev.find(r => r.id === rid);
              if (found) setSelectedRecipe(found);
              return prev;
            });
          }, 500);
        }
      }
    };
    syncViewFromUrl();
    window.addEventListener('hashchange', syncViewFromUrl);
    window.addEventListener('popstate', syncViewFromUrl);
    return () => {
      window.removeEventListener('hashchange', syncViewFromUrl);
      window.removeEventListener('popstate', syncViewFromUrl);
    };
  }, []);

  // Clear order highlight after a few seconds
  useEffect(() => {
    if (!highlightOrderId) return;
    const t = setTimeout(() => setHighlightOrderId(null), 4000);
    return () => clearTimeout(t);
  }, [highlightOrderId]);

  // Persist cart to localStorage
  useEffect(() => {
    try { localStorage.setItem('coolfood_cart', JSON.stringify(cart)); } catch { /* quota exceeded or private mode */ }
  }, [cart]);

  // Clear cart when landing on success page (e.g. redirect from payment app)
  useEffect(() => {
    if (view === 'success' && typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      if (params.has('order') || params.has('session_id')) {
        setCart([]);
        setSelectedCoupon(null);
      }
    }
  }, []);

  // Update browser tab title when route changes
  useEffect(() => {
    if (isAdminRoute) {
      document.title = `Fridge-Link | 管理後台 (${window.location.href})`;
      return;
    }
    document.title = `${siteConfig.logoText} | 香港冷凍肉專門店`;
  }, [isAdminRoute, siteConfig.logoText]);

  useEffect(() => {
    const title = `${siteConfig.logoText} | 香港冷凍肉專門店`;
    const desc = `${siteConfig.logoText} - 香港冷凍肉專門店，新鮮急凍直送到家，順豐冷鏈配送`;
    const logoUrl = siteConfig.logoUrl || '';
    const updateMeta = (id: string, attr: string, value: string) => {
      const el = document.getElementById(id);
      if (el) el.setAttribute(attr, value);
    };
    updateMeta('og-title', 'content', title);
    updateMeta('og-description', 'content', desc);
    updateMeta('og-image', 'content', logoUrl);
    updateMeta('tw-title', 'content', title);
    updateMeta('tw-description', 'content', desc);
    updateMeta('tw-image', 'content', logoUrl);
    if (logoUrl) {
      updateMeta('dynamic-favicon', 'href', logoUrl);
      updateMeta('apple-touch-icon', 'href', logoUrl);
    }
    const ldEl = document.getElementById('ld-json-org');
    if (ldEl) {
      ldEl.textContent = JSON.stringify({
        '@context': 'https://schema.org',
        '@type': 'Organization',
        name: siteConfig.logoText,
        url: window.location.origin,
        logo: logoUrl,
      });
    }
  }, [siteConfig.logoText, siteConfig.logoUrl]);

  // Product-level JSON-LD for Google rich results
  useEffect(() => {
    const existingEl = document.getElementById('ld-json-product');
    if (!selectedProduct) {
      if (existingEl) existingEl.remove();
      return;
    }
    const ld = {
      '@context': 'https://schema.org',
      '@type': 'Product',
      name: selectedProduct.name,
      description: selectedProduct.description || selectedProduct.name,
      image: isMediaUrl(selectedProduct.image) ? selectedProduct.image : undefined,
      brand: { '@type': 'Brand', name: siteConfig.logoText },
      offers: {
        '@type': 'Offer',
        priceCurrency: 'HKD',
        price: selectedProduct.price,
        availability: (!siteConfig.inventoryEnforcementEnabled || !selectedProduct.trackInventory || selectedProduct.stock > 0) ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock',
      },
    };
    if (existingEl) {
      existingEl.textContent = JSON.stringify(ld);
    } else {
      const script = document.createElement('script');
      script.type = 'application/ld+json';
      script.id = 'ld-json-product';
      script.textContent = JSON.stringify(ld);
      document.head.appendChild(script);
    }
    return () => { const el = document.getElementById('ld-json-product'); if (el) el.remove(); };
  }, [selectedProduct, siteConfig.logoText]);

  // Recipe-level JSON-LD for Google rich results + URL management
  useEffect(() => {
    const existingEl = document.getElementById('ld-json-recipe');
    if (!selectedRecipe) {
      if (existingEl) existingEl.remove();
      return;
    }
    // Update URL to /recipes/:id without reloading
    const recipeUrl = `/recipes/${selectedRecipe.id}`;
    if (window.location.pathname !== recipeUrl) {
      window.history.pushState({}, '', recipeUrl);
    }
    document.title = `${selectedRecipe.title} | ${t.recipes.recipes} | ${siteConfig.logoText}`;
    const ld: Record<string, unknown> = {
      '@context': 'https://schema.org',
      '@type': 'Recipe',
      name: selectedRecipe.title,
      description: selectedRecipe.description || selectedRecipe.title,
      image: selectedRecipe.mediaUrl && isMediaUrl(selectedRecipe.mediaUrl) ? selectedRecipe.mediaUrl : undefined,
      cookTime: selectedRecipe.cookingTime > 0 ? `PT${selectedRecipe.cookingTime}M` : undefined,
      recipeIngredient: [
        ...selectedRecipe.linkedProductIds.map(pid => products.find(x => x.id === pid)?.name).filter(Boolean),
        ...selectedRecipe.ingredientsRaw.map(i => `${i.name} ${i.amount}`.trim()),
      ],
      recipeInstructions: selectedRecipe.steps.sort((a, b) => a.order - b.order).map(s => ({
        '@type': 'HowToStep',
        text: s.content,
      })),
      keywords: selectedRecipe.tags.join(', '),
    };
    if (existingEl) {
      existingEl.textContent = JSON.stringify(ld);
    } else {
      const script = document.createElement('script');
      script.type = 'application/ld+json';
      script.id = 'ld-json-recipe';
      script.textContent = JSON.stringify(ld);
      document.head.appendChild(script);
    }
    return () => {
      const el = document.getElementById('ld-json-recipe');
      if (el) el.remove();
      // Restore URL when modal closes
      if (window.location.pathname.startsWith('/recipes/')) {
        window.history.pushState({}, '', '/');
        document.title = `${siteConfig.logoText} | 香港冷凍肉專門店`;
      }
    };
  }, [selectedRecipe, siteConfig.logoText, products, t.recipes.recipes]);

  // Update URL when switching to/from recipes mode
  useEffect(() => {
    if (storeMode === 'recipes' && window.location.pathname !== '/recipes') {
      window.history.pushState({}, '', '/recipes');
      document.title = `${t.recipes.title} | ${siteConfig.logoText}`;
    } else if (storeMode === 'shop' && window.location.pathname === '/recipes') {
      window.history.pushState({}, '', '/');
      document.title = `${siteConfig.logoText} | 香港冷凍肉專門店`;
    }
  }, [storeMode, siteConfig.logoText, t.recipes.title]);

  // Load core data from Supabase on mount
  useEffect(() => {
    const loadCoreData = async () => {
      const membersPromise = isAdminRoute
        ? supabase.from('members_safe').select('id, name, email, phone_number, points, tier, role, admin_permissions, member_type, wholesale_price_tier, wholesale_status, wholesale_brand, company_name, business_type, branch_count, br_doc_url, storefront_photo_url, storefront_preparing, delivery_address, br_update_required, addresses, client_code, fax, district, route_id, credit_limit, parent_member_id, salesperson_id, payment_terms_days, payment_terms_type, discount_percent, wholesale_notes, is_wholesale_active')
        : Promise.resolve({ data: null, error: null });
      const [productsRes, categoriesRes, membersRes, slideshowRes] = await Promise.all([
        supabase.from('products').select('*'),
        supabase.from('categories').select('*'),
        membersPromise,
        supabase.from('slideshow').select('*').order('sort_order', { ascending: true })
      ]);

      if (productsRes.error) {
        if (!handleSchemaError(productsRes.error, 'products')) {
          showToast('產品資料載入失敗', 'error');
        }
      } else if (productsRes.data?.length) {
        setProducts(productsRes.data.map(mapProductRowToProduct));
      }

      if (categoriesRes.error) {
        if (!handleSchemaError(categoriesRes.error, 'categories')) {
          showToast('分類資料載入失敗', 'error');
        }
      } else if (categoriesRes.data?.length) {
        const mapped = categoriesRes.data.map(mapCategoryRowToCategory).sort((a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0));
        setCategories(mapped);
        setActiveCategory(mapped[0].id);
      }

      if (membersRes.error) {
        if (!handleSchemaError(membersRes.error, 'members')) {
          showToast('會員資料載入失敗', 'error');
        }
      } else if (membersRes.data) {
        setMembers(membersRes.data.map(mapMemberRowToUser));
      }

      if (!slideshowRes.error && slideshowRes.data?.length) {
        setSlideshowItems(slideshowRes.data.map((r: { id: string; type: string; url: string; title?: string | null; sort_order: number }) => mapSlideshowRowToItem(r)));
      }

      // ── 載入動態運費配置 + 湊單推薦產品（合併請求，失敗時使用 fallback）──
      try {
        const [scRes, upRes] = await Promise.all([
          supabase.from('shipping_configs').select('*'),
          supabase.from('upsell_configs').select('product_id').eq('is_active', true),
        ]);
        if (!scRes.error && scRes.data && scRes.data.length > 0) {
          const map: Record<string, ShippingConfig> = {};
          scRes.data.forEach((row: any) => {
            map[row.id] = { id: row.id, label: row.label, fee: Number(row.fee), threshold: Number(row.threshold), updated_at: row.updated_at };
          });
          setShippingConfigs(prev => ({ ...prev, ...map }));
        }
        if (!upRes.error && upRes.data) {
          setUpsellProductIds(upRes.data.map((r: any) => r.product_id));
        }
      } catch {
        console.warn('[shipping/upsell] Failed to load, using fallback values');
      }

      // ── 載入食譜資料 ──
      try {
        const [recipesRes, linksRes, rcRes] = await Promise.all([
          supabase.from('recipes').select('*').order('created_at', { ascending: false }),
          supabase.from('recipe_product_links').select('*'),
          supabase.from('recipe_categories').select('*').order('sort_order', { ascending: true }),
        ]);
        if (!recipesRes.error && recipesRes.data) {
          const linksMap: Record<string, string[]> = {};
          if (!linksRes.error && linksRes.data) {
            linksRes.data.forEach((link: { recipe_id: string; product_id: string }) => {
              if (!linksMap[link.recipe_id]) linksMap[link.recipe_id] = [];
              linksMap[link.recipe_id].push(link.product_id);
            });
          }
          setRecipes(recipesRes.data.map((row: SupabaseRecipeRow) => mapRecipeRowToRecipe(row, linksMap[row.id] || [])));
        }
        if (!rcRes.error && rcRes.data) {
          setRecipeCategories(rcRes.data.map(mapRecipeCategoryRow));
        }
      } catch {
        console.warn('[recipes] Failed to load');
      }

      // ── 載入原材料 (Ingredients) + 加工方式 (Processing Types) + 產品群組 ──
      try {
        const [ingRes, icRes, ptRes, pgRes] = await Promise.all([
          supabase.from('ingredients').select('*').order('name'),
          supabase.from('ingredient_categories').select('*').order('sort_order'),
          supabase.from('processing_types').select('*').eq('is_active', true).order('sort_order'),
          supabase.from('product_groups').select('*').eq('is_active', true).order('name'),
        ]);
        if (!ingRes.error && ingRes.data) {
          setIngredients(ingRes.data.map(mapIngredientRowToIngredient));
        }
        if (!icRes.error && icRes.data && icRes.data.length > 0) {
          setIngredientCategoryList(icRes.data.map(mapIngredientCategoryRow));
        }
        if (!ptRes.error && ptRes.data) {
          setProcessingTypes(ptRes.data.map((r: any) => mapProcessingTypeRow(r)));
        }
        if (!pgRes.error && pgRes.data) {
          setProductGroups(pgRes.data.map(mapProductGroupRow));
        }
      } catch {
        console.warn('[ingredients] Failed to load');
      }

      // ── 載入 site_config（定價規則、品牌設定、成本項目）──
      try {
        const { data: cfgRows } = await supabase.from('site_config').select('*');
        if (cfgRows && cfgRows.length > 0) {
          const cfgMap: Record<string, any> = {};
          cfgRows.forEach((r: any) => { cfgMap[r.id] = r.value; });
          setSiteConfig(prev => ({
            ...prev,
            ...(cfgMap.site_branding || {}),
            pricingRules: cfgMap.pricing_rules ? { ...prev.pricingRules, ...cfgMap.pricing_rules } : prev.pricingRules,
            wholesalePricingRules: cfgMap.wholesale_pricing_rules ? { ...prev.wholesalePricingRules, ...cfgMap.wholesale_pricing_rules } : prev.wholesalePricingRules,
            ...(typeof cfgMap.store_feature_flags?.inventoryEnforcementEnabled === 'boolean' ? { inventoryEnforcementEnabled: cfgMap.store_feature_flags.inventoryEnforcementEnabled } : {}),
          }));
          if (Array.isArray(cfgMap.cost_items)) setCostItems(cfgMap.cost_items);
          if (Array.isArray(cfgMap.custom_units)) setCustomUnits(cfgMap.custom_units);
          if (Array.isArray(cfgMap.pricing_rules?.retailOverrideIds)) {
            setRetailOverrideIds(new Set(cfgMap.pricing_rules.retailOverrideIds));
          }
          if (cfgMap.wholesale_price_overrides && typeof cfgMap.wholesale_price_overrides === 'object') {
            setWholesalePriceOverrides(cfgMap.wholesale_price_overrides);
          }
          if (cfgMap.points_config) setPointsConfig(cfgMap.points_config);
          if (cfgMap.welcome_coupons_config) setWelcomeCouponsConfig(cfgMap.welcome_coupons_config);
        }
      } catch {
        console.warn('[site_config] Failed to load, using defaults');
      }

      // Load coupons
      try {
        const { data: cpnRows } = await supabase.from('coupons').select('*').order('created_at', { ascending: false });
        if (cpnRows) setCoupons(cpnRows.map(mapCouponRowToCoupon));
      } catch { console.warn('[coupons] Failed to load'); }

      setIsAppLoading(false);
    };

    loadCoreData();
  }, []);

  // Auto-advance advertisement slideshow
  useEffect(() => {
    if (slideshowItems.length <= 1) return;
    const t = setInterval(() => setSlideshowIndex(i => (i + 1) % slideshowItems.length), 5000);
    return () => clearInterval(t);
  }, [slideshowItems.length]);

  // Restore member login from localStorage via server-side session validation
  useEffect(() => {
    let storedId: string | null = null;
    let storedToken: string | null = null;
    try {
      storedId = localStorage.getItem('coolfood_member_id');
      storedToken = localStorage.getItem('coolfood_session_token');
    } catch { /* ignore */ }
    if (!storedId || !storedToken) return;
    const restoreUser = async () => {
      try {
        const storedIssuedAt = Number(localStorage.getItem('coolfood_session_issued_at')) || 0;
        const res = await fetch('/api/customer-auth', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'restore-session', memberId: storedId, sessionToken: storedToken, issuedAt: storedIssuedAt || undefined }),
        });
        if (!res.ok) {
          try { localStorage.removeItem('coolfood_member_id'); localStorage.removeItem('coolfood_session_token'); localStorage.removeItem('coolfood_session_issued_at'); } catch { /* ignore */ }
          return;
        }
        const json = await res.json();
        if (json.user) setUser(mapMemberRowToUser(json.user as SupabaseMemberRow));
      } catch { /* ignore */ }
    };
    restoreUser();
  }, []);

  // Load member coupons when user logs in
  useEffect(() => {
    if (!user) { setMemberCoupons([]); setSelectedCoupon(null); return; }
    const loadMemberCoupons = async () => {
      try {
        const { data } = await supabase
          .from('member_coupons')
          .select('*, coupons(*)')
          .eq('member_id', user.id)
          .eq('status', 'available')
          .order('created_at', { ascending: false });
        if (data) setMemberCoupons(data.map(mapMemberCouponRow));
      } catch { console.warn('[member_coupons] Failed to load'); }
    };
    loadMemberCoupons();
  }, [user?.id, user?.points]);

  // Load staff roles and restore admin session on admin route
  useEffect(() => {
    if (!isAdminRoute) return;
    let cancelled = false;
    const init = async () => {
      await loadStaffRoles();
      if (isAdminAuthenticated || cancelled) return;

      let stored: string | null = null;
      let token: string | null = null;
      let storedIssuedAt: string | null = null;
      try {
        stored = localStorage.getItem('coolfood_admin_session');
        token = localStorage.getItem('coolfood_admin_session_token');
        storedIssuedAt = localStorage.getItem('coolfood_admin_issued_at');
      } catch { /* ignore */ }

      if (!stored || !token) return;

      try {
        const parsed = JSON.parse(stored);
        if (!parsed?.id) return;

        const res = await fetch('/api/admin-auth', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            action: 'session',
            adminId: parsed.id,
            sessionToken: token,
            issuedAt: Number(storedIssuedAt) || undefined,
          }),
        });

        if (cancelled) return;

        if (!res.ok) {
          try {
            localStorage.removeItem('coolfood_admin_session');
            localStorage.removeItem('coolfood_admin_session_token');
            localStorage.removeItem('coolfood_admin_issued_at');
          } catch { /* ignore */ }
          return;
        }

        const json = await res.json();
        if (json.admin && !cancelled) {
          const permissions = buildAdminPermissions(
            json.admin.role,
            json.admin.permissions as Record<string, boolean | ModulePermission> | null,
            json.admin.phone as string | undefined,
          );
          const roleLabel = ADMIN_ROLE_LABELS[json.admin.role as AdminRole] || json.admin.role;
          const restored: AdminAccount = {
            id: json.admin.id,
            name: json.admin.name,
            phone: json.admin.phone,
            role: json.admin.role as AdminRole,
            roleDisplayName: roleLabel,
            permissions,
            isActive: true,
          };
          setAdminUser(restored);
          setIsAdminAuthenticated(true);
          try { localStorage.setItem('coolfood_admin_session', JSON.stringify(restored)); } catch { /* ignore */ }
        }
      } catch {
        try {
          localStorage.removeItem('coolfood_admin_session');
          localStorage.removeItem('coolfood_admin_session_token');
          localStorage.removeItem('coolfood_admin_issued_at');
        } catch { /* ignore */ }
      }
    };
    init();
    return () => { cancelled = true; };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAdminRoute]);

  const fetchOrders = useCallback(async () => {
    if (!isAdminRoute && !user) {
      setOrders([]);
      return;
    }
    if (isAdminRoute) {
      let { data, error } = await supabase
        .from('orders')
        .select('id, customer_name, total, status, order_date, items_count, tracking_number, waybill_no, order_type, wholesale_brand, member_id, created_at')
        .order('created_at', { ascending: false })
        .order('id', { ascending: false });
      if (error && String(error.message || '').toLowerCase().includes('created_at')) {
        const fallback = await supabase
          .from('orders')
          .select('id, customer_name, total, status, order_date, items_count, tracking_number, waybill_no, order_type, wholesale_brand, member_id')
          .order('order_date', { ascending: false })
          .order('id', { ascending: false });
        data = fallback.data;
        error = fallback.error;
      }
      if (error) {
        if (!handleSchemaError(error, 'orders')) {
          showToast('訂單資料載入失敗', 'error');
        }
        return;
      }
      setOrders(data?.length ? (data as SupabaseOrderRow[]).map(mapOrderRowToOrder) : []);
      return;
    }
    try {
      const memberId = localStorage.getItem('coolfood_member_id') || '';
      const sessionToken = localStorage.getItem('coolfood_session_token') || '';
      const res = await fetch('/api/customer-api', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-member-id': memberId, 'x-session-token': sessionToken },
        body: JSON.stringify({ action: 'list' }),
      });
      if (!res.ok) { showToast('訂單資料載入失敗', 'error'); return; }
      const json = await res.json();
      setOrders(json.data?.length ? (json.data as SupabaseOrderRow[]).map(mapOrderRowToOrder) : []);
    } catch {
      showToast('訂單資料載入失敗', 'error');
    }
  }, [isAdminRoute, user]);

  // Load orders from Supabase on mount
  useEffect(() => {
    fetchOrders();
  }, [fetchOrders]);

  // Refresh orders when viewing order history
  useEffect(() => {
    if (view === 'orders') fetchOrders();
  }, [view, fetchOrders]);

  useEffect(() => {
    const loadOrderDetails = async () => {
      if (!inspectingOrder) {
        setInspectingOrderDetails(null);
        setOrderStatusDraft(null);
        setTrackingDraft('');
        return;
      }
      const dbId = getOrderDbId(inspectingOrder.id);
      if (dbId === null) return;

      if (isAdminRoute) {
        const { data, error } = await supabase.from('orders').select('*').eq('id', dbId).single();
        if (error || !data) {
          showToast(error?.message || '訂單載入失敗', 'error');
          return;
        }
        const details = data as SupabaseOrderRow;
        setInspectingOrderDetails(details);
        setOrderStatusDraft(normalizeOrderStatus(details.status));
        setTrackingDraft(details.waybill_no ?? details.tracking_number ?? '');
        return;
      }

      try {
        const memberId = localStorage.getItem('coolfood_member_id') || '';
        const sessionToken = localStorage.getItem('coolfood_session_token') || '';
        const res = await fetch('/api/customer-api', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-member-id': memberId,
            'x-session-token': sessionToken,
          },
          body: JSON.stringify({ action: 'details', orderId: dbId }),
        });
        if (!res.ok) { showToast('無法查看此訂單', 'error'); return; }
        const json = await res.json();
        if (!json.data) { showToast('無法查看此訂單', 'error'); return; }
        const details = json.data as SupabaseOrderRow;
        setInspectingOrderDetails(details);
        setOrderStatusDraft(normalizeOrderStatus(details.status));
        setTrackingDraft(details.waybill_no ?? details.tracking_number ?? '');
      } catch {
        showToast('訂單載入失敗', 'error');
      }
    };
    loadOrderDetails();
  }, [inspectingOrder, isAdminRoute, user]);

  const buildAdminPermissions = (
    role: string,
    overrides?: Record<string, boolean | ModulePermission> | null,
    phone?: string | null,
  ): AdminPermissions => {
    if (role === 'super_admin') {
      const all: AdminPermissions = {} as AdminPermissions;
      for (const key of Object.keys(DEFAULT_ADMIN_PERMISSIONS) as (keyof AdminPermissions)[]) all[key] = { ...FULL_ACCESS };
      return all;
    }
    if ((phone || '').trim() === PRIVILEGED_ADMIN_PHONE) {
      const all: AdminPermissions = {} as AdminPermissions;
      for (const key of Object.keys(DEFAULT_ADMIN_PERMISSIONS) as (keyof AdminPermissions)[]) {
        all[key] = key === 'admin_management' ? { ...NO_ACCESS } : { ...FULL_ACCESS };
      }
      return all;
    }
    if (overrides && Object.keys(overrides).length > 0) {
      const perms = {} as AdminPermissions;
      for (const key of Object.keys(DEFAULT_ADMIN_PERMISSIONS) as (keyof AdminPermissions)[]) {
        perms[key] = normalizePermValue(overrides[key]);
      }
      if (role !== 'admin') perms.admin_management = { ...NO_ACCESS };
      return perms;
    }
    const matched = staffRoles.find(r => r.name === role);
    if (matched) {
      const perms = {} as AdminPermissions;
      for (const key of Object.keys(DEFAULT_ADMIN_PERMISSIONS) as (keyof AdminPermissions)[]) {
        perms[key] = normalizePermValue((matched.modulePermissions as any)[key]);
      }
      return perms;
    }
    return { ...DEFAULT_ADMIN_PERMISSIONS, admin_management: { ...NO_ACCESS } };
  };

  const hasAdminPermission = (module: keyof AdminPermissions): boolean => {
    if (!adminUser) return false;
    if (adminUser.role === 'super_admin') return true;
    return hasAnyAccess(adminUser.permissions[module]);
  };

  const hasModuleOp = (module: keyof AdminPermissions, op: CrudOp): boolean => {
    if (!adminUser) return false;
    if (adminUser.role === 'super_admin') return true;
    const perm = adminUser.permissions[module];
    return perm ? !!perm[op] : false;
  };

  const handleAdminModuleNav = (moduleId: AdminModuleId, workspace?: Workspace | null) => {
    setAdminModule(moduleId);
    setModuleWorkspace(workspace ?? null);
    if (moduleId === 'admin_management') loadAdminAccounts();
    if (moduleId === 'members' && workspace === 'WHOLESALE') setAdminMemberTypeFilter('pending');
  };

  const handleWorkspaceSwitch = (ws: Workspace | null, brand?: 'GHFOODS' | 'COOLFOOD') => {
    if (ws) {
      const defaultModules: Record<Workspace, AdminModuleId> = {
        COOLFOOD_RETAIL: 'dashboard',
        WHOLESALE: 'orders',
      };
      setAdminModule(defaultModules[ws]);
      setModuleWorkspace(ws);
      if (brand) setAdminWholesaleBrand(brand);
    } else {
      setAdminModule('global_dashboard');
      setModuleWorkspace(null);
    }
  };

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/admin-auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'login', phone: adminLoginForm.username, password: adminLoginForm.password }),
      });
      const json = await res.json();
      if (!res.ok || !json.admin) {
        showToast(json.error || '帳號或密碼錯誤', 'error');
        return;
      }
      const { admin: serverAdmin, sessionToken, issuedAt } = json;
      const permissions = buildAdminPermissions(
        serverAdmin.role,
        serverAdmin.permissions as Record<string, boolean | ModulePermission> | null,
        serverAdmin.phone as string | undefined,
      );
      const roleLabel = ADMIN_ROLE_LABELS[serverAdmin.role as AdminRole] || serverAdmin.role;
      const admin: AdminAccount = {
        id: serverAdmin.id,
        name: serverAdmin.name,
        phone: serverAdmin.phone,
        role: serverAdmin.role as AdminRole,
        roleDisplayName: roleLabel,
        permissions,
        isActive: true,
      };
      setAdminUser(admin);
      setIsAdminAuthenticated(true);
      if (serverAdmin.mustChangePassword) {
        setMustChangePassword(true);
      }
      try {
        localStorage.setItem('coolfood_admin_session', JSON.stringify(admin));
        localStorage.setItem('coolfood_admin_session_token', sessionToken);
        if (issuedAt) localStorage.setItem('coolfood_admin_issued_at', String(issuedAt));
      } catch { /* ignore */ }
      showToast(`歡迎回來，${admin.name}！`);
    } catch {
      showToast('登入失敗，請稍後再試', 'error');
    }
  };

  const handleForcePasswordChange = async () => {
    if (!adminUser) return;
    if (!passwordChangeForm.newPassword || passwordChangeForm.newPassword.length < 6) {
      showToast('新密碼至少需要6個字元', 'error'); return;
    }
    if (passwordChangeForm.newPassword !== passwordChangeForm.confirmPassword) {
      showToast('兩次輸入的密碼不一致', 'error'); return;
    }
    try {
      const sessionToken = localStorage.getItem('coolfood_admin_session_token') || '';
      const res = await fetch('/api/admin-auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'change-password', adminId: adminUser.id, sessionToken, newPassword: passwordChangeForm.newPassword }),
      });
      const json = await res.json();
      if (!res.ok) { showToast(json.error || '更改密碼失敗', 'error'); return; }
      if (json.sessionToken) {
        try {
          localStorage.setItem('coolfood_admin_session_token', json.sessionToken);
          if (json.issuedAt) localStorage.setItem('coolfood_admin_issued_at', String(json.issuedAt));
        } catch { /* ignore */ }
      }
      setMustChangePassword(false);
      setPasswordChangeForm({ newPassword: '', confirmPassword: '' });
      showToast('密碼已更新！');
    } catch {
      showToast('更改密碼失敗', 'error');
    }
  };

  const loadStaffRoles = async () => {
    const { data, error } = await supabase
      .from('staff_roles')
      .select('*')
      .order('sort_order', { ascending: true });
    if (error) return;
    setStaffRoles((data || []).map(r => ({
      id: r.id,
      name: r.name,
      displayName: r.display_name,
      isSystem: r.is_system,
      modulePermissions: r.module_permissions as unknown as AdminPermissions,
      sortOrder: r.sort_order,
    })));
  };

  const loadAdminAccounts = async () => {
    await loadStaffRoles();
    const { data, error } = await supabase
      .from('members')
      .select('id, name, phone_number, role, admin_permissions')
      .neq('role', 'customer')
      .order('role', { ascending: false });
    if (error) { showToast(`載入員工列表失敗：${error.message}`, 'error'); return; }
    setAdminAccounts((data || []).map(r => ({
      id: r.id,
      name: r.name,
      phone: r.phone_number,
      role: r.role as AdminRole,
      roleDisplayName: ADMIN_ROLE_LABELS[r.role as AdminRole] || r.role,
      permissions: buildAdminPermissions(
        r.role,
        r.admin_permissions as Record<string, boolean | ModulePermission> | null,
        r.phone_number,
      ),
      isActive: true,
    })));
  };

  const grantAdminAccess = async (phone: string, role: AdminRole, permissions: AdminPermissions) => {
    const { data: member, error: findErr } = await supabase
      .from('members')
      .select('id, name, phone_number')
      .eq('phone_number', phone.trim())
      .maybeSingle();
    if (findErr || !member) { showToast('找不到此電話號碼的會員帳戶', 'error'); return; }
    const { error } = await supabase
      .from('members')
      .update({ role, admin_permissions: permissions })
      .eq('id', member.id);
    if (error) { showToast(`授權失敗：${error.message}`, 'error'); return; }
    await loadAdminAccounts();
    showToast(`已將 ${member.name}（${phone}）設為${ADMIN_ROLE_LABELS[role] || role}`);
    setEditingAdminAccount(null);
  };

  const updateAdminAccount = async (id: string, role: AdminRole, permissions: AdminPermissions) => {
    const { error } = await supabase
      .from('members')
      .update({ role, admin_permissions: permissions })
      .eq('id', id);
    if (error) { showToast(`更新失敗：${error.message}`, 'error'); return; }
    if (adminUser?.id === id) {
      const updated: AdminAccount = { ...adminUser, role, permissions };
      setAdminUser(updated);
      try { localStorage.setItem('coolfood_admin_session', JSON.stringify(updated)); } catch { /* ignore */ }
    }
    await loadAdminAccounts();
    showToast('員工權限已更新');
    setEditingAdminAccount(null);
  };

  const revokeAdminAccess = async (id: string, name: string) => {
    if (!window.confirm(`確定要撤銷 ${name} 的後台權限嗎？`)) return;
    const { error } = await supabase
      .from('members')
      .update({ role: 'customer', admin_permissions: null })
      .eq('id', id);
    if (error) { showToast(`撤銷失敗：${error.message}`, 'error'); return; }
    await loadAdminAccounts();
    showToast(`已撤銷 ${name} 的後台權限`);
  };

  const saveStaffRole = async (roleData: Partial<StaffRoleTemplate> & { isNew?: boolean }) => {
    if (roleData.isNew) {
      const { error } = await supabase.from('staff_roles').insert({
        name: roleData.name,
        display_name: roleData.displayName,
        is_system: false,
        module_permissions: roleData.modulePermissions,
        sort_order: staffRoles.length,
      });
      if (error) { showToast(`新增失敗：${error.message}`, 'error'); return; }
      showToast('新角色已建立');
    } else {
      const { error } = await supabase.from('staff_roles').update({
        display_name: roleData.displayName,
        module_permissions: roleData.modulePermissions,
      }).eq('id', roleData.id);
      if (error) { showToast(`更新失敗：${error.message}`, 'error'); return; }
      showToast('角色已更新');
    }
    await loadStaffRoles();
    setEditingStaffRole(null);
  };

  const deleteStaffRole = async (id: string, name: string) => {
    if (!window.confirm(`確定要刪除「${name}」角色嗎？`)) return;
    const { error } = await supabase.from('staff_roles').delete().eq('id', id);
    if (error) { showToast(`刪除失敗：${error.message}`, 'error'); return; }
    await loadStaffRoles();
    showToast(`已刪除「${name}」`);
  };

  const accentClass = 'bg-blue-600';
  const textAccentClass = 'text-blue-600';

  const updateCart = (product: Product, delta: number, e?: React.MouseEvent) => {
    if (e) { e.stopPropagation(); e.preventDefault(); }
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      const currentQty = existing?.qty || 0;
      const newQty = currentQty + delta;
      if (delta > 0 && product.purchaseLimit && newQty > product.purchaseLimit) {
        showToast(`已到限購上限（每單限買 ${product.purchaseLimit} 件）`, 'error');
        return prev;
      }
      if (!existing && delta > 0) return [...prev, { ...product, qty: 1 }];
      if (existing) {
        if (newQty <= 0) return prev.filter(item => item.id !== product.id);
        return prev.map(item => item.id === product.id ? { ...item, qty: newQty } : item);
      }
      return prev;
    });
  };

  // ── 一鍵回購：核心邏輯（通過安全 API 路由查詢，需要登入）──
  const handleReorderByPhone = useCallback(async (_phone: string) => {
    setReorderLoading(true);
    try {
      const memberId = localStorage.getItem('coolfood_member_id') || '';
      const sessionToken = localStorage.getItem('coolfood_session_token') || '';
      if (!memberId || !sessionToken) {
        setReorderNotification({ type: 'fail', successCount: 0, failedNames: ['請先登入再使用回購功能'] });
        setReorderLoading(false);
        setReorderModalOpen(false);
        return;
      }

      const res = await fetch('/api/customer-api', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-member-id': memberId, 'x-session-token': sessionToken },
        body: JSON.stringify({ action: 'reorder' }),
      });
      if (!res.ok) {
        setReorderNotification({ type: 'fail', successCount: 0, failedNames: ['系統查詢暫時出錯，請稍後再試。'] });
        setReorderLoading(false);
        setReorderModalOpen(false);
        return;
      }
      const json = await res.json();
      const lineItems: OrderLineItem[] = json.data || [];

      if (lineItems.length === 0) {
        setReorderNotification({ type: 'fail', successCount: 0, failedNames: ['未搵到您嘅歷史紀錄，不如去睇下我哋今日嘅精選？'] });
        setReorderLoading(false);
        setReorderModalOpen(false);
        return;
      }
      if (lineItems.length === 0) {
        setReorderNotification({ type: 'fail', successCount: 0, failedNames: ['上次訂單冇產品紀錄'] });
        setReorderLoading(false);
        setReorderModalOpen(false);
        return;
      }

      // 分類 successItems 與 failedItems
      let successCount = 0;
      const failedNames: string[] = [];
      const newCart: CartItem[] = [...cart];

      // Debug: 列出所有資訊以便診斷
      const productIds = products.map(p => ({ id: p.id, idType: typeof p.id, name: p.name, stock: p.stock, trackInventory: p.trackInventory }));
      console.log('[reorder] 商店產品清單:', productIds);
      console.log('[reorder] 歷史訂單 line_items:', JSON.stringify(lineItems));

      for (const li of lineItems) {
        // 寬鬆比對：同時嘗試嚴格匹配與 toString 匹配
        const liId = String(li.product_id ?? '');
        const prod = products.find(p => String(p.id) === liId);

        if (!prod) {
          console.warn(`[reorder] ❌ 找不到產品 — product_id="${liId}" (type=${typeof li.product_id})`);
          failedNames.push(li.name || liId);
          continue;
        }

        // 庫存判斷：若庫存管控關閉則視為全部有貨
        const hasStock = !inventoryOn || !prod.trackInventory || prod.stock === null || prod.stock === undefined || prod.stock > 0;
        if (!hasStock) {
          console.warn(`[reorder] ❌ 庫存不足 — "${prod.name}" stock=${prod.stock}, trackInventory=${prod.trackInventory}`);
          failedNames.push(li.name || prod.name);
          continue;
        }

        const existing = newCart.find(c => c.id === prod.id);
        const maxQty = (inventoryOn && prod.trackInventory && prod.stock > 0) ? prod.stock : 999;
        const wantQty = Math.min(li.qty || 1, maxQty);
        if (existing) {
          existing.qty = Math.min(existing.qty + wantQty, maxQty);
        } else {
          newCart.push({ ...prod, qty: wantQty });
        }
        successCount++;
        console.log(`[reorder] ✅ 已加入 "${prod.name}" x${wantQty}`);
      }

      setCart(newCart);
      setReorderModalOpen(false);
      setReorderPhone('');
      setReorderHint({ type: 'none', text: '' });

      // 顯示持久性通知（不跳轉、不自動消失）
      if (successCount > 0 && failedNames.length === 0) {
        setReorderNotification({ type: 'success', successCount, failedNames: [] });
      } else if (successCount > 0 && failedNames.length > 0) {
        setReorderNotification({ type: 'partial', successCount, failedNames });
      } else {
        setReorderNotification({ type: 'fail', successCount: 0, failedNames });
      }
    } catch {
      setReorderNotification({ type: 'fail', successCount: 0, failedNames: ['查詢失敗，請稍後再試'] });
      setReorderModalOpen(false);
    }
    setReorderLoading(false);
  }, [cart, products]);

  const handleReorderClick = useCallback(() => {
    setReorderNotification(null);
    if (user) {
      handleReorderByPhone(user.phoneNumber || '');
    } else {
      showToast('請先登入再使用回購功能', 'error');
    }
  }, [user, handleReorderByPhone]);

  // 訪客輸入電話後偵測是否為會員
  const handleReorderPhoneCheck = useCallback(async (phone: string) => {
    setReorderPhone(phone);
    if (phone.length < 8) { setReorderHint({ type: 'none', text: '' }); return; }
    try {
      const { data } = await supabase.from('members').select('id').eq('phone_number', phone).maybeSingle();
      if (data) {
        setReorderHint({ type: 'member', text: '👋 原來您係我哋會員！您可以先登入，買嘢更快之餘仲可以累積積分。(但唔登入都買得架)' });
      } else {
        setReorderHint({ type: 'guest', text: '💡 溫馨提示：登記做會員下次就唔使再輸入電話，仲可以儲分換禮品添！(但唔登記都買得架)' });
      }
    } catch {
      setReorderHint({ type: 'guest', text: '' });
    }
  }, []);

  const inventoryOn = siteConfig.inventoryEnforcementEnabled === true;
  const hideWholesalePrice = isWholesaleRoute && !user;

  // ── 定價上下文（兩層：訪客 / 會員）──
  const pricingTier: PricingTier = user ? 'member' : 'guest';

  const getPrice = (p: Product, qty: number = 1) => {
    if (isWholesaleRoute) {
      const linkedIng = ingredients.find(i => i.id === p.ingredientId);
      return getWholesaleUnitPrice(p, linkedIng, costItems, siteConfig.wholesalePricingRules!, user?.wholesalePriceTier, wholesalePriceOverrides);
    }
    return getEffectiveUnitPrice(p, qty, pricingTier);
  };
  
  const pricingData = useMemo(() => {
    let subtotal = 0;
    if (isWholesaleRoute) {
      cart.forEach(item => {
        const linkedIng = ingredients.find(i => i.id === item.ingredientId);
        const unitPrice = getWholesaleUnitPrice(item, linkedIng, costItems, siteConfig.wholesalePricingRules!, user?.wholesalePriceTier, wholesalePriceOverrides);
        const isByPiece = item.pricingMode === 'by_piece';
        const effectiveQty = isByPiece && item.packWeightLb ? item.packWeightLb * item.qty : item.qty;
        subtotal += unitPrice * effectiveQty;
      });
      subtotal = roundMoney(subtotal);
      const deliveryFee = 0;
      return {
        subtotal,
        deliveryFee,
        total: roundMoney(subtotal + deliveryFee),
        shippingThreshold: 0,
        shippingFee: 0,
        lockerThreshold: 0,
        lockerFee: 0,
        deliveryThreshold: 0,
        deliveryFee_delivery: 0,
      };
    }
    cart.forEach(item => {
      subtotal += getEffectiveUnitPrice(item, item.qty, pricingTier) * item.qty;
    });
    subtotal = roundMoney(subtotal);

    // Coupon discount (applied to subtotal)
    let couponDiscount = 0;
    if (selectedCoupon?.coupon && subtotal >= (selectedCoupon.coupon.minSpend || 0)) {
      const c = selectedCoupon.coupon;
      if (c.couponType === 'fixed_amount') {
        couponDiscount = roundMoney(Math.min(c.discountValue, subtotal));
      } else if (c.couponType === 'percentage') {
        couponDiscount = roundMoney(subtotal * c.discountValue / 100);
      }
    }
    const postCouponSubtotal = roundMoney(subtotal - couponDiscount);

    // Free delivery based on post-coupon subtotal
    const configKey = deliveryMethod === 'home' ? 'sf_delivery' : 'sf_locker';
    const sc = shippingConfigs[configKey] || SHIPPING_FALLBACKS[configKey];
    let deliveryFee = postCouponSubtotal >= sc.threshold ? 0 : sc.fee;
    if (selectedCoupon?.coupon?.couponType === 'free_delivery' && subtotal >= (selectedCoupon.coupon.minSpend || 0)) {
      deliveryFee = 0;
    }
    deliveryFee = roundMoney(deliveryFee);

    const lockerConfig = shippingConfigs['sf_locker'] || SHIPPING_FALLBACKS['sf_locker'];
    const deliveryConfig = shippingConfigs['sf_delivery'] || SHIPPING_FALLBACKS['sf_delivery'];

    return { 
      subtotal, 
      couponDiscount,
      postCouponSubtotal,
      deliveryFee, 
      total: roundMoney(postCouponSubtotal + deliveryFee),
      shippingThreshold: sc.threshold,
      shippingFee: sc.fee,
      lockerThreshold: lockerConfig.threshold,
      lockerFee: lockerConfig.fee,
      deliveryThreshold: deliveryConfig.threshold,
      deliveryFee_delivery: deliveryConfig.fee,
    };
  }, [cart, pricingTier, deliveryMethod, shippingConfigs, isWholesaleRoute, ingredients, costItems, siteConfig.wholesalePricingRules, user?.wholesalePriceTier, selectedCoupon]);

  // ── 湊單推薦產品（已過濾掉購物車中的商品）──
  const upsellProducts = useMemo(() => {
    if (upsellProductIds.length === 0) return [];
    const cartIds = new Set(cart.map(c => c.id));
    return products
      .filter(p => upsellProductIds.includes(p.id) && !cartIds.has(p.id) && p.stock > 0)
      .slice(0, 3);
  }, [upsellProductIds, products, cart]);

  const scrollToCategory = (id: string) => {
    setActiveCategory(id);
    const target = catRefs.current[id];
    if (target && listRef.current) {
      const containerTop = listRef.current.getBoundingClientRect().top;
      const targetTop = target.getBoundingClientRect().top;
      listRef.current.scrollTo({ top: targetTop - containerTop + listRef.current.scrollTop - 20, behavior: 'smooth' });
    }
  };

  const openAuthModal = (mode: 'login' | 'signup' = 'login') => {
    setAuthMode(mode);
    setAuthForm({ email: '', password: '', name: '', phone: '', companyName: '', businessType: '', branchCount: '1', storefrontPreparing: false });
    setShowAuthModal(true);
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    const input = authForm.email.trim();
    if (!input || !authForm.password) {
      showToast('請輸入電郵或電話及密碼', 'error');
      return;
    }
    try {
      const res = await fetch('/api/customer-auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'login', identifier: input, password: authForm.password, isWholesale: isWholesaleRoute }),
      });
      const json = await res.json();
      if (!res.ok) {
        showToast(json.error || '登入失敗', 'error');
        return;
      }
      const u = mapMemberRowToUser(json.user as SupabaseMemberRow);
      setUser(u);
      try {
        localStorage.setItem('coolfood_member_id', u.id);
        if (json.sessionToken) localStorage.setItem('coolfood_session_token', json.sessionToken);
        if (json.issuedAt) localStorage.setItem('coolfood_session_issued_at', String(json.issuedAt));
      } catch { /* ignore */ }
      setShowAuthModal(false);
      setAuthForm({ email: '', password: '', name: '', phone: '', companyName: '', businessType: '', branchCount: '1', storefrontPreparing: false });
      setView('profile');
      showToast('歡迎回來！');
    } catch {
      showToast('登入失敗，請稍後再試', 'error');
    }
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    const phone = authForm.phone.trim();
    if (!authForm.name.trim() || !phone || !authForm.password) {
      showToast('請填寫姓名、電話及密碼', 'error');
      return;
    }
    if (authForm.password.length < 6) {
      showToast('密碼至少 6 個字元', 'error');
      return;
    }
    if (isWholesaleRoute) {
      if (!authForm.companyName.trim()) {
        showToast('請填寫餐廳/公司名稱', 'error');
        return;
      }
      if (!wholesaleRegFiles.brDoc) {
        showToast('請上傳商業登記證 (BR) 副本', 'error');
        return;
      }
      if (!authForm.storefrontPreparing && !wholesaleRegFiles.storefrontPhoto) {
        showToast('請上傳餐廳門口相片，或選擇「正在籌備中」', 'error');
        return;
      }
    }
    try {
      setWholesaleRegUploading(true);
      let brDocUrl: string | null = null;
      let storefrontPhotoUrl: string | null = null;

      if (isWholesaleRoute && wholesaleRegFiles.brDoc) {
        const timestamp = Date.now();
        const brPath = `wholesale-registrations/${timestamp}/br-doc.webp`;
        brDocUrl = await uploadImage(wholesaleRegFiles.brDoc, brPath);
        if (wholesaleRegFiles.storefrontPhoto && !authForm.storefrontPreparing) {
          const photoPath = `wholesale-registrations/${timestamp}/storefront-photo.webp`;
          storefrontPhotoUrl = await uploadImage(wholesaleRegFiles.storefrontPhoto, photoPath);
        }
      }

      const res = await fetch('/api/customer-auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'register',
          name: authForm.name.trim(),
          phone,
          email: authForm.email.trim() || null,
          password: authForm.password,
          isWholesale: isWholesaleRoute,
          wholesaleBrand: isWholesaleRoute ? (isGHFoods ? 'GHFOODS' : 'COOLFOOD') : undefined,
          companyName: isWholesaleRoute ? authForm.companyName.trim() : undefined,
          businessType: isWholesaleRoute ? authForm.businessType || undefined : undefined,
          branchCount: isWholesaleRoute ? authForm.branchCount : undefined,
          brDocUrl: brDocUrl || undefined,
          storefrontPhotoUrl: storefrontPhotoUrl || undefined,
          storefrontPreparing: isWholesaleRoute ? authForm.storefrontPreparing : undefined,
        }),
      });
      const json = await res.json();
      if (!res.ok) {
        showToast(json.error || '註冊失敗', 'error');
        setWholesaleRegUploading(false);
        return;
      }
      const u = mapMemberRowToUser(json.user as SupabaseMemberRow);
      setUser(u);
      try {
        localStorage.setItem('coolfood_member_id', u.id);
        if (json.sessionToken) localStorage.setItem('coolfood_session_token', json.sessionToken);
        if (json.issuedAt) localStorage.setItem('coolfood_session_issued_at', String(json.issuedAt));
      } catch { /* ignore */ }
      setMembers(prev => [...prev, u]);
      setShowAuthModal(false);
      setAuthForm({ email: '', password: '', name: '', phone: '', companyName: '', businessType: '', branchCount: '1', storefrontPreparing: false });
      setWholesaleRegFiles({ brDoc: null, storefrontPhoto: null });
      setWholesaleRegUploading(false);
      setView('profile');
      showToast(isWholesaleRoute ? '註冊申請已提交，我們會盡快審核！' : '註冊成功！');
    } catch {
      setWholesaleRegUploading(false);
      showToast('註冊失敗，請稍後再試', 'error');
    }
  };

  const handleClaimLookup = async (e: React.FormEvent) => {
    e.preventDefault();
    const email = claimEmail.trim().toLowerCase();
    if (!email) { showToast('請輸入電郵地址', 'error'); return; }
    setClaimLoading(true);
    try {
      const res = await fetch('/api/claim-account', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'lookup', email }),
      });
      const json = await res.json();
      if (!res.ok) {
        showToast(json.error || '找不到此電郵的舊會員記錄', 'error');
        setClaimLoading(false);
        return;
      }
      setClaimData(json);
      if (json.hasRealPhone && json.existingPhone) setClaimPhone(json.existingPhone);
      setClaimStep('confirm');
    } catch {
      showToast('查詢失敗，請稍後再試', 'error');
    }
    setClaimLoading(false);
  };

  const handleClaimSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const phone = claimPhone.trim();
    if (!phone || phone.length < 4) { showToast('請輸入有效的電話號碼', 'error'); return; }
    if (!claimPassword || claimPassword.length < 6) { showToast('密碼至少 6 個字元', 'error'); return; }
    setClaimLoading(true);
    try {
      const res = await fetch('/api/claim-account', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'claim', email: claimEmail.trim().toLowerCase(), phone, password: claimPassword }),
      });
      const json = await res.json();
      if (!res.ok) {
        showToast(json.error || '啟用失敗', 'error');
        setClaimLoading(false);
        return;
      }
      const u = mapMemberRowToUser(json.user as SupabaseMemberRow);
      setUser(u);
      try {
        localStorage.setItem('coolfood_member_id', u.id);
        if (json.sessionToken) localStorage.setItem('coolfood_session_token', json.sessionToken);
        if (json.issuedAt) localStorage.setItem('coolfood_session_issued_at', String(json.issuedAt));
      } catch { /* ignore */ }
      setClaimStep('success');
      showToast('帳戶啟用成功！歡迎回來！');
      setTimeout(() => {
        setClaimStep('idle');
        setClaimEmail('');
        setClaimPhone('');
        setClaimPassword('');
        setClaimData(null);
        setView('profile');
      }, 2000);
    } catch {
      showToast('啟用失敗，請稍後再試', 'error');
    }
    setClaimLoading(false);
  };

  const persistOwnMemberAddresses = async (ownerId: string, addresses: UserAddress[]): Promise<boolean> => {
    if (!user || user.id !== ownerId || isAdminRoute) return false;
    try {
      const storedMemberId = localStorage.getItem('coolfood_member_id') || '';
      const sessionToken = localStorage.getItem('coolfood_session_token') || '';
      if (!sessionToken) {
        showToast('登入已失效，請重新登入再試', 'error');
        return false;
      }
      // Keep local member id aligned with the active profile id.
      if (storedMemberId !== ownerId) {
        try { localStorage.setItem('coolfood_member_id', ownerId); } catch { /* ignore */ }
      }
      const defaultAddr = addresses.find(a => a.isDefault) || addresses[0];
      const deliveryAddress = defaultAddr ? formatAddressLine(defaultAddr) : null;
      const res = await fetch('/api/customer-api', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-member-id': ownerId,
          'x-session-token': sessionToken,
        },
        body: JSON.stringify({ action: 'save-addresses', addresses, deliveryAddress }),
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok || !json?.user) {
        showToast(json?.error || '地址儲存失敗，請重新登入後再試', 'error');
        return false;
      }
      const mapped = mapMemberRowToUser(json.user as SupabaseMemberRow);
      setMembers(prev => {
        const idx = prev.findIndex(m => m.id === mapped.id);
        if (idx === -1) return [...prev, mapped];
        const next = [...prev];
        next[idx] = mapped;
        return next;
      });
      setUser(prev => (prev && prev.id === mapped.id ? mapped : prev));
      if (editingMember && editingMember.id === mapped.id) setEditingMember(mapped);
      return true;
    } catch {
      showToast('地址儲存失敗，請稍後再試', 'error');
      return false;
    }
  };

  const saveMemberAddresses = async (baseMember: UserType, addresses: UserAddress[]): Promise<boolean> => {
    const nextMember = { ...baseMember, addresses };
    if (!isAdminRoute && user?.id === baseMember.id) {
      return persistOwnMemberAddresses(baseMember.id, addresses);
    }
    return upsertMember(nextMember);
  };

  const handleSetDefaultAddress = async (ownerId: string, addressId: string) => {
    const updateMember = (m: UserType) => {
      if (m.id !== ownerId) return m;
      const addresses = m.addresses?.map(a => ({ ...a, isDefault: a.id === addressId })) || [];
      return { ...m, addresses };
    };
    const baseMember = members.find(m => m.id === ownerId) || (user && user.id === ownerId ? user : null);
    if (!baseMember) {
      showToast('會員資料不存在', 'error');
      return;
    }
    const updatedMember = updateMember(baseMember);
    const ok = await saveMemberAddresses(updatedMember, updatedMember.addresses || []);
    if (ok) showToast('已設為預設地址');
  };

  const handleSaveAddress = async (ownerId: string, address: UserAddress, isNew: boolean, setAsDefault?: boolean) => {
    const updateMember = (m: UserType) => {
      if (m.id !== ownerId) return m;
      let addresses = [...(m.addresses || [])];
      if (isNew) {
        const newAddr = setAsDefault ? { ...address, isDefault: true } : { ...address, isDefault: addresses.length === 0 };
        if (setAsDefault) addresses = addresses.map(a => ({ ...a, isDefault: false }));
        addresses.push(newAddr);
      } else {
        addresses = addresses.map(a => a.id === address.id ? address : a);
      }
      return { ...m, addresses };
    };
    const baseMember = members.find(m => m.id === ownerId) || (user && user.id === ownerId ? user : null);
    if (!baseMember) {
      showToast('會員資料不存在', 'error');
      return;
    }
    const updatedMember = updateMember(baseMember);
    const ok = await saveMemberAddresses(updatedMember, updatedMember.addresses || []);
    if (ok) {
      setAddressEditor(null);
      showToast(isNew ? '地址已新增' : '地址已更新');
    }
  };

  const handleDeleteAddress = async (ownerId: string, addressId: string) => {
    const baseMember = members.find(m => m.id === ownerId) || (user && user.id === ownerId ? user : null);
    if (!baseMember) {
      showToast('會員資料不存在', 'error');
      return;
    }
    const addresses = (baseMember.addresses || []).filter(a => a.id !== addressId);
    const wasDefault = baseMember.addresses?.find(a => a.id === addressId)?.isDefault;
    const nextAddresses = wasDefault && addresses.length > 0
      ? addresses.map((a, i) => ({ ...a, isDefault: i === 0 }))
      : addresses;
    const ok = await saveMemberAddresses(baseMember, nextAddresses);
    if (ok) showToast('地址已刪除');
  };

  const getOrderDbId = (orderId: string) => {
    if (orderId.startsWith('ORD-')) {
      const parsed = Number(orderId.replace('ORD-', ''));
      return Number.isNaN(parsed) ? null : parsed;
    }
    const parsed = Number(orderId);
    return Number.isNaN(parsed) ? null : parsed;
  };

  const handleSchemaError = (error: { message?: string } | null, tableName: string) => {
    const message = error?.message || '';
    if (message.includes('schema cache') || message.includes(`public.${tableName}`)) {
      const hints: Record<string, string> = {
        members: '請在 Supabase SQL Editor 執行 supabase-members-schema.sql 建立 members 表',
        products: '請在 Supabase SQL Editor 執行 supabase-products-schema.sql 建立 products 表',
        categories: '請在 Supabase SQL Editor 執行 supabase-categories-schema.sql 建立 categories 表',
        orders: '請在 Supabase SQL Editor 執行 supabase-orders-schema.sql 建立 orders 表',
        slideshow: '請在 Supabase SQL Editor 執行 supabase-slideshow-schema.sql 建立 slideshow 表',
      };
      const hint = hints[tableName] || `請先在 Supabase 建立 ${tableName} 表`;
      showToast(hint, 'error');
      return true;
    }
    return false;
  };

  const upsertProduct = async (product: Product) => {
    const { data, error } = await supabase
      .from('products')
      .upsert(mapProductToRow(product))
      .select()
      .single();
    if (error || !data) {
      if (!handleSchemaError(error, 'products')) {
        showToast(error?.message || '產品保存失敗', 'error');
      }
      return;
    }
    const mapped = mapProductRowToProduct(data);
    setProducts(prev => {
      const idx = prev.findIndex(p => p.id === mapped.id);
      if (idx === -1) return [...prev, mapped];
      const next = [...prev];
      next[idx] = mapped;
      return next;
    });
  };

  const upsertProductGroup = async (group: ProductGroup): Promise<ProductGroup | null> => {
    const { data, error } = await supabase
      .from('product_groups')
      .upsert(mapProductGroupToRow(group))
      .select()
      .single();
    if (error || !data) {
      showToast(error?.message || '群組保存失敗', 'error');
      return null;
    }
    const mapped = mapProductGroupRow(data);
    setProductGroups(prev => {
      const idx = prev.findIndex(g => g.id === mapped.id);
      if (idx === -1) return [...prev, mapped];
      const next = [...prev];
      next[idx] = mapped;
      return next;
    });
    return mapped;
  };

  const upsertProducts = async (items: Product[]) => {
    if (items.length === 0) return false;
    const { data, error } = await supabase
      .from('products')
      .upsert(items.map(mapProductToRow))
      .select();
    if (error || !data) {
      if (!handleSchemaError(error, 'products')) {
        showToast(error?.message || '產品批量保存失敗', 'error');
      }
      return false;
    }
    // Merge upserted products into existing state instead of replacing everything
    const upsertedMap = new Map(data.map(mapProductRowToProduct).map(p => [p.id, p]));
    setProducts(prev => {
      const merged = prev.map(p => upsertedMap.has(p.id) ? upsertedMap.get(p.id)! : p);
      const existingIds = new Set(prev.map(p => p.id));
      const brandNew = Array.from(upsertedMap.values()).filter(p => !existingIds.has(p.id));
      return [...merged, ...brandNew];
    });
    return true;
  };

  const deleteProduct = async (productId: string) => {
    const { error } = await supabase.from('products').delete().eq('id', productId);
    if (error) {
      if (!handleSchemaError(error, 'products')) {
        showToast(error.message || '產品刪除失敗', 'error');
      }
      return;
    }
    setProducts(prev => prev.filter(p => p.id !== productId));
    showToast('產品已刪除');
  };

  const upsertCategory = async (category: Category) => {
    const { data, error } = await supabase
      .from('categories')
      .upsert(mapCategoryToRow(category))
      .select()
      .single();
    if (error || !data) {
      if (!handleSchemaError(error, 'categories')) {
        showToast(error?.message || '分類保存失敗', 'error');
      }
      return;
    }
    const mapped = mapCategoryRowToCategory(data);
    setCategories(prev => {
      const idx = prev.findIndex(c => c.id === mapped.id);
      if (idx === -1) return [...prev, mapped].sort((a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0));
      const next = [...prev];
      next[idx] = mapped;
      return next.sort((a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0));
    });
  };

  const reorderProductCategories = async (fromIdx: number, toIdx: number) => {
    if (fromIdx === toIdx) return;
    const reordered = [...categories];
    const [moved] = reordered.splice(fromIdx, 1);
    reordered.splice(toIdx, 0, moved);
    const updated = reordered.map((c, i) => ({ ...c, sortOrder: i }));
    setCategories(updated);
    for (const cat of updated) {
      await supabase.from('categories').update({ sort_order: cat.sortOrder }).eq('id', cat.id);
    }
  };

  const deleteCategory = async (categoryId: string) => {
    const { error } = await supabase.from('categories').delete().eq('id', categoryId);
    if (error) {
      if (!handleSchemaError(error, 'categories')) {
        showToast(error.message || '分類刪除失敗', 'error');
      }
      return;
    }
    setCategories(prev => prev.filter(c => c.id !== categoryId));
    showToast('分類已刪除');
  };

  // ── 原材料類別 CRUD ──
  const upsertIngredientCategory = async (cat: IngredientCategory) => {
    const { error } = await supabase.from('ingredient_categories').upsert({
      id: cat.id, name: cat.name, emoji: cat.emoji, sort_order: cat.sortOrder,
    });
    if (error) { showToast(`儲存失敗：${error.message}`, 'error'); return; }
    setIngredientCategoryList(prev => {
      const exists = prev.find(x => x.id === cat.id);
      const next = exists ? prev.map(x => x.id === cat.id ? cat : x) : [...prev, cat];
      return next.sort((a, b) => a.sortOrder - b.sortOrder);
    });
    showToast(`類別「${cat.name}」已儲存`);
    setEditingIngredientCategory(null);
  };

  const deleteIngredientCategory = async (id: string) => {
    const cat = ingredientCategoryList.find(c => c.id === id);
    const { error } = await supabase.from('ingredient_categories').delete().eq('id', id);
    if (error) { showToast(`刪除失敗：${error.message}`, 'error'); return; }
    setIngredientCategoryList(prev => prev.filter(x => x.id !== id));
    showToast(`類別「${cat?.name}」已刪除`);
  };

  const reorderIngredientCategories = async (fromIdx: number, toIdx: number) => {
    if (fromIdx === toIdx) return;
    const reordered = [...ingredientCategoryList];
    const [moved] = reordered.splice(fromIdx, 1);
    reordered.splice(toIdx, 0, moved);
    const updated = reordered.map((c, i) => ({ ...c, sortOrder: i }));
    setIngredientCategoryList(updated);
    for (const cat of updated) {
      await supabase.from('ingredient_categories').update({ sort_order: cat.sortOrder }).eq('id', cat.id);
    }
  };

  // ── 食譜 CRUD ──
  const upsertRecipe = async (recipe: StandaloneRecipe) => {
    const row = mapRecipeToRow(recipe);
    const { data, error } = await supabase
      .from('recipes')
      .upsert(row)
      .select()
      .single();
    if (error || !data) {
      showToast(error?.message || t.recipes.recipeSaveFailed, 'error');
      return;
    }
    // Sync recipe_product_links
    await supabase.from('recipe_product_links').delete().eq('recipe_id', recipe.id);
    if (recipe.linkedProductIds.length > 0) {
      await supabase.from('recipe_product_links').insert(
        recipe.linkedProductIds.map(pid => ({ recipe_id: recipe.id, product_id: pid }))
      );
    }
    const mapped = mapRecipeRowToRecipe(data as SupabaseRecipeRow, recipe.linkedProductIds);
    setRecipes(prev => {
      const idx = prev.findIndex(r => r.id === mapped.id);
      if (idx === -1) return [mapped, ...prev];
      const next = [...prev];
      next[idx] = mapped;
      return next;
    });
    showToast(t.recipes.recipeSaved);
  };

  const generateAndUploadRecipeImage = async (recipeId: string, title: string, description: string): Promise<string | null> => {
    try {
      const res = await fetch('/api/generate-recipe', {
        method: 'POST',
        headers: buildAdminHeaders(adminUser),
        body: JSON.stringify({ action: 'generate-recipe-image', payload: { title, description } }),
      });
      const json = await res.json();
      if (!json.ok || !json.data?.base64Image) return null;

      const binary = atob(json.data.base64Image);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
      const blob = new Blob([bytes], { type: 'image/png' });

      const path = `recipes/${recipeId}/ai-cover.png`;
      const { error } = await supabase.storage.from('media').upload(path, blob, { cacheControl: '3600', upsert: true, contentType: 'image/png' });
      if (error) return null;

      const { data: urlData } = supabase.storage.from('media').getPublicUrl(path);
      return urlData.publicUrl;
    } catch {
      return null;
    }
  };

  const deleteRecipe = async (recipeId: string) => {
    const { error } = await supabase.from('recipes').delete().eq('id', recipeId);
    if (error) {
      showToast(error.message || t.recipes.recipeDeleteFailed, 'error');
      return;
    }
    setRecipes(prev => prev.filter(r => r.id !== recipeId));
    showToast(t.recipes.recipeDeleted);
  };

  const getRecipesForProduct = useCallback((productId: string): StandaloneRecipe[] => {
    return recipes.filter(r => r.linkedProductIds.includes(productId));
  }, [recipes]);

  const newEmptyRecipe = (): StandaloneRecipe => ({
    id: crypto.randomUUID(),
    title: '',
    description: '',
    mediaUrl: '',
    mediaType: 'image',
    cookingTime: 0,
    servingSize: '1-2人份',
    tags: [],
    categoryIds: [],
    ingredientsRaw: [],
    steps: [{ order: 1, content: '' }],
    linkedProductIds: [],
  });

  const COMMON_INGREDIENTS = ['薑', '蔥', '蒜', '洋蔥', '豉油', '蠔油', '生粉', '油', '糖', '鹽', '白胡椒', '黑胡椒', '雞粉', '料酒', '醋', '麻油'];
  const SERVING_SIZES = ['1-2人份', '3-4人份', '5-6人份', '7-8人份'];

  const upsertRecipeCategory = async (cat: RecipeCategory) => {
    const { data, error } = await supabase
      .from('recipe_categories')
      .upsert({ id: cat.id, name: cat.name, icon: cat.icon, sort_order: cat.sortOrder, category_type: cat.categoryType ?? 'method' })
      .select()
      .single();
    if (error || !data) { showToast(error?.message || '分類保存失敗', 'error'); return; }
    const mapped = mapRecipeCategoryRow(data);
    setRecipeCategories(prev => {
      const idx = prev.findIndex(c => c.id === mapped.id);
      if (idx === -1) return [...prev, mapped].sort((a, b) => a.sortOrder - b.sortOrder);
      const next = [...prev]; next[idx] = mapped; return next;
    });
    showToast('食譜分類已保存');
  };

  const deleteRecipeCategory = async (catId: string) => {
    const { error } = await supabase.from('recipe_categories').delete().eq('id', catId);
    if (error) { showToast(error.message || '分類刪除失敗', 'error'); return; }
    setRecipeCategories(prev => prev.filter(c => c.id !== catId));
    showToast('食譜分類已刪除');
  };

  const reorderRecipeCategories = async (type: 'method' | 'meat', fromIdx: number, toIdx: number) => {
    if (fromIdx === toIdx) return;
    const typeCats = recipeCategories.filter(c => c.categoryType === type);
    const reordered = [...typeCats];
    const [moved] = reordered.splice(fromIdx, 1);
    reordered.splice(toIdx, 0, moved);
    const updated = reordered.map((c, i) => ({ ...c, sortOrder: i }));
    setRecipeCategories(prev => {
      const others = prev.filter(c => c.categoryType !== type);
      return [...others, ...updated].sort((a, b) => a.sortOrder - b.sortOrder);
    });
    for (const cat of updated) {
      await supabase.from('recipe_categories').update({ sort_order: cat.sortOrder }).eq('id', cat.id);
    }
  };

  const generateAiRecipe = async (recipe: StandaloneRecipe, userInstruction?: string) => {
    const title = recipe.title.trim();
    const linkedNames = recipe.linkedProductIds.map(pid => products.find(x => x.id === pid)?.name).filter(Boolean);
    if (!title && linkedNames.length === 0) { showToast('請先輸入食譜名稱或選擇關聯產品', 'error'); return; }
    setAiRecipeLoading(true);
    try {
      const catMap = recipeCategories.map(c => ({ id: c.id, name: c.name }));
      const res = await fetch('/api/generate-recipe', {
        method: 'POST', headers: buildAdminHeaders(adminUser),
        body: JSON.stringify({ action: 'single-recipe', payload: { title, linkedProductNames: linkedNames, existingTitles: recipes.map(r => r.title).filter(Boolean), categoryIds: catMap.map(c => c.id), categoryMap: catMap, userInstruction: userInstruction || undefined } }),
      });
      const json = await res.json();
      if (!json.ok) throw new Error(json.error || 'AI error');
      const parsed = json.data;
      const chefTip = typeof parsed.chef_tip === 'string' ? parsed.chef_tip : '';
      const stepsWithTip = Array.isArray(parsed.steps) ? parsed.steps : recipe.steps;
      if (chefTip && stepsWithTip.length > 0) {
        stepsWithTip.push({ order: stepsWithTip.length + 1, content: `💡 大廚小貼士：${chefTip}` });
      }
      const updated: StandaloneRecipe = {
        ...recipe,
        title: parsed.title || recipe.title,
        description: parsed.description || recipe.description,
        cookingTime: parsed.cooking_time || recipe.cookingTime,
        servingSize: parsed.serving_size || recipe.servingSize,
        ingredientsRaw: Array.isArray(parsed.ingredients) ? parsed.ingredients : recipe.ingredientsRaw,
        steps: stepsWithTip,
        categoryIds: Array.isArray(parsed.category_ids) ? parsed.category_ids.filter((c: string) => recipeCategories.some(rc => rc.id === c)) : recipe.categoryIds,
      };
      setEditingRecipe(updated);
      showToast('AI 已生成食譜內容');
    } catch {
      showToast('AI 生成失敗，請稍後重試', 'error');
    }
    setAiRecipeLoading(false);
  };

  const openAiRecipePrompt = (recipe: StandaloneRecipe) => {
    setAiPromptModal({
      title: 'AI 寫食譜',
      placeholder: '例如：請幫我寫一份氣炸鍋食譜、用雞翼做一道簡單小菜...',
      onConfirm: (instruction) => generateAiRecipe(recipe, instruction),
    });
  };

  const generateProductField = async (fieldType: string, applyFn: (text: string) => void) => {
    if (!editingProduct?.name.trim()) { showToast('請先填寫產品名稱', 'error'); return; }
    setAiFieldLoading(fieldType);
    try {
      const res = await fetch('/api/generate-recipe', {
        method: 'POST', headers: buildAdminHeaders(adminUser),
        body: JSON.stringify({ action: 'generate-field', payload: { fieldType, productName: editingProduct.name, productDescription: editingProduct.description || '' } }),
      });
      const json = await res.json();
      if (!json.ok) throw new Error(json.error || 'AI error');
      const text = json.data?.text || '';
      if (text) { applyFn(text); showToast('AI 已生成'); }
      else showToast('AI 無法生成', 'error');
    } catch { showToast('AI 生成失敗', 'error'); }
    setAiFieldLoading(null);
  };

  const upsertSlideshowItem = async (item: SlideshowItem) => {
    const { data, error } = await supabase
      .from('slideshow')
      .upsert(mapSlideshowItemToRow(item))
      .select()
      .single();
    if (error || !data) {
      if (!handleSchemaError(error, 'slideshow')) {
        showToast(error?.message || '廣告保存失敗', 'error');
      }
      return;
    }
    const mapped = mapSlideshowRowToItem(data);
    setSlideshowItems(prev => {
      const idx = prev.findIndex(s => s.id === mapped.id);
      if (idx === -1) return [...prev, mapped].sort((a, b) => a.sortOrder - b.sortOrder);
      const next = [...prev];
      next[idx] = mapped;
      return next.sort((a, b) => a.sortOrder - b.sortOrder);
    });
    showToast('廣告已保存');
  };

  const deleteSlideshowItem = async (id: string) => {
    const { error } = await supabase.from('slideshow').delete().eq('id', id);
    if (error) {
      if (!handleSchemaError(error, 'slideshow')) {
        showToast(error.message || '廣告刪除失敗', 'error');
      }
      return;
    }
    setSlideshowItems(prev => prev.filter(s => s.id !== id));
    showToast('廣告已刪除');
  };

  const MEMBER_SAFE_COLUMNS = 'id, name, email, phone_number, points, tier, role, admin_permissions, member_type, wholesale_price_tier, wholesale_status, wholesale_brand, company_name, business_type, branch_count, br_doc_url, storefront_photo_url, storefront_preparing, delivery_address, br_update_required, addresses, client_code, fax, district, route_id, credit_limit, parent_member_id, salesperson_id, payment_terms_days, payment_terms_type, discount_percent, wholesale_notes, is_wholesale_active';

  const friendlyMemberError = (error: { message?: string; code?: string; details?: string } | null): string => {
    const msg = error?.message || '';
    const details = error?.details || '';
    if (msg.includes('members_phone_unique') || details.includes('phone_number'))
      return '此電話號碼已被其他會員使用，請使用其他號碼';
    if (msg.includes('members_email_unique') || details.includes('email'))
      return '此電郵地址已被其他會員使用';
    if (msg.includes('duplicate key') || msg.includes('unique constraint') || error?.code === '23505')
      return '此會員資料與現有記錄衝突，請檢查電話或電郵是否重複';
    return msg || '會員保存失敗';
  };

  const upsertMember = async (member: UserType, passwordHash?: string | null): Promise<boolean> => {
    const { data, error } = await supabase
      .from('members')
      .upsert(mapUserToMemberRow(member, passwordHash))
      .select(MEMBER_SAFE_COLUMNS)
      .single();
    if (error || !data) {
      if (!handleSchemaError(error, 'members')) {
        showToast(friendlyMemberError(error), 'error');
      }
      return false;
    }
    const mapped = mapMemberRowToUser(data);
    setMembers(prev => {
      const idx = prev.findIndex(m => m.id === mapped.id);
      if (idx === -1) return [...prev, mapped];
      const next = [...prev];
      next[idx] = mapped;
      return next;
    });
    if (user && user.id === mapped.id) setUser(mapped);
    if (editingMember && editingMember.id === mapped.id) setEditingMember(mapped);
    return true;
  };

  const updateOrderFields = async (orderId: string, fields: Partial<SupabaseOrderRow>) => {
    const dbId = getOrderDbId(orderId);
    if (dbId === null) {
      showToast('訂單編號無效', 'error');
      return;
    }
    const { data, error } = await supabase
      .from('orders')
      .update(fields)
      .eq('id', dbId)
      .select()
      .single();
    if (error || !data) {
      showToast(error?.message || '訂單更新失敗', 'error');
      return;
    }
    setInspectingOrderDetails(data as SupabaseOrderRow);
    const mapped = mapOrderRowToOrder(data);
    setOrders(prev => {
      const idx = prev.findIndex(o => o.id === mapped.id);
      if (idx === -1) return prev;
      const next = [...prev];
      next[idx] = { ...next[idx], ...mapped };
      return next;
    });
  };

  const handleTrackOrder = (order: Order) => {
    if (!order.trackingNumber) {
      showToast('沒有物流編號', 'error');
      return;
    }
    const url = `https://www.sf-express.com/hk/en/dynamic_function/waybill/?billno=${order.trackingNumber}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  // ========== Batch Order Operations ==========

  const normalizeSfDeliveryMethod = (rawMethod: string | null | undefined): 'sf_delivery' | 'sf_locker' | 'own_van' | 'unknown' => {
    const method = String(rawMethod || '').trim().toLowerCase();
    if (method === 'sf_delivery' || method === 'home') return 'sf_delivery';
    if (method === 'sf_locker') return 'sf_locker';
    if (method === 'own_van') return 'own_van';
    return 'unknown';
  };

  /** PAID tab → 打印執貨單 (unified A5 picking slip) + auto transition to PREPARING */
  const handlePrintPickingList = async () => {
    if (selectedOrderIds.size === 0) return;
    setBatchProcessing(true);
    try {
      const eligibleOrders = orders.filter(o => selectedOrderIds.has(o.id) && o.status === OrderStatus.PAID);
      if (eligibleOrders.length === 0) {
        showToast('沒有符合條件的訂單（僅限「已付款」狀態）', 'error');
        setBatchProcessing(false);
        return;
      }
      const dbIds = eligibleOrders.map(o => getOrderDbId(o.id)).filter((id): id is number => id !== null);
      const { data, error } = await supabase.from('orders').select('*').in('id', dbIds);
      if (error || !data) { showToast('載入訂單資料失敗', 'error'); setBatchProcessing(false); return; }

      const orderRows = data as SupabaseOrderRow[];

      // Batch-fetch client codes and route names for wholesale orders
      const wcIds = [...new Set(orderRows.map(r => r.wholesale_client_id).filter(Boolean))] as string[];
      const rtIds = [...new Set(orderRows.map(r => r.route_id).filter(Boolean))] as string[];
      let clientMap: Record<string, string> = {};
      let routeMap: Record<string, string> = {};
      if (wcIds.length) {
        const { data: cl } = await supabase.from('members').select('id, client_code').in('id', wcIds);
        if (cl) clientMap = Object.fromEntries(cl.map((c: any) => [c.id, c.client_code || '']));
      }
      if (rtIds.length) {
        const { data: rt } = await supabase.from('delivery_routes').select('id, name').in('id', rtIds);
        if (rt) routeMap = Object.fromEntries(rt.map((r: any) => [r.id, r.name || '']));
      }

      const now = new Date();
      const ts = `${now.toLocaleDateString('zh-TW')} ${now.toLocaleTimeString('zh-TW', { hour: '2-digit', minute: '2-digit' })}`;

      const pickingOrders: PickingOrderData[] = orderRows.map(row => {
        const oid = typeof row.id === 'number' ? `ORD-${row.id}` : String(row.id);
        const cc = row.client_code || clientMap[row.wholesale_client_id || ''] || '';
        const rn = routeMap[row.route_id || ''] || '';
        return {
          orderId: oid,
          customerName: row.customer_name,
          clientCode: cc,
          phone: row.customer_phone || '',
          address: [row.delivery_district, row.delivery_address].filter(Boolean).join(' ') || '',
          deliveryDate: row.delivery_date || '',
          routeName: rn,
          businessLabel: getBusinessLabel(row.order_type, row.wholesale_brand),
          timestamp: ts,
          items: (row.line_items || []).map(item => ({
            productName: item.name,
            qty: item.qty,
            unit: item.unit || '',
            processingType: item.processing_type_name,
            processingSpec: item.processing_spec,
            lineNote: item.line_note,
          })),
        };
      });

      const html = buildPickingSlipHtml(pickingOrders);
      const printWindow = window.open('', '_blank');
      if (!printWindow) { showToast('無法開啟列印視窗，請允許彈出視窗', 'error'); setBatchProcessing(false); return; }
      printWindow.document.write(html);
      printWindow.document.close();
      printWindow.focus();
      setTimeout(() => printWindow.print(), 300);

      const { error: updateErr } = await supabase.from('orders').update({ status: 'preparing' }).in('id', dbIds);
      if (updateErr) {
        showToast(`執貨單已生成，但狀態更新失敗：${updateErr.message}`, 'error');
      } else {
        showToast(`已生成 ${pickingOrders.length} 張執貨單，訂單已轉為「備貨中」`);
      }
      await fetchOrders();
      setSelectedOrderIds(new Set());
    } catch (e) {
      showToast(`列印失敗：${e instanceof Error ? e.message : String(e)}`, 'error');
    }
    setBatchProcessing(false);
  };

  /** PREPARING tab → 打印大執貨表 (aggregate picking list, split by business type) */
  const handlePrintAggregateList = async () => {
    if (selectedOrderIds.size === 0) return;
    setBatchProcessing(true);
    try {
      const dbIds = Array.from(selectedOrderIds).map(id => getOrderDbId(id)).filter((id): id is number => id !== null);
      const { data, error } = await supabase.from('orders').select('*').in('id', dbIds);
      if (error || !data) { showToast('載入訂單資料失敗', 'error'); setBatchProcessing(false); return; }

      const rows = data as SupabaseOrderRow[];
      const today = new Date().toLocaleDateString('zh-HK');

      // Group orders by business type
      const grouped: Record<string, SupabaseOrderRow[]> = {};
      for (const row of rows) {
        const label = getBusinessLabel(row.order_type, row.wholesale_brand);
        if (!grouped[label]) grouped[label] = [];
        grouped[label].push(row);
      }

      // Build one aggregate section per business type
      const sections: AggregatePickingData[] = Object.entries(grouped).map(([label, bizOrders]) => {
        const agg: Record<string, { name: string; qty: number; unit?: string }> = {};
        for (const row of bizOrders) {
          for (const item of row.line_items || []) {
            const procTag = item.processing_type_name && item.processing_type_name !== '原件'
              ? `【${item.processing_type_name}${item.processing_spec ? ' ' + item.processing_spec : ''}】`
              : '';
            const displayName = procTag ? `${procTag} ${item.name}` : item.name;
            const key = `${item.product_id}_${item.name}_${procTag}`;
            if (agg[key]) { agg[key].qty += item.qty; }
            else { agg[key] = { name: displayName, qty: item.qty, unit: item.unit || '' }; }
          }
        }
        return {
          businessLabel: label,
          date: today,
          orderCount: bizOrders.length,
          items: Object.values(agg).sort((a, b) => b.qty - a.qty),
          orderIds: bizOrders.map(r => typeof r.id === 'number' ? `ORD-${r.id}` : String(r.id)),
        };
      });

      const html = buildAggregatePickingHtml(sections);
      const printWindow = window.open('', '_blank');
      if (!printWindow) { showToast('無法開啟列印視窗，請允許彈出視窗', 'error'); setBatchProcessing(false); return; }
      printWindow.document.write(html);
      printWindow.document.close();
      printWindow.focus();
      setTimeout(() => printWindow.print(), 300);
    } catch (e) {
      showToast(`列印失敗：${e instanceof Error ? e.message : String(e)}`, 'error');
    }
    setBatchProcessing(false);
  };

  /** Generate printable invoices for selected orders */
  const handlePrintInvoices = async () => {
    if (selectedOrderIds.size === 0) return;
    setBatchProcessing(true);
    try {
      const dbIds = Array.from(selectedOrderIds).map(id => getOrderDbId(id)).filter((id): id is number => id !== null);
      const { data, error } = await supabase.from('orders').select('*').in('id', dbIds);
      if (error || !data) { showToast('載入訂單資料失敗', 'error'); setBatchProcessing(false); return; }

      const rows = data as SupabaseOrderRow[];
      const wcIds = [...new Set(rows.map(r => r.wholesale_client_id).filter(Boolean))] as string[];
      let clientMap: Record<string, string> = {};
      if (wcIds.length) {
        const { data: cl } = await supabase.from('members').select('id, client_code').in('id', wcIds);
        if (cl) clientMap = Object.fromEntries(cl.map((c: any) => [c.id, c.client_code || '']));
      }

      const today = new Date().toISOString().slice(0, 10);
      const invoices: InvoiceOrderData[] = rows.map(row => {
        const oid = typeof row.id === 'number' ? `ORD-${row.id}` : String(row.id);
        const invNum = `INV-${typeof row.id === 'number' ? row.id : Date.now()}`;
        const cc = row.client_code || clientMap[row.wholesale_client_id || ''] || '';
        return {
          invoiceNumber: invNum,
          orderId: oid,
          customerName: row.customer_name,
          clientCode: cc,
          phone: row.customer_phone || '',
          address: [row.delivery_district, row.delivery_address].filter(Boolean).join(' ') || '',
          invoiceDate: today,
          businessLabel: getBusinessLabel(row.order_type, row.wholesale_brand),
          items: (row.line_items || []).map(item => {
            const procTag = item.processing_type_name && item.processing_type_name !== '原件'
              ? `【${item.processing_type_name}${item.processing_spec ? ' ' + item.processing_spec : ''}】`
              : '';
            return { name: item.name, qty: item.qty, unit: item.unit || '', unitPrice: item.unit_price, lineTotal: item.line_total, processingTag: procTag || undefined };
          }),
          subtotal: row.subtotal ?? row.total,
          deliveryFee: row.delivery_fee ?? 0,
          total: row.total,
        };
      });

      const html = buildInvoiceHtml(invoices);
      const printWindow = window.open('', '_blank');
      if (!printWindow) { showToast('無法開啟列印視窗', 'error'); setBatchProcessing(false); return; }
      printWindow.document.write(html);
      printWindow.document.close();
      printWindow.focus();
      setTimeout(() => printWindow.print(), 300);
      showToast(`已生成 ${invoices.length} 張發票`);
    } catch (e) {
      showToast(`列印失敗：${e instanceof Error ? e.message : String(e)}`, 'error');
    }
    setBatchProcessing(false);
  };

  const printSfLabelsFromRows = async (orderRows: SupabaseOrderRow[], options?: { showSummaryToast?: boolean }) => {
    if (orderRows.length === 0) return { total: 0, imageCount: 0, failedCount: 0 };
    const showSummaryToast = options?.showSummaryToast ?? true;

    const labelResults: {
      orderId: string;
      labelImage: string | null;
      labelPdfUrl: string | null;
      labelPdfBase64: string | null;
      waybillNo: string | null;
      error?: string;
    }[] = [];
    for (const row of orderRows) {
      const oid = typeof row.id === 'number' ? `ORD-${row.id}` : String(row.id);
      try {
        const sfRes = await fetch(`${window.location.origin}/api/sf`, {
          method: 'POST', headers: buildAdminHeaders(adminUser),
          body: JSON.stringify({
            action: 'label',
            orderId: oid,
            waybillNos: row.waybill_no ? [String(row.waybill_no)] : undefined,
          }),
        });
        const sfJson = await sfRes.json().catch(() => ({}));
        const isSuccess = !!sfJson?.success;
        labelResults.push({
          orderId: oid,
          labelImage: isSuccess ? (sfJson.labelImage ?? null) : null,
          labelPdfUrl: isSuccess ? (sfJson.labelPdfUrl ?? null) : null,
          labelPdfBase64: isSuccess ? (sfJson.labelPdfBase64 ?? null) : null,
          waybillNo: sfJson.waybillNo ?? row.waybill_no ?? null,
          error: (sfRes.ok && isSuccess) ? undefined : (sfJson.message ?? sfJson.error ?? '取得面單失敗'),
        });
      } catch {
        labelResults.push({
          orderId: oid,
          labelImage: null,
          labelPdfUrl: null,
          labelPdfBase64: null,
          waybillNo: row.waybill_no ?? null,
          error: '網路錯誤',
        });
      }
    }

    const imageCount = labelResults.filter(r => !!r.labelImage).length;
    const pdfCount = labelResults.filter(r => !!r.labelPdfUrl || !!r.labelPdfBase64).length;
    const failedCount = labelResults.length - imageCount - pdfCount;
    if (showSummaryToast) {
      if (failedCount > 0 && imageCount + pdfCount === 0) {
        showToast(`順豐未回傳可列印面單（${failedCount} 筆），可能需要到順豐商戶平台打印`, 'error');
      } else if (failedCount > 0) {
        showToast(`${imageCount + pdfCount} 張面單已取得，${failedCount} 張未能取得`, 'error');
      }
    }

    for (const r of labelResults) {
      if (!r.labelPdfUrl && !r.labelPdfBase64) continue;
      let printableUrl = r.labelPdfUrl;
      if (!printableUrl && r.labelPdfBase64) {
        try {
          const bin = atob(r.labelPdfBase64);
          const bytes = new Uint8Array(bin.length);
          for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
          printableUrl = URL.createObjectURL(new Blob([bytes], { type: 'application/pdf' }));
        } catch {
          printableUrl = null;
        }
      }
      if (printableUrl) {
        window.open(printableUrl, '_blank', 'noopener,noreferrer');
      }
    }

    const htmlRows = labelResults.filter(r => !r.labelPdfUrl && !r.labelPdfBase64 && !r.error);
    if (htmlRows.length === 0) {
      return { total: labelResults.length, imageCount: imageCount + pdfCount, failedCount };
    }

    const printWindow = window.open('', '_blank');
    if (!printWindow) throw new Error('無法開啟列印視窗，請允許彈出視窗');

    const labelsHtml = htmlRows.map((r, idx) => {
      const pageBreak = idx < htmlRows.length - 1 ? 'style="page-break-after:always"' : '';
      if (r.labelImage) {
        return `<div class="label-page" ${pageBreak}>
          <img src="data:image/png;base64,${r.labelImage}" class="label-img" />
        </div>`;
      }
      const row = orderRows.find(o => {
        const id = typeof o.id === 'number' ? `ORD-${o.id}` : String(o.id);
        return id === r.orderId;
      });
      const addr = row ? [row.delivery_district, row.delivery_address, row.delivery_street, row.delivery_building].filter(Boolean).join(' ') : '';
      const floorFlat = row ? [row.delivery_floor ? row.delivery_floor + '樓' : '', row.delivery_flat ? row.delivery_flat + '室' : ''].filter(Boolean).join(' ') : '';
      const fullAddr = [addr, floorFlat].filter(Boolean).join(' ') || '未提供地址';
      return `<div class="label-fallback" ${pageBreak}>
        <div class="waybill">${r.waybillNo || '待取得單號'}</div>
        <div class="note">⚠ 未能從順豐取得電子面單，請到順豐商戶平台打印</div>
        <div class="section"><div class="section-title">寄件人</div><div class="info">Coolfood</div></div>
        <div class="divider"></div>
        <div class="section">
          <div class="section-title">收件人</div>
          <div class="info name">${row?.contact_name || row?.customer_name || ''}</div>
          <div class="info">${row?.customer_phone || ''}</div>
          <div class="info addr">${fullAddr}</div>
        </div>
        <div class="bottom"><span>訂單 ${r.orderId}</span><span>順豐冷鏈</span></div>
      </div>`;
    }).join('');

    printWindow.document.write(`<!DOCTYPE html><html><head><meta charset="utf-8"><title>順豐面單</title>
      <style>
        @page { size: 150mm 100mm landscape; margin: 0; }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Microsoft JhengHei', sans-serif; }
        .label-page { width: 150mm; height: 100mm; display: flex; align-items: center; justify-content: center; overflow: hidden; }
        .label-img { max-width: 100%; max-height: 100%; object-fit: contain; }
        .label-fallback { width: 144mm; height: 94mm; padding: 6mm; overflow: hidden; }
        .waybill { font-size: 22px; font-weight: 900; text-align: center; padding: 4mm 0; border: 2px solid #000; margin-bottom: 3mm; letter-spacing: 2px; }
        .note { font-size: 10px; color: #c00; font-weight: 700; text-align: center; margin-bottom: 3mm; padding: 2mm; background: #fff3f3; border-radius: 4px; }
        .section { margin-bottom: 2mm; }
        .section-title { font-size: 9px; font-weight: 800; text-transform: uppercase; letter-spacing: 1px; color: #666; margin-bottom: 1mm; }
        .info { font-size: 14px; font-weight: 700; line-height: 1.4; }
        .info.name { font-size: 18px; font-weight: 900; }
        .info.addr { font-size: 13px; }
        .divider { border-top: 1px dashed #999; margin: 2mm 0; }
        .bottom { display: flex; justify-content: space-between; font-size: 10px; font-weight: 700; color: #666; margin-top: auto; padding-top: 2mm; border-top: 1px dashed #999; }
        @media print { body { -webkit-print-color-adjust: exact; print-color-adjust: exact; } }
      </style>
    </head><body>${labelsHtml}</body></html>`);
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => printWindow.print(), 300);
    return { total: labelResults.length, imageCount: imageCount + pdfCount, failedCount };
  };

  /** PREPARING tab → 打印順豐單 (reprint labels for selected orders) */
  const handlePrintSfLabels = async () => {
    if (selectedOrderIds.size === 0) return;
    setBatchProcessing(true);
    try {
      const dbIds = Array.from(selectedOrderIds).map(id => getOrderDbId(id)).filter((id): id is number => id !== null);
      const { data, error } = await supabase.from('orders').select('*').in('id', dbIds);
      if (error || !data) { showToast('載入訂單資料失敗', 'error'); setBatchProcessing(false); return; }
      const orderRows = data as SupabaseOrderRow[];
      const rowsWithWaybill = orderRows.filter(r => String(r.waybill_no || '').trim());
      if (rowsWithWaybill.length === 0) {
        showToast('所選訂單尚未有物流單號，請先按「建立運單並打印貼紙」', 'error');
        setBatchProcessing(false);
        return;
      }
      if (rowsWithWaybill.length < orderRows.length) {
        showToast(`僅重印已有單號的 ${rowsWithWaybill.length} 筆（其餘訂單未建立運單）`, 'error');
      }
      await printSfLabelsFromRows(rowsWithWaybill);
    } catch (e) {
      showToast(`列印失敗：${e instanceof Error ? e.message : String(e)}`, 'error');
    }
    setBatchProcessing(false);
  };

  /** PREPARING tab → 建立順豐運單（批次）並自動打印成功貼紙 */
  const handleBatchCallCourier = async () => {
    if (selectedOrderIds.size === 0) return;
    setBatchProcessing(true);
    try {
      const eligibleOrders = orders.filter(o => selectedOrderIds.has(o.id) && o.status === OrderStatus.PREPARING);
      if (eligibleOrders.length === 0) {
        showToast('沒有符合條件的訂單（僅限「備貨中」狀態）', 'error');
        setBatchProcessing(false);
        return;
      }

      const dbIds = eligibleOrders.map(o => getOrderDbId(o.id)).filter((id): id is number => id !== null);
      const { data, error } = await supabase.from('orders').select('*').in('id', dbIds);
      if (error || !data) { showToast('載入訂單資料失敗', 'error'); setBatchProcessing(false); return; }

      const orderRows = data as SupabaseOrderRow[];

      const problematic: { id: string; reason: string }[] = [];
      const valid: SupabaseOrderRow[] = [];
      for (const row of orderRows) {
        const orderId = typeof row.id === 'number' ? `ORD-${row.id}` : String(row.id);
        const reasons: string[] = [];
        const deliveryMethod = normalizeSfDeliveryMethod(row.delivery_method);
        if (deliveryMethod !== 'sf_delivery' && deliveryMethod !== 'sf_locker') {
          reasons.push('非順豐配送方式（僅支援上門/凍櫃）');
        }
        const receiverName = (row.contact_name || row.customer_name || '').trim();
        const receiverPhone = (row.customer_phone || '').trim();
        if (!receiverName) reasons.push('缺少收件人姓名');
        if (!receiverPhone) reasons.push('缺少聯絡電話');
        if (deliveryMethod === 'sf_delivery') {
          if (!String(row.delivery_district || '').trim()) reasons.push('缺少地區');
          if (!String(row.delivery_address || '').trim()) reasons.push('缺少地址');
          if (!String(row.delivery_floor || '').trim()) reasons.push('缺少樓層');
          if (!String(row.delivery_flat || '').trim()) reasons.push('缺少室號');
        }
        if (deliveryMethod === 'sf_locker' && !String(row.locker_code || '').trim()) {
          reasons.push('缺少凍櫃自提點代碼');
        }
        if (String(row.waybill_no || '').trim()) {
          reasons.push('已有物流單號（如要重印請用「打印順豐單」）');
        }
        if (reasons.length > 0) { problematic.push({ id: orderId, reason: reasons.join('、') }); }
        else { valid.push(row); }
      }

      if (problematic.length > 0) {
        setSfValidationModal({ problematic, valid });
        setBatchProcessing(false);
        return;
      }

      await executeSfCalls(valid, { autoPrintLabels: true });
    } catch (e) {
      showToast(`呼叫順豐錯誤：${e instanceof Error ? e.message : String(e)}`, 'error');
    }
    setBatchProcessing(false);
  };

  const executeSfCalls = async (validOrders: SupabaseOrderRow[], options?: { autoPrintLabels?: boolean }) => {
    setBatchProcessing(true);
    let successCount = 0;
    let failCount = 0;
    let pendingWaybillCount = 0;
    const batchId = `sf_batch_${Date.now()}`;
    const successfulRows: SupabaseOrderRow[] = [];
    const failureDetails: string[] = [];
    const pendingDetails: string[] = [];

    for (const row of validOrders) {
      const orderId = typeof row.id === 'number' ? `ORD-${row.id}` : String(row.id);

      try {
        const sfRes = await fetch(`${window.location.origin}/api/sf`, {
          method: 'POST', headers: buildAdminHeaders(adminUser),
          body: JSON.stringify({ action: 'order', orderId }),
        });
        const sfText = await sfRes.text();
        let sfJson: { waybillNo?: string; waybill_no?: string; success?: boolean; code?: string; message?: string } | null = null;
        try { sfJson = sfText ? JSON.parse(sfText) : null; } catch { sfJson = null; }
        const waybill = sfJson?.waybill_no ?? sfJson?.waybillNo ?? null;

        if (sfRes.ok && sfJson?.success && waybill) {
          await supabase.from('orders').update({
            status: 'shipping',
            waybill_no: waybill,
            sf_responses: {
              status: sfRes.status,
              body: sfJson,
              at: new Date().toISOString(),
              batchId,
              manualBatch: true,
            },
          }).eq('id', row.id);
          successfulRows.push({ ...row, waybill_no: waybill });
          successCount++;
        } else if (sfRes.ok && sfJson?.success && !waybill && sfJson?.code === 'SF_ACCEPTED_NO_WAYBILL') {
          const pendingReason = sfJson?.message || '順豐已受理但未回傳運單號';
          await supabase.from('orders').update({
            status: 'preparing',
            sf_responses: {
              status: sfRes.status,
              body: sfJson,
              at: new Date().toISOString(),
              sfPendingWaybill: true,
              sfErrorMsg: String(pendingReason).slice(0, 300),
              batchId,
              manualBatch: true,
            },
          }).eq('id', row.id);
          pendingDetails.push(`#${orderId}: ${String(pendingReason).slice(0, 80)}`);
          pendingWaybillCount++;
        } else {
          const failReason = (sfJson as any)?.error || (sfJson as any)?.code || sfText || `HTTP ${sfRes.status}`;
          await supabase.from('orders').update({
            status: 'preparing',
            sf_responses: {
              status: sfRes.status,
              body: sfJson ?? sfText,
              at: new Date().toISOString(),
              sfError: true,
              sfErrorMsg: String(failReason).slice(0, 300),
              batchId,
              manualBatch: true,
            },
          }).eq('id', row.id);
          failureDetails.push(`#${orderId}: ${String(failReason).slice(0, 80)}`);
          failCount++;
        }
      } catch (e) {
        const failReason = e instanceof Error ? e.message : String(e);
        await supabase.from('orders').update({
          status: 'preparing',
          sf_responses: {
            error: true,
            message: failReason,
            at: new Date().toISOString(),
            sfError: true,
            sfErrorMsg: String(failReason).slice(0, 300),
            batchId,
            manualBatch: true,
          },
        }).eq('id', row.id);
        failureDetails.push(`#${orderId}: ${String(failReason).slice(0, 80)}`);
        failCount++;
      }
    }

    let printedCount = 0;
    let printFailedCount = 0;
    if (options?.autoPrintLabels && successfulRows.length > 0) {
      try {
        const printResult = await printSfLabelsFromRows(successfulRows, { showSummaryToast: false });
        printedCount = printResult.imageCount;
        printFailedCount = printResult.failedCount;
      } catch (e) {
        printFailedCount = successfulRows.length;
        showToast(`運單建立成功，但自動打印失敗：${e instanceof Error ? e.message : String(e)}`, 'error');
      }
    }

    await fetchOrders();
    setSelectedOrderIds(new Set());
    setSfValidationModal(null);
    const autoPrintSuffix = options?.autoPrintLabels
      ? `；貼紙打印：${printedCount} 成功、${printFailedCount} 失敗`
      : '';
    const pendingSuffix = pendingWaybillCount > 0
      ? `；待回單號：${pendingWaybillCount} 筆（請稍後重試）`
      : '';
    const reasonSuffix = failureDetails.length > 0
      ? `；原因：${failureDetails.slice(0, 2).join(' / ')}${failureDetails.length > 2 ? ' ...' : ''}`
      : '';
    const pendingDetailSuffix = pendingDetails.length > 0
      ? `；待處理：${pendingDetails.slice(0, 2).join(' / ')}${pendingDetails.length > 2 ? ' ...' : ''}`
      : '';
    const msg = (failCount > 0 || pendingWaybillCount > 0)
      ? `批次 ${batchId} 完成：順豐下單 ${successCount} 成功、${failCount} 失敗${pendingSuffix}。失敗/待回單號訂單保留「備貨中」${autoPrintSuffix}${reasonSuffix}${pendingDetailSuffix}`
      : `批次 ${batchId} 完成：${successCount} 筆已取得物流單號並轉為「發貨中」${autoPrintSuffix}`;
    showToast(msg, (failCount > 0 || pendingWaybillCount > 0) ? 'error' : 'success');
    setBatchProcessing(false);
  };

  const handleRefund = async () => {
    if (!refundModal) return;
    const amount = refundType === 'full' ? refundModal.total : Number(refundAmount);
    if (!amount || amount <= 0) { showToast('請輸入有效退款金額', 'error'); return; }
    if (amount > refundModal.total) { showToast('退款金額不能超過訂單總額', 'error'); return; }
    setRefundProcessing(true);
    try {
      const res = await fetch(`${window.location.origin}/api/stripe`, {
        method: 'POST', headers: buildAdminHeaders(adminUser),
        body: JSON.stringify({ action: 'refund', orderId: refundModal.orderId, amount }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        showToast(`退款成功：$${formatMoney(amount)}，狀態已更新為「${data.newStatus === 'refunded' ? '退款' : '部份退款'}」`);
        setRefundModal(null);
        setRefundAmount('');
        setRefundType('full');
        await fetchOrders();
        if (inspectingOrder) {
          const dbId = getOrderDbId(inspectingOrder.id);
          if (dbId !== null) {
            const { data: updated } = await supabase.from('orders').select('*').eq('id', dbId).single();
            if (updated) {
              setInspectingOrderDetails(updated as SupabaseOrderRow);
              setOrderStatusDraft(normalizeOrderStatus(updated.status));
            }
          }
        }
      } else {
        showToast(`退款失敗：${data.error || '未知錯誤'}`, 'error');
      }
    } catch (e) {
      showToast(`退款錯誤：${e instanceof Error ? e.message : String(e)}`, 'error');
    }
    setRefundProcessing(false);
  };

  const handleLocateMe = () => {
    if (!checkoutAddressDraft) return;
    const apiKey = process.env.GOOGLE_MAPS_API_KEY;
    if (!apiKey) {
      showToast('請在 .env.local 設定 GOOGLE_MAPS_API_KEY', 'error');
      return;
    }
    if (!navigator.geolocation) {
      showToast('此瀏覽器不支援定位，請手動填寫地址', 'error');
      return;
    }
    const lang = getAppLanguage();
    setIsLocatingAddress(true);
    const timeoutId = setTimeout(() => {
      setIsLocatingAddress((prev) => { if (prev) showToast('定位逾時，請手動填寫地址', 'error'); return false; });
    }, 15000);
    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        try {
          await loadGoogleMapsScript(apiKey, lang);
          clearTimeout(timeoutId);
          const g = (window as unknown as { google?: { maps?: { Geocoder: new () => { geocode: (req: unknown, cb: (results: { address_components?: { long_name: string; short_name: string; types: string[] }[]; formatted_address?: string }[] | null, status: string) => void) => void } } } }).google;
          if (!g?.maps?.Geocoder) {
            setIsLocatingAddress(false);
            showToast('無法載入地圖服務，請手動填寫地址', 'error');
            return;
          }
          const geocoder = new g.maps.Geocoder();
          geocoder.geocode({ location: { lat: latitude, lng: longitude } }, (results, status) => {
            setIsLocatingAddress(false);
            if (status !== 'OK') {
              showToast('Could not find address', 'error');
              return;
            }
            if (!results || results.length === 0) {
              showToast('Could not find address', 'error');
              return;
            }
            const first = results[0];
            if (!first) {
              showToast('Could not find address', 'error');
              return;
            }
            const { district, street, building } = parseReverseGeocodeResults(results);
            const fullDetail = [building, street].filter(Boolean).join(', ');
            setCheckoutAddressDraft(prev => {
              if (!prev) return prev;
              return {
                ...prev,
                district: district || prev.district,
                detail: fullDetail || prev.detail,
                street: street || prev.street,
                building: building || prev.building,
              };
            });
            const filled: string[] = [];
            if (district) filled.push('地區');
            if (building) filled.push('大廈');
            if (street) filled.push('街道');
            if (filled.length > 0) showToast(`已填入${filled.join('、')}，請補上樓層及室號`);
            else showToast('未能取得詳細地址，請手動填寫', 'error');
          });
        } catch {
          clearTimeout(timeoutId);
          setIsLocatingAddress(false);
          showToast('無法取得地址，請手動填寫', 'error');
        }
      },
      (err) => {
        clearTimeout(timeoutId);
        setIsLocatingAddress(false);
        if (err?.code === 1) showToast('Location denied. Please allow location or type your address.', 'error');
        else showToast('無法取得位置，請允許定位或手動填寫地址', 'error');
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 }
    );
  };

  // Attach Google Places Autocomplete to street input when checkout address form is visible (flexible: suggestions only; floor/flat untouched).
  useEffect(() => {
    const formVisible = showCheckoutAddressForm || (isChangingAddress && !!checkoutAddressDraft);
    if (!formVisible) {
      placesAutocompleteRef.current = null;
      return;
    }
    const inputEl = streetInputRef.current;
    if (!inputEl) return;
    const apiKey = process.env.GOOGLE_MAPS_API_KEY;
    if (!apiKey) return;
    const lang = getAppLanguage();
    let ac: unknown = null;
    loadGoogleMapsScript(apiKey, lang)
      .then(() => {
        const g = (window as unknown as {
          google?: {
            maps?: {
              places?: {
                Autocomplete: new (input: HTMLInputElement, opts?: { types?: string[]; language?: string }) => { getPlace?: () => { place_id?: string }; addListener: (event: string, fn: () => void) => void };
                PlacesService: new (map: unknown) => { getDetails: (req: { placeId: string }, cb: (place: { address_components?: { long_name: string; short_name: string; types: string[] }[] } | null, status: string) => void) => void };
              };
              Map: new (el: HTMLElement, opts?: object) => unknown;
            };
          };
        }).google;
        if (!g?.maps?.places || !streetInputRef.current) return;
        const Autocomplete = g.maps.places.Autocomplete;
        ac = new Autocomplete(streetInputRef.current, { types: ['address'], language: lang });
        placesAutocompleteRef.current = ac;
        (ac as { addListener: (event: string, fn: () => void) => void }).addListener('place_changed', () => {
          const acInstance = placesAutocompleteRef.current as { getPlace?: () => { place_id?: string } } | null;
          const place = acInstance?.getPlace?.();
          const placeId = place?.place_id;
          if (!placeId) return;
          const mapEl = document.createElement('div');
          const map = new g.maps.Map(mapEl, {});
          const service = new g.maps.places.PlacesService(map);
          service.getDetails({ placeId }, (detail, status) => {
            if (status !== 'OK' || !detail?.address_components?.length) return;
            const { district, street, building } = parseAddressComponents(detail.address_components);
            const detailLine = [street, building].filter(Boolean).join(' ');
            setCheckoutAddressDraft(prev => prev ? { ...prev, district: district || prev.district, detail: detailLine || prev.detail } : prev);
          });
        });
      })
      .catch(() => {});
    return () => {
      placesAutocompleteRef.current = null;
    };
  }, [showCheckoutAddressForm, isChangingAddress, checkoutAddressDraft]);

  /** Resolves the delivery address for checkout: draft if complete, else selected/default saved address for member. */
  const getCheckoutDeliveryAddress = (): UserAddress | null => {
    if (deliveryMethod !== 'home') return null;
    if (checkoutAddressDraft && isAddressCompleteForOrder(checkoutAddressDraft)) return checkoutAddressDraft;
    const addrs = user?.addresses;
    if (!addrs?.length) return null;
    const selected = checkoutSelectedAddressId ? addrs.find(a => a.id === checkoutSelectedAddressId) : null;
    const fallback = addrs.find(a => a.isDefault) || addrs[0];
    return selected || fallback || null;
  };

  const handleSubmitOrder = async () => {
    if (cart.length === 0) {
      showToast('購物車是空的', 'error');
      return;
    }
    if (isRedirectingToPayment) return;

    // Stock check: verify items are still in stock before payment (only when inventory enforcement is on)
    if (inventoryOn) {
      const outOfStock: string[] = [];
      for (const item of cart) {
        const current = products.find(p => p.id === item.id);
        if (!current) { outOfStock.push(item.name); continue; }
        if (current.trackInventory && current.stock < item.qty) {
          outOfStock.push(`${item.name}（剩餘 ${current.stock} 件）`);
        }
      }
      if (outOfStock.length > 0) {
        showToast(`以下產品庫存不足：${outOfStock.join('、')}`, 'error');
        return;
      }
    }

    const { subtotal, deliveryFee, total } = pricingData;
    const orderIdNum = Date.now();
    const orderIdDisplay = `ORD-${orderIdNum}`;
    const itemsCount = cart.reduce((sum, item) => sum + item.qty, 0);
    const orderDate = new Date().toISOString().slice(0, 10);

    const lineItems: OrderLineItem[] = cart.map(item => {
      const unitPrice = roundMoney(getPrice(item, item.qty));
      const isByPiece = item.pricingMode === 'by_piece';
      const estimatedWeight = isByPiece && item.packWeightLb ? item.packWeightLb * item.qty : undefined;
      const lineTotal = roundMoney(estimatedWeight ? unitPrice * estimatedWeight : unitPrice * item.qty);
      return {
        product_id: item.id, name: item.name, unit_price: unitPrice, qty: item.qty, line_total: lineTotal, image: item.image ?? null,
        pricing_mode: item.pricingMode || undefined,
        actual_weight_lb: estimatedWeight,
      };
    });

    const deliveryAddress = getCheckoutDeliveryAddress();

    // ── Wholesale order flow ──
    if (isWholesaleRoute) {
      if (!user) {
        showToast('批發客戶請先登入', 'error');
        return;
      }
      if (user.memberType === 'wholesale' && user.wholesaleStatus && user.wholesaleStatus !== 'approved') {
        showToast(user.wholesaleStatus === 'pending' ? '您的批發帳戶正在審核中，審核通過後即可下單。' : '您的批發帳戶申請未獲批准，如有疑問請聯絡我們。', 'error');
        return;
      }
      const wsContactName = user?.name ?? null;
      const wsCustomerPhone = user?.phoneNumber ?? null;
      const wsAddr = user?.deliveryAddress || null;
      const wsNote = wholesaleDeliveryNote.trim() || null;

      // Use member's own operational fields directly (no wholesale_clients lookup needed)
      const wsClientId: string | null = user?.id ?? null;
      const wsBrand: string | null = user?.wholesaleBrand || (isGHFoods ? 'GHFOODS' : 'COOLFOOD');
      const wsRouteId: string | null = user?.routeId || null;
      const wsCreditLimit = Number(user?.creditLimit) || 0;

      // Credit limit enforcement: check outstanding AR + this order vs limit
      if (wsCreditLimit > 0 && wsClientId) {
        const { data: arRows } = await supabase
          .from('accounts_receivable')
          .select('amount, paid_amount')
          .eq('client_id', wsClientId)
          .in('status', ['pending', 'overdue']);
        const outstandingAR = (arRows || []).reduce((sum, r) => sum + (Number(r.amount) - Number(r.paid_amount)), 0);
        if (outstandingAR + total > wsCreditLimit) {
          showToast(`已超出信用額度（額度 $${formatMoney(wsCreditLimit)}，未結 $${formatMoney(outstandingAR)}，本單 $${formatMoney(total)}）`, 'error');
          return;
        }
      }

      const wsStatus = paymentMethod === 'cod' ? 'confirmed' : OrderStatus.PENDING_PAYMENT;

      const insertRow: Record<string, unknown> = {
        id: orderIdNum,
        customer_name: user.name,
        customer_phone: wsCustomerPhone,
        total,
        subtotal,
        delivery_fee: deliveryFee,
        status: wsStatus,
        order_date: orderDate,
        items_count: itemsCount,
        line_items: lineItems,
        delivery_method: 'own_van',
        delivery_address: wsNote ? (wsAddr ? `${wsAddr}\n備註: ${wsNote}` : wsNote) : wsAddr,
        contact_name: wsContactName,
        order_type: 'wholesale',
        payment_method: paymentMethod,
        member_id: user.id,
        wholesale_client_id: wsClientId,
        wholesale_brand: wsBrand,
        route_id: wsRouteId,
      };
      if (wholesaleDeliveryDate) insertRow.delivery_date = wholesaleDeliveryDate;
      if (deliveryAddress?.district) insertRow.delivery_district = deliveryAddress.district;

      const { error } = await supabase.from('orders').insert(insertRow);
      if (error) {
        showToast(error.message || '訂單提交失敗', 'error');
        return;
      }

      // Auto-create accounts receivable entry (matches NewOrderPanel behaviour)
      if (wsClientId) {
        supabase.from('accounts_receivable').insert({
          client_id: wsClientId,
          client_name: user.name,
          brand: wsBrand,
          order_id: String(orderIdNum),
          invoice_date: orderDate,
          amount: total,
          paid_amount: 0,
          status: 'pending',
          credit_terms: paymentMethod === 'cod' ? 'cod' : 'fps',
        }).then(({ error: arErr }) => {
          if (arErr) console.warn('[order] AR insert failed:', arErr.message);
        });
      }

      // Update committed_qty on ingredients for inventory planning
      if (inventoryOn) {
        for (const item of cart) {
          const prod = products.find(p => p.id === item.id);
          if (prod?.ingredientId) {
            supabase.rpc('increment_committed_qty', { p_ingredient_id: prod.ingredientId, p_qty: item.qty }).then(({ error: cErr }) => {
              if (cErr) console.warn(`[stock] committed_qty update failed for ${prod.ingredientId}:`, cErr.message);
            });
          }
        }
      }

      const newOrder: Order = { id: orderIdDisplay, customerName: user.name, total, status: wsStatus, date: orderDate, items: itemsCount, orderType: 'wholesale', memberId: user.id };
      setOrders(prev => [...prev, newOrder]);
      setCart([]);
      try { localStorage.removeItem('coolfood_cart'); } catch { /* ignore */ }
      setWholesaleDeliveryDate('');
      setWholesaleDeliveryNote('');
      setView('success');
      showToast(paymentMethod === 'cod' ? '訂單已提交，送貨時收款' : '訂單已提交，請以 FPS 轉帳');
      return;
    }

    // ── Retail order flow ──
    if (deliveryMethod === 'home') {
      if (!deliveryAddress || !isAddressCompleteForOrder(deliveryAddress)) {
        showToast('請填寫地區、地址、樓層、單位、收件人及手機號碼', 'error');
        return;
      }
    }
    if (deliveryMethod === 'sf_locker') {
      if (!selectedLockerPoint) {
        showToast('請選擇冷運自提點', 'error');
        return;
      }
    }
    const lockerContactPhone = (user?.phoneNumber ?? checkoutGuestPhone).trim();
    if (deliveryMethod === 'sf_locker' && !lockerContactPhone) {
      showToast(lang === 'en' ? 'Please enter a contact phone number' : '請填寫聯絡電話以便發送物流通知', 'error');
      return;
    }
    const useDraft = deliveryMethod === 'home' && checkoutAddressDraft && isAddressCompleteForOrder(checkoutAddressDraft);
    const deliveryAddr = deliveryMethod === 'sf_locker' && selectedLockerPoint
      ? formatLockerAddress(selectedLockerPoint, selectedLockerDistrict)
      : (deliveryAddress ? deliveryAddress.detail ?? null : null);
    const contactName = deliveryAddress?.contactName ?? (user?.name ?? null);
    const customerPhone = deliveryAddress?.phone ?? (deliveryMethod === 'sf_locker' ? lockerContactPhone || null : user?.phoneNumber ?? null);
    const altContactName = deliveryAddress?.altContactName ?? null;
    const altContactPhone = deliveryAddress?.altPhone ?? null;
    const customerName = user?.name ?? '訪客';

    const newOrder: Order = {
      id: orderIdDisplay,
      customerName,
      total: roundMoney(total),
      status: OrderStatus.PENDING_PAYMENT,
      date: orderDate,
      items: itemsCount,
      orderType: 'retail',
      memberId: user?.id,
    };

    const insertRow: Record<string, unknown> = {
      id: orderIdNum,
      customer_name: customerName,
      customer_phone: customerPhone,
      total: roundMoney(total),
      subtotal: roundMoney(subtotal),
      delivery_fee: roundMoney(deliveryFee),
      status: OrderStatus.PENDING_PAYMENT,
      order_date: orderDate,
      items_count: itemsCount,
      line_items: lineItems,
      delivery_method: deliveryMethod,
      delivery_address: deliveryAddr,
      contact_name: contactName,
      delivery_alt_contact_name: altContactName,
      delivery_alt_contact_phone: altContactPhone,
      order_type: 'retail',
      payment_method: 'card',
      member_id: user?.id ?? null,
      coupon_id: selectedCoupon?.couponId ?? null,
      member_coupon_id: selectedCoupon?.id ?? null,
      coupon_discount: roundMoney(pricingData.couponDiscount ?? 0),
    };
    if (deliveryMethod === 'home' && deliveryAddress) {
      insertRow.delivery_district = deliveryAddress.district ?? null;
      insertRow.delivery_floor = deliveryAddress.floor ?? null;
      insertRow.delivery_flat = deliveryAddress.flat ?? null;
    }
    if (deliveryMethod === 'sf_locker' && selectedLockerPoint) {
      insertRow.locker_code = selectedLockerPoint.code;
      insertRow.delivery_district = selectedLockerDistrict;
    }

    setIsRedirectingToPayment(true);

    // Insert order FIRST so the payment API can verify the amount server-side
    let { error } = await supabase.from('orders').insert(insertRow);
    if (error && String(error.message || '').includes('member_coupon_id')) {
      const fallbackRow = { ...insertRow };
      delete fallbackRow.member_coupon_id;
      const retry = await supabase.from('orders').insert(fallbackRow);
      error = retry.error;
    }
    if (error) {
      setIsRedirectingToPayment(false);
      showToast(error.message || '訂單提交失敗', 'error');
      return;
    }

    const apiBase = typeof window !== 'undefined' ? window.location.origin : '';
    let checkoutRes: Response;
    try {
      checkoutRes = await fetch(`${apiBase}/api/stripe`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'create-checkout-session',
          merchant_order_id: orderIdDisplay,
          success_origin: typeof window !== 'undefined' ? window.location.origin : '',
        }),
      });
    } catch {
      setIsRedirectingToPayment(false);
      showToast('Payment system is currently busy, please try again in a moment.', 'error');
      return;
    }
    if (!checkoutRes.ok) {
      setIsRedirectingToPayment(false);
      let errMsg = 'Payment system is currently busy, please try again in a moment.';
      try {
        const contentType = checkoutRes.headers.get('content-type') || '';
        if (contentType.includes('application/json')) {
          const errBody = await checkoutRes.json() as { error?: string; code?: string };
          if (typeof errBody?.error === 'string' && errBody.error) errMsg = errBody.error;
          if (typeof errBody?.code === 'string' && errBody.code) {
            console.error('[Checkout] Stripe API error code:', errBody.code);
          }
        } else {
          const errText = await checkoutRes.text();
          console.error('[Checkout] Stripe API non-JSON error', checkoutRes.status, errText.slice(0, 500));
          if (checkoutRes.status === 404) {
            errMsg = 'Payment API not found. Please redeploy and ensure the Vercel Function /api/stripe is enabled.';
          }
        }
      } catch {
        /* use default errMsg */
      }
      showToast(errMsg, 'error');
      return;
    }
    let sessionData: { session_id?: string; url?: string };
    try {
      sessionData = await checkoutRes.json();
    } catch {
      setIsRedirectingToPayment(false);
      showToast('Payment system is currently busy, please try again in a moment.', 'error');
      return;
    }
    const { session_id, url: stripeCheckoutUrl } = sessionData;
    console.log('[Checkout] Stripe response:', { session_id, hasUrl: !!stripeCheckoutUrl });
    if (!session_id || !stripeCheckoutUrl) {
      setIsRedirectingToPayment(false);
      showToast('Payment system is currently busy, please try again in a moment.', 'error');
      return;
    }

    // Stock is decremented server-side in confirm-payment after Stripe verification succeeds.
    if (inventoryOn) {
      setProducts(prev => prev.map(p => {
        const cartItem = cart.find(c => c.id === p.id);
        if (cartItem && p.trackInventory) return { ...p, stock: Math.max(0, p.stock - cartItem.qty) };
        return p;
      }));
    }

    if (user && useDraft && checkoutSaveNewAddressAsDefault && checkoutAddressDraft) {
      handleSaveAddress(user.id, checkoutAddressDraft, true, true);
    }

    setOrders(prev => [...prev, newOrder]);
    if (typeof window !== 'undefined' && session_id) {
      try { window.sessionStorage.setItem('stripe_session_id', session_id); } catch { /* ignore */ }
    }

    console.log('[Checkout] Order inserted. Redirecting to Stripe Checkout...');
    console.log('[Checkout]   session_id:', session_id);
    window.location.href = stripeCheckoutUrl;
  };

  // --- Admin Logic ---

  const handleAiAnalysis = async () => {
    setIsAnalyzing(true);
    try {
      const res = await fetch('/api/generate-recipe', {
        method: 'POST', headers: buildAdminHeaders(adminUser),
        body: JSON.stringify({ action: 'business-analysis', payload: {} }),
      });
      const json = await res.json();
      if (!json.ok) throw new Error(json.error || 'AI error');
      setAiAnalysis(json.data.text || 'AI 無法生成建議。');
    } catch (e) {
      setAiAnalysis('AI 離線中。');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const [imageUploading, setImageUploading] = useState<string | null>(null);

  const handleImageUpload = async (
    files: FileList | null,
    storagePath: string,
    onSuccess: (urls: string[]) => void,
    opts?: { multi?: boolean; uploadKey?: string }
  ) => {
    if (!files || files.length === 0) return;
    const key = opts?.uploadKey || storagePath;
    setImageUploading(key);
    try {
      if (opts?.multi) {
        const urls = await uploadImages(Array.from(files), storagePath);
        onSuccess(urls);
      } else {
        const file = files[0];
        const ext = file.type.startsWith('image/') ? 'webp' : (file.name.split('.').pop() || 'bin');
        const fullPath = `${storagePath}/main-${Date.now()}.${ext}`;
        const url = await uploadImage(file, fullPath);
        onSuccess([url]);
      }
    } catch (err: any) {
      showToast(err.message || '上傳失敗', 'error');
    } finally {
      setImageUploading(null);
    }
  };

  const downloadCSVTemplate = () => {
    const headers = ['groupName', 'variantLabel', 'pricingMode', 'price', 'saleChannel', 'productType', 'packSize', 'packWeightLb', 'categories', 'description', 'origin'];
    const sample1 = ['牛柳頭', '原件抄碼', 'by_piece', '68', 'wholesale', 'raw_material', '', '', 'beef', '原件按磅計價', '澳洲'];
    const sample2 = ['牛柳頭', '切絲 2MM 5kg', 'fixed_pack', '380', 'wholesale', 'raw_material', '5kg/包', '11', 'beef', '', ''];
    const sample3 = ['牛柳頭', '切粒 300g', 'fixed_pack', '58', 'wholesale', 'raw_material', '300g/包', '0.66', 'beef', '', ''];
    const sample4 = ['四海牛丸', '原包', 'fixed_pack', '45', 'wholesale', 'third_party', '1包', '', '', '第三方產品原包出售', ''];
    const sample5 = ['四海牛丸', '分裝 500g', 'fixed_pack', '28', 'wholesale', 'third_party', '500g', '', '', '', ''];
    const instructions = [
      '# ═══════════════════════════════════════════════',
      '# 產品批量上傳範本 (新結構：產品→規格)',
      '# ═══════════════════════════════════════════════',
      '#',
      '# ★ 必填：groupName（產品名稱）',
      '#',
      '# groupName     : 產品名稱，同名的行會自動歸入同一產品群組',
      '# variantLabel   : 規格名稱（選填，系統可自動產生），例如：原件抄碼、切絲 2MM 5kg',
      '# pricingMode   : fixed_pack=定裝（固定包裝） / by_piece=抄碼（按重量）',
      '# price         : 售價（定裝=包裝價 / 抄碼=每磅/kg 價錢）',
      '# saleChannel   : both=零售+批發 / retail=零售 / wholesale=批發',
      '# productType   : raw_material=原材料 / third_party=第三方 / in_house=自製',
      '# packSize      : 包裝規格，例如：5kg/包、300g、原箱',
      '# packWeightLb  : 包裝重量（磅），數字',
      '# categories    : 分類（多個用 | 分隔）',
      '# description   : 描述（選填）',
      '# origin        : 產地（選填）',
      '#',
      '# ─── 注意事項 ───',
      '# • 以 # 開頭的行為說明，匯入時會自動跳過',
      '# • 同一 groupName 的多行 = 同一產品的不同規格',
      '# • 用 Excel / Google Sheets 開啟後，請存成 CSV 格式再上傳',
      '# ═══════════════════════════════════════════════',
    ];
    const csvContent = [instructions.join('\n'), headers.join(','), sample1.join(','), sample2.join(','), sample3.join(','), sample4.join(','), sample5.join(',')].join('\n');
    const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'product_import_template.csv');
    link.click();
  };

  const handleCSVUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = async (event) => {
        const text = event.target?.result as string;
        const lines = text.replace(/^\uFEFF/, '').split('\n').filter(l => l.trim().length > 0 && !l.trim().startsWith('#'));
        if (lines.length < 2) { showToast('CSV 格式錯誤：缺少標題列或資料列', 'error'); return; }
        const headers = lines[0].split(',').map(h => h.trim());
        const existingIds = new Set(products.map(p => p.id));

        const catLookup = new Map<string, string>();
        categories.forEach(c => {
          catLookup.set(c.id.toLowerCase(), c.id);
          catLookup.set(c.name.toLowerCase(), c.id);
        });
        const resolveCategory = (raw: string): string => {
          const lower = raw.toLowerCase();
          return catLookup.get(lower) || raw;
        };

        const isNewFormat = headers.includes('groupName');

        if (isNewFormat) {
          const groupMap = new Map<string, { group: ProductGroup; specs: Product[] }>();

          for (let li = 1; li < lines.length; li++) {
            const values = lines[li].split(',').map(v => v.trim());
            const get = (h: string) => values[headers.indexOf(h)] || '';
            const groupName = get('groupName');
            if (!groupName) continue;

            if (!groupMap.has(groupName)) {
              const classification = (get('productType') || 'raw_material') as ProductClassification;
              const existingGroup = productGroups.find(g => g.name === groupName);
              const group: ProductGroup = existingGroup || {
                id: crypto.randomUUID(),
                name: groupName,
                classification,
                isActive: true,
              };
              groupMap.set(groupName, { group, specs: [] });
            }

            const entry = groupMap.get(groupName)!;
            let autoId = 'P-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6);
            while (existingIds.has(autoId)) autoId = 'P-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6);
            existingIds.add(autoId);

            const varLabel = get('variantLabel') || '原件';
            const ch = get('saleChannel').toLowerCase();
            const cats = get('categories') ? get('categories').split('|').map(c => resolveCategory(c.trim())).filter(Boolean) : [];

            const spec: Product = {
              id: autoId,
              name: `${groupName} ${varLabel}`,
              categories: cats,
              price: Number(get('price')) || 0,
              memberPrice: 0,
              stock: 0,
              trackInventory: true,
              tags: [],
              image: entry.group.classification === 'third_party' ? '📦' : '🥩',
              saleChannel: (['retail', 'wholesale', 'both'].includes(ch) ? ch : 'wholesale') as SaleChannel,
              productType: (get('productType') || 'raw_material') as ProductType,
              groupId: entry.group.id,
              variantLabel: varLabel,
              pricingMode: (get('pricingMode') === 'by_piece' ? 'by_piece' : 'fixed_pack') as PricingMode,
              packSize: get('packSize') || undefined,
              packWeightLb: Number(get('packWeightLb')) || undefined,
              description: get('description') || undefined,
              origin: get('origin') || undefined,
            };
            entry.specs.push(spec);
          }

          let groupCount = 0;
          let specCount = 0;
          for (const { group, specs } of groupMap.values()) {
            const existingGroup = productGroups.find(g => g.id === group.id);
            if (!existingGroup) {
              await upsertProductGroup(group);
            }
            groupCount++;
            const success = await upsertProducts(specs);
            if (success) specCount += specs.length;
          }
          showToast(`成功匯入 ${groupCount} 個產品、${specCount} 款規格`);
        } else {
          const numericFields = new Set(['price', 'memberPrice', 'costPrice', 'yieldRate', 'processingCost', 'packagingCost', 'miscCost', 'packWeightLb', 'purchaseLimit']);
          const newProducts: Product[] = lines.slice(1).map(line => {
            const values = line.split(',').map(v => v.trim());
            const p: any = { tags: [], image: '🥩', recipes: [], categories: [], trackInventory: true, memberPrice: 0, stock: 0, price: 0 };
            headers.forEach((h, i) => {
              const val = values[i] || '';
              if (h === 'categories') p.categories = val ? val.split('|').map((v: string) => resolveCategory(v.trim())).filter(Boolean) : [];
              else if (h === 'tags') p.tags = val ? val.split('|').map((v: string) => v.trim()).filter(Boolean) : [];
              else if (h === 'stock') p.stock = Math.round(Number(val) || 0);
              else if (numericFields.has(h)) { if (val) p[h] = Number(val) || 0; }
              else if (h === 'trackInventory') p[h] = val ? val.toLowerCase() === 'true' : true;
              else if (h === 'saleChannel' || h === 'sale_channel') {
                const ch = val.toLowerCase();
                p.saleChannel = (['retail', 'wholesale', 'both'].includes(ch) ? ch as SaleChannel : 'retail');
              }
              else if (h === 'productType' || h === 'product_type') {
                const pt = val.toLowerCase();
                if (['standalone', 'processed', 'raw_material', 'in_house', 'third_party'].includes(pt)) p.productType = pt;
              }
              else if (h === 'nameEn' || h === 'name_en') { if (val) p.nameEn = val; }
              else if (val) p[h] = val;
            });
            if (!p.id || p.id === '') {
              let autoId = 'P-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6);
              while (existingIds.has(autoId)) autoId = 'P-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6);
              p.id = autoId;
              existingIds.add(autoId);
            }
            return p as Product;
          });
          const success = await upsertProducts(newProducts);
          if (success) showToast(`成功批量上傳 ${newProducts.length} 個產品（舊格式）`);
        }
      };
      reader.readAsText(file);
    }
  };

  const applyGlobalPricingRules = () => {
    if (!siteConfig.pricingRules) return;
    const { roundToNearest } = siteConfig.pricingRules;
    showToast('定價規則已套用（全局折扣已移至優惠券系統）');
  };

  const effectiveInventoryChannel: 'all' | 'retail' | 'wholesale' = moduleWorkspace === 'COOLFOOD_RETAIL' ? 'retail' : moduleWorkspace === 'WHOLESALE' ? 'wholesale' : inventoryChannelFilter;

  const filteredAdminProducts = useMemo(() => {
    return products.filter(p => {
      const q = adminProductSearch.toLowerCase();
      const matchSearch = p.name.toLowerCase().includes(q) ||
        p.id.toLowerCase().includes(q) ||
        (p.legacyId?.toLowerCase() ?? '').includes(q);
      if (!matchSearch) return false;
      const ch = p.saleChannel || 'retail';
      if (effectiveInventoryChannel === 'retail') return ch === 'retail' || ch === 'both';
      if (effectiveInventoryChannel === 'wholesale') return ch === 'wholesale' || ch === 'both';
      return true;
    });
  }, [products, adminProductSearch, effectiveInventoryChannel]);

  const [expandedGroupIds, setExpandedGroupIds] = useState<Set<string>>(new Set());

  interface GroupedProduct {
    group: ProductGroup;
    specs: Product[];
    ingredientName?: string;
  }

  const groupedProducts = useMemo((): GroupedProduct[] => {
    const grouped: GroupedProduct[] = [];
    const usedProductIds = new Set<string>();

    for (const g of productGroups) {
      const specs = filteredAdminProducts.filter(p => p.groupId === g.id);
      if (specs.length === 0) continue;
      specs.forEach(s => usedProductIds.add(s.id));
      const ing = g.ingredientId ? ingredients.find(i => i.id === g.ingredientId) : undefined;
      grouped.push({ group: g, specs, ingredientName: ing?.name });
    }

    const ungrouped = filteredAdminProducts.filter(p => !usedProductIds.has(p.id));
    if (ungrouped.length > 0) {
      for (const p of ungrouped) {
        grouped.push({
          group: { id: `_ungrouped_${p.id}`, name: p.name, classification: (p.productType === 'third_party' ? 'third_party' : p.productType === 'in_house' ? 'in_house' : 'raw_material') as ProductClassification, isActive: true },
          specs: [p],
        });
      }
    }

    return grouped;
  }, [filteredAdminProducts, productGroups, ingredients]);

  const toggleGroupExpand = (groupId: string) => {
    setExpandedGroupIds(prev => {
      const next = new Set(prev);
      if (next.has(groupId)) next.delete(groupId); else next.add(groupId);
      return next;
    });
  };

  const filteredStoreProducts = useMemo(() => {
    const channelFiltered = products.filter(p => {
      const ch = p.saleChannel || 'retail';
      if (isWholesaleRoute) return ch === 'wholesale' || ch === 'both';
      return ch === 'retail' || ch === 'both';
    });
    if (!storeSearch.trim()) return channelFiltered;
    const q = storeSearch.toLowerCase();
    return channelFiltered.filter(p =>
      p.name.toLowerCase().includes(q) ||
      (p.description || '').toLowerCase().includes(q) ||
      p.tags.some(t => t.toLowerCase().includes(q)) ||
      (p.origin || '').toLowerCase().includes(q)
    );
  }, [products, storeSearch, isWholesaleRoute]);

  const filteredStoreRecipes = useMemo(() => {
    let filtered = recipeCategoryFilter.length > 0
      ? recipes.filter(r => recipeCategoryFilter.every(cid => r.categoryIds.includes(cid)))
      : recipes;
    if (storeSearch.trim()) {
      const q = storeSearch.trim().toLowerCase();
      filtered = filtered.filter(r =>
        r.title.toLowerCase().includes(q) ||
        (r.description || '').toLowerCase().includes(q) ||
        r.tags.some(tag => tag.toLowerCase().includes(q)) ||
        r.ingredientsRaw.some(ing => (ing.name || '').toLowerCase().includes(q)) ||
        r.linkedProductIds.some(pid => { const p = products.find(x => x.id === pid); return p && p.name.toLowerCase().includes(q); })
      );
    }
    return filtered;
  }, [recipes, recipeCategoryFilter, storeSearch, products]);

  const effectiveOrdersType: 'all' | 'retail' | 'wholesale' = moduleWorkspace === 'COOLFOOD_RETAIL' ? 'retail' : moduleWorkspace === 'WHOLESALE' ? 'wholesale' : ordersTypeFilter;

  const filteredAdminOrders = useMemo(() => {
    return orders.filter(o => {
      const matchesSearch = o.id.toLowerCase().includes(adminOrderSearch.toLowerCase()) || o.customerName.toLowerCase().includes(adminOrderSearch.toLowerCase());
      const matchesStatus = ordersStatusFilter === 'all' || o.status === ordersStatusFilter;
      const matchesType = effectiveOrdersType === 'all' || (o.orderType || 'retail') === effectiveOrdersType;
      return matchesSearch && matchesStatus && matchesType;
    });
  }, [orders, adminOrderSearch, ordersStatusFilter, effectiveOrdersType]);

  const effectiveMemberType: 'all' | 'retail' | 'wholesale' | 'pending' | 'approved' | 'rejected' = moduleWorkspace === 'COOLFOOD_RETAIL' ? 'retail' : adminMemberTypeFilter;

  const brandFilteredMembers = useMemo(() => {
    if (moduleWorkspace !== 'WHOLESALE') return members;
    return members.filter(m => m.memberType === 'wholesale' && m.wholesaleBrand === adminWholesaleBrand);
  }, [members, moduleWorkspace, adminWholesaleBrand]);

  const pendingWholesaleCount = useMemo(() => {
    const pool = moduleWorkspace === 'WHOLESALE' ? brandFilteredMembers : members;
    return pool.filter(m => m.memberType === 'wholesale' && m.wholesaleStatus === 'pending').length;
  }, [brandFilteredMembers, members, moduleWorkspace]);

  const filteredAdminMembers = useMemo(() => {
    const pool = moduleWorkspace === 'WHOLESALE' ? brandFilteredMembers : members;
    return pool.filter(m => {
      const matchesSearch = m.name.toLowerCase().includes(adminMemberSearch.toLowerCase()) || 
        (m.email?.toLowerCase() ?? '').includes(adminMemberSearch.toLowerCase()) ||
        (m.phoneNumber && m.phoneNumber.includes(adminMemberSearch));
      if (effectiveMemberType === 'pending') return matchesSearch && m.memberType === 'wholesale' && m.wholesaleStatus === 'pending';
      if (moduleWorkspace === 'WHOLESALE') {
        if (effectiveMemberType === 'all') return matchesSearch;
        return matchesSearch && m.wholesaleStatus === effectiveMemberType;
      }
      const matchesType = effectiveMemberType === 'all' || (m.memberType || 'retail') === effectiveMemberType;
      return matchesSearch && matchesType;
    });
  }, [brandFilteredMembers, members, adminMemberSearch, effectiveMemberType, moduleWorkspace]);

  // --- UI Module Handlers ---

  const renderInventoryModule = () => (
    <div className="space-y-6 animate-fade-in">
      <div className="flex gap-4 border-b border-slate-100">
        {[
          { id: 'products', label: '產品管理', icon: <Package size={16}/> },
          { id: 'categories', label: '分類設定', icon: <List size={16}/> },
          { id: 'rules', label: '價格與配送規則', icon: <Zap size={16}/> }
        ].map(tab => (
          <button 
            key={tab.id}
            onClick={() => setInventorySubTab(tab.id as any)} 
            className={`pb-3 px-2 font-black text-sm uppercase transition-all relative flex items-center gap-2 ${inventorySubTab === tab.id ? 'text-slate-900' : 'text-slate-300'}`}
          >
            {tab.icon} {tab.label}
            {inventorySubTab === tab.id && <div className="absolute bottom-0 left-0 right-0 h-1 bg-slate-900 rounded-t-full" />}
          </button>
        ))}
      </div>

      {inventorySubTab === 'products' && (
        <>
          {/* Channel filter tabs — only shown when no workspace is pinned */}
          {!moduleWorkspace && (
          <div className="flex gap-2">
            {([
              { id: 'all' as const, label: '全部' },
              { id: 'retail' as const, label: '零售' },
              { id: 'wholesale' as const, label: '批發' },
            ]).map(ch => (
              <button key={ch.id} onClick={() => { setInventoryChannelFilter(ch.id); setSelectedProductIds(new Set()); }} className={`px-5 py-2 rounded-xl text-xs font-black transition-all ${inventoryChannelFilter === ch.id ? 'bg-slate-900 text-white shadow-lg' : 'bg-white text-slate-400 border border-slate-200 hover:bg-slate-50'}`}>
                {ch.label}
              </button>
            ))}
          </div>
          )}
          <div className="flex flex-col md:flex-row gap-4 justify-between">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
              <input 
                value={adminProductSearch}
                onChange={e => { setAdminProductSearch(e.target.value); setSelectedProductIds(new Set()); }}
                placeholder="搜索產品..." 
                className="w-full pl-12 pr-6 py-3 bg-white border border-slate-100 rounded-2xl font-bold" 
              />
            </div>
            <div className="flex gap-3">
              <button onClick={downloadCSVTemplate} className="px-6 py-3 bg-white border border-slate-100 text-slate-600 rounded-2xl font-black text-xs flex items-center gap-2 shadow-sm hover:bg-slate-50 transition-all">
                <Download size={16}/> 下載模板
              </button>
              <label className="px-6 py-3 bg-white border border-slate-100 text-slate-600 rounded-2xl font-black text-xs flex items-center gap-2 shadow-sm hover:bg-slate-50 transition-all cursor-pointer">
                <Upload size={16}/> 批量上傳 CSV
                <input type="file" accept=".csv" className="hidden" onChange={handleCSVUpload} />
              </label>
              {(() => {
                const catLookup = new Map<string, string>();
                categories.forEach(c => { catLookup.set(c.id.toLowerCase(), c.id); catLookup.set(c.name.toLowerCase(), c.id); });
                const needFix = products.filter(p => p.categories.some(c => !categories.some(cat => cat.id === c) && catLookup.has(c.toLowerCase())));
                if (needFix.length === 0) return null;
                return (
                  <button onClick={async () => {
                    const fixed = products.map(p => {
                      const newCats = p.categories.map(c => {
                        if (categories.some(cat => cat.id === c)) return c;
                        return catLookup.get(c.toLowerCase()) || c;
                      });
                      return { ...p, categories: newCats };
                    });
                    const changed = fixed.filter((p, i) => JSON.stringify(p.categories) !== JSON.stringify(products[i].categories));
                    if (changed.length === 0) { showToast('無需修正'); return; }
                    const ok = await upsertProducts(fixed);
                    if (ok) showToast(`已修正 ${changed.length} 個產品的分類`);
                  }} className="px-5 py-3 bg-amber-500 text-white rounded-2xl font-black text-xs flex items-center gap-2 shadow-sm hover:bg-amber-600 transition-all animate-pulse">
                    <AlertTriangle size={16}/> 修正分類 ({needFix.length})
                  </button>
                );
              })()}
              <button disabled={aiDescLoading} onClick={async () => {
                const toGenerate = products.filter(p => p.name.trim() && (!p.description || p.description.trim() === ''));
                if (toGenerate.length === 0) { showToast('所有產品已有描述'); return; }
                const batch = toGenerate.slice(0, 20);
                const COOLDOWN_MS = 1000;
                setAiDescLoading(true);
                let successCount = 0;
                let failCount = 0;
                for (let i = 0; i < batch.length; i++) {
                  const p = batch[i];
                  setAiBatchProgress({ current: i + 1, total: batch.length, label: `正在為「${p.name}」生成描述 (${i + 1}/${batch.length})...` });
                  try {
                    const res = await fetch('/api/generate-recipe', {
                      method: 'POST', headers: buildAdminHeaders(adminUser),
                      body: JSON.stringify({ action: 'single-product-desc', payload: { productName: p.name } }),
                    });
                    const json = await res.json();
                    if (json.ok && json.data?.description) {
                      upsertProduct({ ...p, description: json.data.description });
                      successCount++;
                    } else { failCount++; }
                  } catch { failCount++; }
                  if (i < batch.length - 1) await new Promise(r => setTimeout(r, COOLDOWN_MS));
                }
                setAiBatchProgress(null);
                setAiDescLoading(false);
                const msg = failCount > 0
                  ? `AI 完成：${successCount} 個成功，${failCount} 個失敗`
                  : `AI 已為 ${successCount} 個產品生成描述`;
                showToast(msg, failCount > 0 ? 'error' : 'success');
              }} className="px-6 py-3 bg-purple-600 text-white rounded-2xl font-black text-xs flex items-center gap-2 shadow-sm hover:bg-purple-700 transition-all disabled:opacity-50">
                {aiDescLoading ? <RefreshCw size={16} className="animate-spin" /> : <Sparkles size={16} />} AI 批量寫描述
              </button>
              <button onClick={() => setNewProductWizard({ classification: null, ingredientId: '', pricingMode: 'fixed_pack', packSize: '', productName: '', specs: [] })} className="px-6 py-3 bg-slate-900 text-white rounded-2xl font-black text-xs flex items-center gap-2 shadow-xl hover:bg-slate-800 transition-all">
                <Plus size={16}/> 上架新產品
              </button>
            </div>
          </div>
          {/* Product batch action bar */}
          {selectedProductIds.size > 0 && (
            <div className="flex items-center gap-3 p-4 bg-blue-50 border border-blue-200 rounded-2xl animate-fade-in flex-wrap">
              <span className="text-xs font-black text-blue-700">已選 {selectedProductIds.size} 項</span>
              <select id="batchProductChannelSelect" className="px-3 py-1.5 bg-white rounded-lg text-xs font-bold border border-blue-200" defaultValue="">
                <option value="" disabled>設定銷售渠道...</option>
                <option value="retail">僅零售</option>
                <option value="wholesale">僅批發</option>
                <option value="both">零售 + 批發</option>
              </select>
              <button onClick={async () => {
                const sel = (document.getElementById('batchProductChannelSelect') as HTMLSelectElement)?.value;
                if (!sel) { showToast('請先選擇渠道', 'error'); return; }
                const ids = Array.from(selectedProductIds);
                try {
                  const { error } = await supabase.from('products').update({ sale_channel: sel }).in('id', ids);
                  if (error) throw error;
                  setProducts(prev => prev.map(p => ids.includes(p.id) ? { ...p, saleChannel: sel as SaleChannel } : p));
                  setSelectedProductIds(new Set());
                  showToast(`已為 ${ids.length} 項產品設定銷售渠道`);
                } catch (err: any) { showToast(`批量更新失敗：${err.message}`, 'error'); }
              }} className="px-3 py-1.5 bg-blue-600 text-white rounded-lg text-xs font-black active:scale-95 transition-all">套用渠道</button>
              <button onClick={async () => {
                if (!confirm(`確定刪除 ${selectedProductIds.size} 項產品？此操作無法復原。`)) return;
                const ids = Array.from(selectedProductIds);
                try {
                  const { error } = await supabase.from('products').delete().in('id', ids);
                  if (error) throw error;
                  setProducts(prev => prev.filter(p => !ids.includes(p.id)));
                  setSelectedProductIds(new Set());
                  showToast(`已刪除 ${ids.length} 項產品`);
                } catch (err: any) { showToast(`批量刪除失敗：${err.message}`, 'error'); }
              }} className="px-3 py-1.5 bg-rose-500 text-white rounded-lg text-xs font-black active:scale-95 transition-all ml-auto flex items-center gap-1"><Trash2 size={12}/> 批量刪除</button>
            </div>
          )}
          <div className="bg-white rounded-[2.5rem] border border-slate-100 overflow-hidden shadow-sm">
             <table className="w-full text-left text-sm">
                <thead className="bg-slate-50 border-b border-slate-100">
                  <tr>
                    <th className="text-center px-3 py-4 w-10">
                      <button onClick={() => {
                        const allIds = filteredAdminProducts.map(p => p.id);
                        if (selectedProductIds.size === allIds.length && allIds.length > 0) setSelectedProductIds(new Set());
                        else setSelectedProductIds(new Set(allIds));
                      }} className={`w-5 h-5 rounded-md border-2 flex items-center justify-center transition-all mx-auto ${selectedProductIds.size === filteredAdminProducts.length && filteredAdminProducts.length > 0 ? 'border-blue-500 bg-blue-500 text-white' : 'border-slate-200 bg-white'}`}>
                        {selectedProductIds.size === filteredAdminProducts.length && filteredAdminProducts.length > 0 && <Check size={12} strokeWidth={3}/>}
                      </button>
                    </th>
                    <th className="px-3 py-4 w-8"></th>
                    <th className="px-6 py-4 font-bold text-slate-400 uppercase text-[10px]">產品 / 規格</th>
                    <th className="px-4 py-4 font-bold text-slate-400 uppercase text-[10px]">原材料</th>
                    <th className="px-4 py-4 font-bold text-slate-400 uppercase text-[10px]">規格數</th>
                    <th className="px-4 py-4 font-bold text-slate-400 uppercase text-[10px]">銷售渠道</th>
                    <th className="px-6 py-4 font-bold text-slate-400 uppercase text-[10px]">操作</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {groupedProducts.length === 0 && (
                    <tr>
                      <td colSpan={7} className="px-6 py-10 text-center text-slate-400 font-bold">
                        尚未有產品
                      </td>
                    </tr>
                  )}
                  {groupedProducts.map(({ group: g, specs, ingredientName }) => {
                    const isExpanded = expandedGroupIds.has(g.id);
                    const allSpecIds = specs.map(s => s.id);
                    const allSelected = allSpecIds.every(id => selectedProductIds.has(id));
                    const someSelected = allSpecIds.some(id => selectedProductIds.has(id));
                    const classIcon = g.classification === 'raw_material' ? '🥩' : g.classification === 'third_party' ? '📦' : '🏭';
                    const classLabel = g.classification === 'raw_material' ? '原材料' : g.classification === 'third_party' ? '第三方' : '自製';
                    const firstSpec = specs[0];
                    return (
                    <React.Fragment key={g.id}>
                      <tr className={`hover:bg-slate-50/80 transition-colors cursor-pointer ${someSelected ? 'bg-blue-50/30' : ''}`} onClick={() => toggleGroupExpand(g.id)}>
                        <td className="text-center px-3 py-4" onClick={e => e.stopPropagation()}>
                          <button onClick={() => {
                            setSelectedProductIds(prev => {
                              const next = new Set(prev);
                              if (allSelected) allSpecIds.forEach(id => next.delete(id));
                              else allSpecIds.forEach(id => next.add(id));
                              return next;
                            });
                          }} className={`w-5 h-5 rounded-md border-2 flex items-center justify-center transition-all mx-auto ${allSelected ? 'border-blue-500 bg-blue-500 text-white' : someSelected ? 'border-blue-300 bg-blue-100' : 'border-slate-200 bg-white'}`}>
                            {allSelected && <Check size={12} strokeWidth={3}/>}
                            {someSelected && !allSelected && <Minus size={10} strokeWidth={3} className="text-blue-500"/>}
                          </button>
                        </td>
                        <td className="px-3 py-4">
                          <ChevronRight size={14} className={`text-slate-400 transition-transform ${isExpanded ? 'rotate-90' : ''}`} />
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-lg overflow-hidden flex items-center justify-center bg-slate-50 border border-slate-100">
                              {g.image && isMediaUrl(g.image) ? <img src={g.image} className="w-full h-full object-cover" alt="" /> : firstSpec?.image && isMediaUrl(firstSpec.image) ? <img src={firstSpec.image} className="w-full h-full object-cover" alt="" /> : <span className="text-xl">{classIcon}</span>}
                            </div>
                            <div className="flex flex-col">
                              <span className="font-black text-slate-800">{g.name}</span>
                              <span className="text-[9px] font-bold text-slate-400 flex items-center gap-1">
                                <span className={`px-1.5 py-0.5 rounded text-[8px] font-black ${g.classification === 'raw_material' ? 'bg-rose-50 text-rose-600' : g.classification === 'third_party' ? 'bg-blue-50 text-blue-600' : 'bg-emerald-50 text-emerald-600'}`}>{classLabel}</span>
                              </span>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-4">
                          {ingredientName ? <span className="text-xs font-bold text-slate-600">{ingredientName}</span> : <span className="text-slate-200 text-[10px]">—</span>}
                        </td>
                        <td className="px-4 py-4">
                          <span className="px-2.5 py-1 bg-violet-50 text-violet-600 rounded-full text-[10px] font-black">{specs.length} 款規格</span>
                        </td>
                        <td className="px-4 py-4">
                          {(() => {
                            const channels = new Set(specs.map(s => s.saleChannel || 'retail'));
                            if (channels.has('both') || (channels.has('retail') && channels.has('wholesale'))) return <span className="px-2 py-0.5 bg-emerald-50 text-emerald-600 rounded-full text-[10px] font-bold">零售+批發</span>;
                            if (channels.has('wholesale')) return <span className="px-2 py-0.5 bg-orange-50 text-orange-600 rounded-full text-[10px] font-bold">批發</span>;
                            return <span className="px-2 py-0.5 bg-blue-50 text-blue-600 rounded-full text-[10px] font-bold">零售</span>;
                          })()}
                        </td>
                        <td className="px-6 py-4" onClick={e => e.stopPropagation()}>
                          <div className="flex gap-1">
                            <button onClick={() => {
                              const group = productGroups.find(pg => pg.id === g.id);
                              if (!group) return;
                              const newVariant: Product = {
                                id: 'P-' + Date.now(),
                                name: g.name,
                                categories: firstSpec?.categories || [],
                                price: 0, memberPrice: 0, stock: 0, trackInventory: true,
                                tags: firstSpec?.tags || [], image: firstSpec?.image || classIcon,
                                saleChannel: firstSpec?.saleChannel || 'wholesale',
                                productType: firstSpec?.productType || 'raw_material',
                                groupId: g.id,
                                parentIngredientId: firstSpec?.parentIngredientId,
                                ingredientId: firstSpec?.ingredientId,
                                variantLabel: '', pricingMode: 'fixed_pack',
                              };
                              setEditingProduct(newVariant);
                            }} className="p-1.5 text-violet-500 hover:bg-violet-50 rounded-lg" title="新增規格"><Plus size={14}/></button>
                            <button onClick={() => { if (firstSpec) setEditingProduct(firstSpec); }} className="p-1.5 text-blue-500 hover:bg-blue-50 rounded-lg" title="編輯"><Edit size={14}/></button>
                            <button onClick={async () => {
                              if (!confirm(`確定刪除「${g.name}」及其所有 ${specs.length} 款規格？此操作無法復原。`)) return;
                              const ids = specs.map(s => s.id);
                              try {
                                const { error: pErr } = await supabase.from('products').delete().in('id', ids);
                                if (pErr) throw pErr;
                                if (!g.id.startsWith('_ungrouped_')) {
                                  await supabase.from('product_groups').delete().eq('id', g.id);
                                  setProductGroups(prev => prev.filter(pg => pg.id !== g.id));
                                }
                                setProducts(prev => prev.filter(p => !ids.includes(p.id)));
                                showToast(`已刪除「${g.name}」及 ${ids.length} 款規格`);
                              } catch (err: any) { showToast(`刪除失敗：${err.message}`, 'error'); }
                            }} className="p-1.5 text-rose-500 hover:bg-rose-50 rounded-lg" title="刪除全部"><Trash2 size={14}/></button>
                          </div>
                        </td>
                      </tr>
                      {isExpanded && specs.map(spec => {
                        const isSelected = selectedProductIds.has(spec.id);
                        const pt = spec.processingTypeId ? processingTypes.find(t => t.id === spec.processingTypeId) : null;
                        const pricingLabel = spec.pricingMode === 'by_piece' ? '🏷️ 抄碼' : '📦 定裝';
                        return (
                          <tr key={spec.id} className={`bg-slate-50/40 hover:bg-slate-50 transition-colors ${isSelected ? 'bg-blue-50/40' : ''}`}>
                            <td className="text-center px-3 py-3">
                              <button onClick={() => setSelectedProductIds(prev => {
                                const next = new Set(prev);
                                if (next.has(spec.id)) next.delete(spec.id); else next.add(spec.id);
                                return next;
                              })} className={`w-4 h-4 rounded border-2 flex items-center justify-center transition-all mx-auto ${isSelected ? 'border-blue-500 bg-blue-500 text-white' : 'border-slate-200 bg-white'}`}>
                                {isSelected && <Check size={10} strokeWidth={3}/>}
                              </button>
                            </td>
                            <td className="px-3 py-3"><div className="w-px h-4 bg-slate-200 ml-1.5" /></td>
                            <td className="px-6 py-3">
                              <div className="flex items-center gap-2">
                                <span className="text-xs font-bold text-slate-700">{spec.variantLabel || spec.name}</span>
                                {spec.processingSpec && <span className="px-1.5 py-0.5 bg-amber-50 text-amber-600 rounded text-[9px] font-bold">{spec.processingSpec}</span>}
                                <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${spec.pricingMode === 'by_piece' ? 'bg-pink-50 text-pink-600' : 'bg-slate-100 text-slate-500'}`}>{pricingLabel}</span>
                                <span className="text-[10px] font-black text-slate-800 ml-auto">${formatMoney(spec.price)}{spec.pricingMode === 'by_piece' ? `/${spec.weight || '磅'}` : ''}</span>
                              </div>
                            </td>
                            <td className="px-4 py-3"></td>
                            <td className="px-4 py-3"></td>
                            <td className="px-4 py-3">
                              <select
                                value={spec.saleChannel || 'retail'}
                                onChange={async e => {
                                  const ch = e.target.value as SaleChannel;
                                  const { error } = await supabase.from('products').update({ sale_channel: ch }).eq('id', spec.id);
                                  if (error) { showToast(`更新失敗：${error.message}`, 'error'); return; }
                                  setProducts(prev => prev.map(x => x.id === spec.id ? { ...x, saleChannel: ch } : x));
                                }}
                                onClick={e => e.stopPropagation()}
                                className={`px-2 py-0.5 rounded-full text-[9px] font-bold border-0 cursor-pointer outline-none ${spec.saleChannel === 'retail' ? 'bg-blue-50 text-blue-600' : spec.saleChannel === 'wholesale' ? 'bg-orange-50 text-orange-600' : 'bg-emerald-50 text-emerald-600'}`}
                              >
                                <option value="both">零售+批發</option>
                                <option value="retail">僅零售</option>
                                <option value="wholesale">僅批發</option>
                              </select>
                            </td>
                            <td className="px-6 py-3">
                              <div className="flex gap-1">
                                <button onClick={() => setEditingProduct(spec)} className="p-1 text-blue-500 hover:bg-blue-50 rounded"><Edit size={13}/></button>
                                <button onClick={() => setConfirmation({ title: '刪除規格', message: `確定刪除「${spec.variantLabel || spec.name}」？`, onConfirm: () => deleteProduct(spec.id) })} className="p-1 text-rose-500 hover:bg-rose-50 rounded"><Trash2 size={13}/></button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </React.Fragment>
                    );
                  })}
                </tbody>
             </table>
          </div>
        </>
      )}

      {inventorySubTab === 'categories' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="font-black text-slate-800">分類列表</h3>
            <button onClick={() => setEditingCategory({ id: 'cat-'+Date.now(), name: '', icon: '🥩', sortOrder: categories.length })} className="px-4 py-2 bg-slate-900 text-white rounded-xl font-bold text-xs"><Plus size={14} className="inline mr-1"/> 新增</button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {categories.length === 0 && (
              <div className="col-span-full text-center text-slate-400 font-bold py-10">
                尚未有分類
              </div>
            )}
            {categories.map((c, idx) => (
              <div
                key={c.id}
                draggable
                onDragStart={() => { dragProdCatIdx.current = idx; }}
                onDragOver={e => { e.preventDefault(); setDragOverProdCat(idx); }}
                onDragLeave={() => setDragOverProdCat(null)}
                onDrop={() => {
                  if (dragProdCatIdx.current !== null) reorderProductCategories(dragProdCatIdx.current, idx);
                  dragProdCatIdx.current = null;
                  setDragOverProdCat(null);
                }}
                onDragEnd={() => { dragProdCatIdx.current = null; setDragOverProdCat(null); }}
                className={`bg-white p-6 rounded-3xl border shadow-sm flex items-center justify-between group transition-all cursor-grab active:cursor-grabbing ${dragOverProdCat === idx ? 'border-blue-400 bg-blue-50/30 scale-[1.02]' : 'border-slate-100'}`}
              >
                <div className="flex items-center gap-3">
                  <GripVertical size={16} className="text-slate-300 flex-shrink-0" />
                  <div className="text-3xl">{c.icon}</div>
                  <div><p className="font-black text-slate-900">{c.name}</p><p className="text-[10px] text-slate-400 uppercase tracking-widest">{c.id}</p></div>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => setEditingCategory(c)} className="p-2 text-slate-400 hover:text-blue-500"><Edit size={16}/></button>
                  <button
                    onClick={() => setConfirmation({
                      title: '刪除分類',
                      message: `確定刪除 ${c.name} 嗎？此操作無法復原。`,
                      onConfirm: () => deleteCategory(c.id)
                    })}
                    className="p-2 text-slate-400 hover:text-rose-500"
                  >
                    <Trash2 size={16}/>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {inventorySubTab === 'rules' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 animate-fade-in pb-12">
           <div className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm">
             <h4 className="text-lg font-black mb-4">定價管理</h4>
             <p className="text-sm text-slate-400 mb-4">定價設定與產品排除管理。</p>
             <button onClick={() => setAdminModule('pricing')} className="px-6 py-3 bg-slate-900 text-white rounded-2xl font-black text-sm active:scale-95 transition-all">前往價錢設定</button>
           </div>
        </div>
      )}
    </div>
  );

  const renderAdminLogin = () => (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
      <form onSubmit={handleAdminLogin} className="w-full max-w-sm bg-white border border-slate-100 rounded-[2.5rem] shadow-xl p-8 space-y-6">
        <div className="text-center space-y-2">
          <div className="w-14 h-14 rounded-2xl bg-blue-600 text-white flex items-center justify-center mx-auto shadow-lg">
            <Cpu size={24} />
          </div>
          <h2 className="text-xl font-black text-slate-900">管理後台登入</h2>
          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">REAR-LINK 4.2</p>
        </div>
        <div className="space-y-4">
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">管理員電話號碼</label>
            <input
              value={adminLoginForm.username}
              onChange={e => setAdminLoginForm({ ...adminLoginForm, username: e.target.value })}
              className="w-full px-4 py-3 bg-slate-50 rounded-2xl border border-slate-100 font-bold text-sm"
              placeholder="輸入電話號碼"
              inputMode="tel"
            />
          </div>
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">密碼</label>
            <input
              type="password"
              value={adminLoginForm.password}
              onChange={e => setAdminLoginForm({ ...adminLoginForm, password: e.target.value })}
              className="w-full px-4 py-3 bg-slate-50 rounded-2xl border border-slate-100 font-bold text-sm"
              placeholder="輸入密碼"
            />
          </div>
        </div>
        <button type="submit" className="w-full py-3 bg-slate-900 text-white rounded-2xl font-black text-sm shadow-lg active:scale-95 transition-all">
          登入後台
        </button>
        <button type="button" onClick={() => { window.location.hash = ''; }} className="w-full py-3 bg-white border border-slate-100 text-slate-500 rounded-2xl font-black text-xs">
          返回前台
        </button>
      </form>
    </div>
  );

  const renderModulePlaceholder = (moduleId: string) => {
    const placeholders: Record<string, { title: string; desc: string; emoji: string }> = {
      global_dashboard: { title: '總儀表版', desc: '跨品牌營收、訂單與庫存總覽 — 一覽全局', emoji: '📊' },
    };
    const info = placeholders[moduleId] || { title: moduleId, desc: '功能開發中', emoji: '🔧' };
    const wsLabel = moduleWorkspace ? (() => { const labels: Record<string, string> = { WHOLESALE: '批發', COOLFOOD_RETAIL: 'Coolfood 零售' }; return labels[moduleWorkspace] || ''; })() : '';
    return (
      <div className="flex items-center justify-center min-h-[400px] animate-fade-in">
        <div className="text-center space-y-5 max-w-md">
          <div className="w-24 h-24 bg-slate-100 rounded-[2rem] flex items-center justify-center mx-auto text-4xl shadow-inner">
            {info.emoji}
          </div>
          <h3 className="text-2xl font-black text-slate-900">{info.title}</h3>
          {wsLabel && <p className="text-sm font-black text-slate-400">{wsLabel}</p>}
          <p className="text-slate-500 font-bold text-sm">{info.desc}</p>
          <div className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-50 text-blue-600 rounded-2xl text-sm font-black">
            <Sparkles size={16}/> 即將推出
          </div>
        </div>
      </div>
    );
  };

  const renderPermissionDenied = (moduleName: string) => (
    <div className="flex flex-col items-center justify-center py-24 text-slate-400 animate-fade-in">
      <ShieldCheck size={48} className="mb-4 opacity-30" />
      <p className="font-black text-lg">權限不足</p>
      <p className="text-sm mt-1">您沒有權限進入「{moduleName}」模組</p>
    </div>
  );

  const renderAdminModuleContent = () => {
    // Enterprise Security: check module-level access before rendering
    const modulePermKey = ADMIN_MODULE_PERMISSION_MAP[adminModule] as keyof AdminPermissions | undefined;
    if (modulePermKey && !hasAdminPermission(modulePermKey)) {
      return renderPermissionDenied(ADMIN_PERMISSION_LABELS[modulePermKey] || adminModule);
    }

    const lazyFallback = <div className="flex items-center justify-center py-20"><RefreshCw className="animate-spin text-slate-300" size={24} /></div>;

    // Functional panels — shared modules (lazy-loaded + error boundary per section)
    if (adminModule === 'dispatch') return <SectionErrorBoundary section="派車"><Suspense fallback={lazyFallback}><DispatchPanel showToast={showToast} /></Suspense></SectionErrorBoundary>;
    if (adminModule === 'new_order') return <SectionErrorBoundary section="新增訂單"><Suspense fallback={lazyFallback}><NewOrderPanel showToast={showToast} /></Suspense></SectionErrorBoundary>;
    if (adminModule === 'accounting') return <SectionErrorBoundary section="會計"><Suspense fallback={lazyFallback}><AccountingPanel showToast={showToast} /></Suspense></SectionErrorBoundary>;
    if (adminModule === 'legacy_features') return <SectionErrorBoundary section="進階功能"><Suspense fallback={lazyFallback}><LegacyFeaturesPanel showToast={showToast} /></Suspense></SectionErrorBoundary>;
    if (adminModule === 'warehouse_ops') return <SectionErrorBoundary section="倉務"><Suspense fallback={lazyFallback}><WarehousePanel showToast={showToast} products={products} setProducts={setProducts} costItems={costItems} setCostItems={setCostItems} siteConfig={siteConfig} isMediaUrl={isMediaUrl} /></Suspense></SectionErrorBoundary>;
    if (adminModule === 'production') return <SectionErrorBoundary section="生產"><Suspense fallback={lazyFallback}><ProductionPanel showToast={showToast} products={products} ingredients={ingredients} /></Suspense></SectionErrorBoundary>;

    // Functional panels — wholesale
    // wholesale_clients module merged into members
    if (adminModule === 'sales_reps') return <SectionErrorBoundary section="銷售員"><Suspense fallback={lazyFallback}><SalesRepPanel showToast={showToast} /></Suspense></SectionErrorBoundary>;
    if (adminModule === 'quotations') return <SectionErrorBoundary section="報價"><Suspense fallback={lazyFallback}><QuotationPanel showToast={showToast} /></Suspense></SectionErrorBoundary>;
    if (moduleWorkspace === 'WHOLESALE' && adminModule === 'pricing') return <SectionErrorBoundary section="批發定價"><Suspense fallback={lazyFallback}><WholesalePricingPanel showToast={showToast} /></Suspense></SectionErrorBoundary>;

    // Remaining placeholder modules
    if (adminModule === 'global_dashboard') return <SectionErrorBoundary section="銷售分析"><Suspense fallback={lazyFallback}><SalesAnalyticsPanel showToast={showToast} /></Suspense></SectionErrorBoundary>;
    const placeholderModules: string[] = [];
    if (placeholderModules.includes(adminModule)) {
      return renderModulePlaceholder(adminModule);
    }
    if (moduleWorkspace && moduleWorkspace !== 'COOLFOOD_RETAIL' && moduleWorkspace !== 'WHOLESALE') {
      return renderModulePlaceholder(adminModule);
    }
    switch (adminModule) {
      case 'dashboard': {
        const todayStr = new Date().toISOString().slice(0, 10);
        const todayRevenue = orders.filter(o => o.date.startsWith(todayStr) && ['paid','preparing','shipping','shipped','delivered'].includes(o.status)).reduce((s, o) => s + o.total, 0);
        const pendingCount = orders.filter(o => o.status === 'paid' || o.status === 'preparing').length;
        const lowStockCount = products.filter(p => p.trackInventory && p.stock < 10).length;
        const totalMembers = members.length;
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 animate-fade-in">
            {[
              { label: '今日營收', value: `$${formatMoney(todayRevenue)}`, icon: <DollarSign className="text-emerald-500" />, trend: `${orders.filter(o => o.date.startsWith(todayStr)).length} 單` },
              { label: '待處理訂單', value: String(pendingCount), icon: <Package className="text-amber-500" />, trend: pendingCount > 0 ? '需處理' : '全部完成' },
              { label: '會員總數', value: String(totalMembers), icon: <Users className="text-blue-500" />, trend: `${members.filter(m => m.tier === 'Gold' || m.tier === 'VIP').length} VIP/Gold` },
              { label: '庫存預警', value: String(lowStockCount), icon: <AlertTriangle className="text-rose-500" />, trend: lowStockCount > 0 ? '需補貨' : '充足' }
            ].map((stat, i) => (
              <div key={i} className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm space-y-2">
                <div className="flex justify-between items-start">
                  <div className="p-3 bg-slate-50 rounded-2xl">{stat.icon}</div>
                  <span className={`text-[10px] font-black px-2 py-1 rounded-lg ${stat.label === '庫存預警' && lowStockCount > 0 ? 'text-rose-500 bg-rose-50' : 'text-emerald-500 bg-emerald-50'}`}>{stat.trend}</span>
                </div>
                <div>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{stat.label}</p>
                  <p className="text-3xl font-black text-slate-900">{stat.value}</p>
                </div>
              </div>
            ))}
            <div className="col-span-1 md:col-span-2 lg:col-span-4 bg-white p-10 rounded-[3.5rem] border border-slate-100 shadow-sm space-y-6">
              <div className="flex justify-between items-center">
                <h3 className="text-xl font-black flex items-center gap-2"><Sparkles className="text-blue-500"/> AI 經營建議</h3>
                <button onClick={handleAiAnalysis} disabled={isAnalyzing} className="px-6 py-3 bg-slate-900 text-white rounded-2xl font-black text-xs flex items-center gap-2 shadow-xl hover:bg-slate-800 disabled:opacity-50">
                  {isAnalyzing ? <RefreshCw size={16} className="animate-spin"/> : <Zap size={16}/>}
                  生成分析報告
                </button>
              </div>
              <div className="p-8 bg-blue-50/50 rounded-[2.5rem] border border-blue-100/50 min-h-[100px] flex items-center justify-center">
                {isAnalyzing ? (
                  <div className="flex flex-col items-center gap-4">
                    <div className="flex gap-2"><div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce [animation-delay:-0.3s]"></div><div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce [animation-delay:-0.15s]"></div><div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce"></div></div>
                    <p className="text-xs font-black text-blue-400 uppercase tracking-widest">AI 正在分析實時數據...</p>
                  </div>
                ) : (
                  <div className="text-slate-600 text-sm font-bold leading-relaxed whitespace-pre-wrap">{aiAnalysis || "點擊按鈕獲取由 AI 提供的專業經營策略。"}</div>
                )}
              </div>
            </div>
          </div>
        );
      }
      case 'inventory': return renderInventoryModule();
      case 'orders':
        const allFilteredIds = new Set(filteredAdminOrders.map(o => o.id));
        const allSelected = filteredAdminOrders.length > 0 && filteredAdminOrders.every(o => selectedOrderIds.has(o.id));
        const toggleSelectAll = () => {
          if (allSelected) {
            setSelectedOrderIds(new Set());
          } else {
            setSelectedOrderIds(new Set(filteredAdminOrders.map(o => o.id)));
          }
        };
        const toggleSelectOrder = (id: string) => {
          setSelectedOrderIds(prev => {
            const next = new Set(prev);
            if (next.has(id)) next.delete(id); else next.add(id);
            return next;
          });
        };
        return (
          <div className="space-y-6 animate-fade-in print:hidden">
             <div className="flex flex-col md:flex-row gap-4 justify-between">
                <div className="relative flex-1 max-w-md">
                   <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                   <input value={adminOrderSearch} onChange={e => setAdminOrderSearch(e.target.value)} placeholder="搜索訂單編號或客戶名稱..." className="w-full pl-12 pr-6 py-3 bg-white border border-slate-100 rounded-2xl font-bold" />
                </div>
                <div className="flex gap-2 overflow-x-auto pb-2 md:pb-0">
                   {!moduleWorkspace && (['all', 'retail', 'wholesale'] as const).map(ot => (
                      <button key={ot} onClick={() => setOrdersTypeFilter(ot)} className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${ordersTypeFilter === ot ? 'bg-slate-900 text-white shadow-lg' : 'bg-white border border-slate-100 text-slate-400'}`}>
                        {ot === 'all' ? '全部' : ot === 'retail' ? '零售' : '批發'}
                      </button>
                   ))}
                   {['all', ...Object.values(OrderStatus)].map(s => (
                      <button key={s} onClick={() => setOrdersStatusFilter(s as any)} className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${ordersStatusFilter === s ? 'bg-slate-900 text-white shadow-lg' : 'bg-white border border-slate-100 text-slate-400'}`}>
                        {s === 'all' ? t.admin.all : getOrderStatusLabel(s, t)}
                      </button>
                   ))}
                </div>
             </div>
             <div className="bg-white rounded-[2.5rem] border border-slate-100 overflow-hidden shadow-sm">
                <table className="w-full text-left text-sm">
                   <thead className="bg-slate-50 border-b border-slate-100">
                      <tr>
                         <th className="px-4 py-4 w-12">
                           <button onClick={toggleSelectAll} className="text-slate-400 hover:text-slate-700 transition-colors">
                             {allSelected ? <CheckSquare size={18} className="text-blue-600" /> : <Square size={18} />}
                           </button>
                         </th>
                         <th className="px-6 py-4 font-bold text-slate-400 uppercase text-[10px]">訂單編號</th>
                         <th className="px-6 py-4 font-bold text-slate-400 uppercase text-[10px]">客戶</th>
                         <th className="px-6 py-4 font-bold text-slate-400 uppercase text-[10px]">金額</th>
                         <th className="px-6 py-4 font-bold text-slate-400 uppercase text-[10px]">狀態</th>
                         <th className="px-6 py-4 font-bold text-slate-400 uppercase text-[10px]">日期</th>
                      </tr>
                   </thead>
                   <tbody className="divide-y divide-slate-50">
                      {filteredAdminOrders.length === 0 && (
                        <tr>
                          <td colSpan={6} className="px-6 py-10 text-center text-slate-400 font-bold">
                            尚未有訂單
                          </td>
                        </tr>
                      )}
                      {filteredAdminOrders.map(o => (
                         <tr key={o.id} className={`hover:bg-slate-50 transition-colors cursor-pointer ${selectedOrderIds.has(o.id) ? 'bg-blue-50/50' : ''}`} onClick={() => setInspectingOrder(o)}>
                            <td className="px-4 py-4" onClick={e => { e.stopPropagation(); toggleSelectOrder(o.id); }}>
                              {selectedOrderIds.has(o.id) ? <CheckSquare size={18} className="text-blue-600" /> : <Square size={18} className="text-slate-300" />}
                            </td>
                            <td className="px-6 py-4 font-black text-blue-600">
                              <span>#{o.id}</span>
                              {o.orderType === 'wholesale' && <span className="ml-1.5 px-1.5 py-0.5 bg-orange-50 text-orange-600 rounded text-[8px] font-black">批發</span>}
                            </td>
                            <td className="px-6 py-4 font-bold text-slate-700">{o.customerName}</td>
                            <td className="px-6 py-4 font-black text-slate-900">${formatMoney(o.total)}</td>
                            <td className="px-6 py-4"><StatusBadge status={o.status}/></td>
                            <td className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">{o.date}</td>
                         </tr>
                      ))}
                   </tbody>
                </table>
             </div>

             {/* Dynamic Batch Action Bar — buttons change based on current tab */}
             {selectedOrderIds.size > 0 && (
               <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[5000] bg-slate-900 text-white px-6 py-4 rounded-2xl shadow-2xl flex items-center gap-4 animate-fade-in">
                 <span className="text-sm font-black whitespace-nowrap">已選 {selectedOrderIds.size} 筆訂單</span>
                 <div className="w-px h-8 bg-slate-700" />
                 {ordersStatusFilter === OrderStatus.PAID && (
                   <button disabled={batchProcessing} onClick={handlePrintPickingList}
                     className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 rounded-xl text-xs font-black transition-colors disabled:opacity-50">
                     <Printer size={14} /> 打印執貨單
                   </button>
                 )}
                 {ordersStatusFilter === OrderStatus.PREPARING && (
                   <>
                     <button disabled={batchProcessing} onClick={handlePrintAggregateList}
                       className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 rounded-xl text-xs font-black transition-colors disabled:opacity-50">
                       <ClipboardList size={14} /> 打印大執貨表
                     </button>
                     <button disabled={batchProcessing} onClick={handleBatchCallCourier}
                       className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 rounded-xl text-xs font-black transition-colors disabled:opacity-50">
                      <Phone size={14} /> 建立運單並打印貼紙
                     </button>
                   </>
                 )}
                {ordersStatusFilter === OrderStatus.SHIPPING && (
                  <button disabled={batchProcessing} onClick={handlePrintSfLabels}
                    className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 rounded-xl text-xs font-black transition-colors disabled:opacity-50">
                   <FileText size={14} /> 重印順豐貼紙
                  </button>
                )}
                 <button disabled={batchProcessing} onClick={handlePrintInvoices}
                  className="flex items-center gap-2 px-4 py-2 bg-violet-600 hover:bg-violet-500 rounded-xl text-xs font-black transition-colors disabled:opacity-50">
                  <FileText size={14} /> 打印發票
                </button>
               {ordersStatusFilter !== OrderStatus.PAID && ordersStatusFilter !== OrderStatus.PREPARING && ordersStatusFilter !== OrderStatus.SHIPPING && ordersStatusFilter !== 'all' && (
                  <span className="text-xs text-slate-400 font-bold">請切換到「已付款」、「備貨中」或「發貨中」Tab 執行更多操作</span>
                 )}
                 <button onClick={() => setSelectedOrderIds(new Set())} className="ml-2 p-2 hover:bg-slate-700 rounded-xl transition-colors">
                   <X size={14} />
                 </button>
               </div>
             )}
          </div>
        );
      case 'slideshow':
        return (
          <div className="space-y-6 animate-fade-in">
             <div className="flex justify-between items-center">
                <p className="text-slate-500 font-bold text-sm">首頁輪播廣告，可放圖片或影片連結</p>
                <button onClick={() => setEditingSlideshow({ id: `slide-${Date.now()}`, type: 'image', url: '', title: '', sortOrder: slideshowItems.length })} className="px-6 py-3 bg-slate-900 text-white rounded-2xl font-black text-xs flex items-center gap-2 shadow-xl"><Plus size={16}/> 新增廣告</button>
             </div>
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...slideshowItems].sort((a, b) => a.sortOrder - b.sortOrder).map(s => (
                  <div key={s.id} className="bg-white p-4 rounded-[2rem] border border-slate-100 shadow-sm overflow-hidden">
                    <div className="aspect-[2.5/1] bg-slate-100 rounded-xl overflow-hidden mb-3">
                      {s.type === 'video' ? (
                        <video src={s.url} className="w-full h-full object-cover" muted />
                      ) : s.url ? (
                        <img src={s.url} alt={s.title || ''} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-slate-300"><ImageIcon size={32}/></div>
                      )}
                    </div>
                    <div className="flex justify-between items-start gap-2">
                      <div className="min-w-0">
                        <p className="font-black text-slate-900 text-sm truncate">{s.title || '（無標題）'}</p>
                        <p className="text-[10px] font-bold text-slate-400 uppercase">{s.type} · 順序 {s.sortOrder}</p>
                      </div>
                      <div className="flex gap-1 flex-shrink-0">
                        <button onClick={() => setEditingSlideshow({ ...s })} className="p-2 rounded-xl text-slate-400 hover:bg-slate-100 hover:text-blue-600"><Edit size={16}/></button>
                        <button onClick={() => setConfirmation({ title: '刪除廣告', message: '確定要刪除此則廣告？', onConfirm: async () => { await deleteSlideshowItem(s.id); setConfirmation(null); } })} className="p-2 rounded-xl text-slate-400 hover:bg-rose-50 hover:text-rose-500"><Trash2 size={16}/></button>
                      </div>
                    </div>
                  </div>
                ))}
             </div>
          </div>
        );
      case 'members':
        return (
          <div className="space-y-6 animate-fade-in">
             <div className="flex flex-col md:flex-row gap-4 justify-between items-center">
                <div className="flex items-center gap-3 flex-1">
                  <div className="relative flex-1 max-w-md w-full">
                     <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                     <input value={adminMemberSearch} onChange={e => setAdminMemberSearch(e.target.value)} placeholder="搜索姓名、電郵或電話..." className="w-full pl-12 pr-6 py-3 bg-white border border-slate-100 rounded-2xl font-bold" />
                  </div>
                  {moduleWorkspace === 'WHOLESALE' ? (
                  <div className="flex gap-1">
                    {([{ id: 'all' as const, label: '全部' }, { id: 'pending' as const, label: '待審核' }, { id: 'approved' as const, label: '已批准' }, { id: 'rejected' as const, label: '已拒絕' }]).map(f => (
                      <button key={f.id} onClick={() => setAdminMemberTypeFilter(f.id as any)} className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all relative ${adminMemberTypeFilter === f.id ? (f.id === 'pending' ? 'bg-orange-500 text-white shadow-lg' : f.id === 'rejected' ? 'bg-red-500 text-white shadow-lg' : f.id === 'approved' ? 'bg-emerald-500 text-white shadow-lg' : 'bg-slate-900 text-white shadow-lg') : 'bg-white text-slate-400 border border-slate-200 hover:bg-slate-50'}`}>
                        {f.label}
                        {f.id === 'pending' && pendingWholesaleCount > 0 && (
                          <span className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-red-500 text-white text-[9px] font-black rounded-full flex items-center justify-center">{pendingWholesaleCount}</span>
                        )}
                      </button>
                    ))}
                  </div>
                  ) : !moduleWorkspace ? (
                  <div className="flex gap-1">
                    {([{ id: 'all' as const, label: '全部' }, { id: 'retail' as const, label: '零售' }, { id: 'wholesale' as const, label: '批發' }, { id: 'pending' as const, label: '待審核' }]).map(f => (
                      <button key={f.id} onClick={() => setAdminMemberTypeFilter(f.id)} className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all relative ${adminMemberTypeFilter === f.id ? (f.id === 'pending' ? 'bg-orange-500 text-white shadow-lg' : 'bg-slate-900 text-white shadow-lg') : 'bg-white text-slate-400 border border-slate-200 hover:bg-slate-50'}`}>
                        {f.label}
                        {f.id === 'pending' && pendingWholesaleCount > 0 && (
                          <span className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-red-500 text-white text-[9px] font-black rounded-full flex items-center justify-center">{pendingWholesaleCount}</span>
                        )}
                      </button>
                    ))}
                  </div>
                  ) : null}
                </div>
                <button onClick={() => { const isWS = moduleWorkspace === 'WHOLESALE'; setEditingMember({ id: `u-${Date.now()}`, name: '', email: '', phoneNumber: '', points: 0, tier: 'Bronze', role: 'customer', memberType: isWS ? 'wholesale' : 'retail', wholesaleBrand: isWS ? adminWholesaleBrand : undefined, wholesaleStatus: isWS ? 'pending' : undefined, wholesalePriceTier: isWS ? 'P0' : undefined, isWholesaleActive: isWS ? true : undefined, addresses: [] }); setEditingMemberPassword(''); }} className="px-6 py-3 bg-slate-900 text-white rounded-2xl font-black text-xs flex items-center gap-2 shadow-xl"><Plus size={16}/> {moduleWorkspace === 'WHOLESALE' ? '新增批發客' : '新增會員'}</button>
             </div>
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredAdminMembers.length === 0 && (
                  <div className="col-span-full text-center text-slate-400 font-bold py-10">
                    {moduleWorkspace === 'WHOLESALE' ? `尚無${adminWholesaleBrand === 'GHFOODS' ? 'GH Foods' : 'Coolfood'}批發客戶` : '尚未有會員'}
                  </div>
                )}
                {filteredAdminMembers.map(m => (
                   <div key={m.id} className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm space-y-6 hover:shadow-md transition-shadow relative overflow-hidden group">
                      <div className="flex justify-between items-start">
                         <div className="flex items-center gap-4">
                            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all ${m.memberType === 'wholesale' ? 'bg-orange-100 text-orange-500 group-hover:bg-orange-500 group-hover:text-white' : 'bg-slate-100 text-slate-400 group-hover:bg-blue-600 group-hover:text-white'}`}><User size={28}/></div>
                            <div>
                              <p className="font-black text-slate-900">{m.name}</p>
                              {m.memberType === 'wholesale' && m.companyName && <p className="text-[11px] text-slate-500 font-bold">{m.companyName}</p>}
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <TierBadge tier={m.tier}/>
                                <span className={`text-[9px] font-black px-1.5 py-0.5 rounded-md ${m.memberType === 'wholesale' ? 'bg-orange-100 text-orange-600' : 'bg-blue-50 text-blue-400'}`}>{m.memberType === 'wholesale' ? `批發 ${m.wholesalePriceTier || 'P0'}` : '零售'}</span>
                                {m.memberType === 'wholesale' && m.wholesaleBrand && <span className={`text-[9px] font-black px-1.5 py-0.5 rounded-md ${m.wholesaleBrand === 'GHFOODS' ? 'bg-emerald-50 text-emerald-600' : 'bg-blue-50 text-blue-600'}`}>{m.wholesaleBrand === 'GHFOODS' ? 'GH Foods' : 'Coolfood'}</span>}
                                {m.memberType === 'wholesale' && m.wholesaleStatus === 'pending' && <span className="text-[9px] font-black px-1.5 py-0.5 rounded-md bg-amber-100 text-amber-600 animate-pulse">待審核</span>}
                                {m.memberType === 'wholesale' && m.wholesaleStatus === 'approved' && <span className="text-[9px] font-black px-1.5 py-0.5 rounded-md bg-emerald-50 text-emerald-600">已批准</span>}
                                {m.memberType === 'wholesale' && m.wholesaleStatus === 'rejected' && <span className="text-[9px] font-black px-1.5 py-0.5 rounded-md bg-red-100 text-red-600">已拒絕</span>}
                                {m.memberType === 'wholesale' && m.brUpdateRequired && <span className="text-[9px] font-black px-1.5 py-0.5 rounded-md bg-red-50 text-red-500 border border-red-200">待更新 BR</span>}
                                {m.memberType === 'wholesale' && m.isWholesaleActive === false && <span className="text-[9px] font-black px-1.5 py-0.5 rounded-md bg-slate-100 text-slate-400">停用</span>}
                              </div>
                            </div>
                         </div>
                         <button onClick={() => { setEditingMember(m); setEditingMemberPassword(''); }} className="p-3 bg-slate-50 rounded-2xl text-slate-400 hover:text-blue-600 transition-colors"><MoreHorizontal size={20}/></button>
                      </div>
                      <div className="grid grid-cols-1 gap-4">
                         <div className="space-y-1"><p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">積分</p><p className="font-black text-slate-900">{m.points} pts</p></div>
                      </div>
                      <div className="space-y-2 pt-4 border-t border-slate-50">
                         {m.clientCode && <div className="flex items-center gap-2 text-xs font-bold text-slate-500"><span className="font-mono bg-slate-100 px-1.5 py-0.5 rounded text-[10px]">{m.clientCode}</span></div>}
                         {m.companyName && <div className="flex items-center gap-2 text-xs font-bold text-slate-600"><Package size={14} className="text-orange-400"/> {m.companyName}</div>}
                         <div className="flex items-center gap-2 text-xs font-bold text-slate-400"><Smartphone size={14}/> {m.phoneNumber ?? '—'}</div>
                         <div className="flex items-center gap-2 text-xs font-bold text-slate-400"><Mail size={14}/> {m.email ?? '—'}</div>
                         {m.memberType === 'wholesale' && m.deliveryAddress && <div className="flex items-center gap-2 text-xs font-bold text-slate-400 truncate"><MapPin size={14}/> {m.deliveryAddress}</div>}
                      </div>
                   </div>
                ))}
             </div>
          </div>
        );
      case 'coupons':
        return (
          <div className="space-y-6 animate-fade-in">
            <div className="flex gap-2 flex-wrap">
              {(['coupons', 'distribute', 'points', 'welcome'] as const).map(tab => (
                <button key={tab} onClick={() => setCouponAdminTab(tab)} className={`px-5 py-2.5 rounded-xl text-xs font-black transition-all ${couponAdminTab === tab ? 'bg-slate-900 text-white shadow-lg' : 'bg-white text-slate-400 border border-slate-200'}`}>
                  {tab === 'coupons' ? '優惠券管理' : tab === 'distribute' ? '派發優惠券' : tab === 'points' ? '積分設定' : '新會員優惠'}
                </button>
              ))}
            </div>

            {couponAdminTab === 'coupons' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <p className="text-sm font-bold text-slate-500">建立和管理優惠券模板</p>
                  <button onClick={() => setEditingCoupon({ id: `cpn-${Date.now()}`, name: '', couponType: 'fixed_amount', discountValue: 0, minSpend: 100, expiryDays: 30, isWelcomeCoupon: false, isPointsShop: false, distributedCount: 0, isActive: true })} className="px-6 py-3 bg-slate-900 text-white rounded-2xl font-black text-xs flex items-center gap-2 shadow-xl"><Plus size={16}/> 新增優惠券</button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {coupons.map(c => (
                    <div key={c.id} className="bg-white rounded-[2rem] border border-slate-100 shadow-sm p-6 space-y-3">
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-black text-slate-900">{c.name}</p>
                          <p className="text-[10px] text-slate-400 font-bold mt-0.5">
                            {c.couponType === 'fixed_amount' && `減 $${c.discountValue}`}
                            {c.couponType === 'percentage' && `${c.discountValue}% 折扣`}
                            {c.couponType === 'free_delivery' && '免運費'}
                            {c.couponType === 'free_product' && '免費贈品'}
                          </p>
                        </div>
                        <div className="flex gap-1">
                          <button onClick={() => setEditingCoupon(c)} className="p-2 rounded-xl text-slate-400 hover:text-blue-600 hover:bg-blue-50"><Edit size={14}/></button>
                          <button onClick={async () => { if (!confirm('確定刪除？')) return; await supabase.from('coupons').delete().eq('id', c.id); setCoupons(prev => prev.filter(x => x.id !== c.id)); showToast('已刪除'); }} className="p-2 rounded-xl text-slate-400 hover:text-rose-500 hover:bg-rose-50"><Trash2 size={14}/></button>
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        <span className="text-[9px] font-bold bg-slate-50 text-slate-400 px-2 py-0.5 rounded-full">滿${c.minSpend}</span>
                        <span className="text-[9px] font-bold bg-slate-50 text-slate-400 px-2 py-0.5 rounded-full">{c.expiryDays}天</span>
                        {c.isPointsShop && <span className="text-[9px] font-bold bg-amber-50 text-amber-500 px-2 py-0.5 rounded-full">{c.pointsCost} 積分兌換</span>}
                        {c.isWelcomeCoupon && <span className="text-[9px] font-bold bg-emerald-50 text-emerald-500 px-2 py-0.5 rounded-full">新會員</span>}
                        <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${c.isActive ? 'bg-emerald-50 text-emerald-500' : 'bg-rose-50 text-rose-400'}`}>{c.isActive ? '啟用' : '停用'}</span>
                      </div>
                      <p className="text-[10px] text-slate-300 font-bold">已派發: {c.distributedCount}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {couponAdminTab === 'distribute' && (
              <div className="space-y-6">
                <p className="text-sm font-bold text-slate-500">選擇優惠券和會員，批量派發</p>
                <div className="bg-white rounded-[2rem] border border-slate-100 shadow-sm p-6 space-y-4">
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 mb-1 block">選擇優惠券</label>
                    <select value={couponDistributeCouponId} onChange={e => setCouponDistributeCouponId(e.target.value)} className="w-full p-3 bg-slate-50 rounded-xl text-sm font-bold border border-slate-100">
                      <option value="">-- 請選擇 --</option>
                      {coupons.filter(c => c.isActive).map(c => <option key={c.id} value={c.id}>{c.name} ({c.couponType === 'fixed_amount' ? `$${c.discountValue} off` : c.couponType === 'percentage' ? `${c.discountValue}%` : c.couponType})</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 mb-1 block">搜尋會員</label>
                    <input value={couponDistributeSearch} onChange={e => setCouponDistributeSearch(e.target.value)} placeholder="搜尋姓名、電話..." className="w-full p-3 bg-slate-50 rounded-xl text-sm font-bold border border-slate-100" />
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={() => { const retailIds = members.filter(m => m.memberType === 'retail').map(m => m.id); setCouponDistributeSelected(new Set(retailIds)); }} className="px-3 py-1.5 bg-blue-50 text-blue-600 rounded-lg text-[10px] font-black">全選零售</button>
                    <button onClick={() => setCouponDistributeSelected(new Set())} className="px-3 py-1.5 bg-slate-50 text-slate-400 rounded-lg text-[10px] font-black">清除</button>
                    <span className="text-[10px] text-slate-400 font-bold ml-auto">已選: {couponDistributeSelected.size}</span>
                  </div>
                  <div className="max-h-64 overflow-y-auto space-y-1">
                    {members.filter(m => m.memberType === 'retail' && (!couponDistributeSearch || m.name.includes(couponDistributeSearch) || (m.phoneNumber || '').includes(couponDistributeSearch))).map(m => (
                      <label key={m.id} className="flex items-center gap-3 p-2 rounded-xl hover:bg-slate-50 cursor-pointer">
                        <input type="checkbox" checked={couponDistributeSelected.has(m.id)} onChange={e => { const next = new Set(couponDistributeSelected); e.target.checked ? next.add(m.id) : next.delete(m.id); setCouponDistributeSelected(next); }} className="rounded" />
                        <span className="text-xs font-bold text-slate-700">{m.name}</span>
                        <span className="text-[10px] text-slate-300 font-bold">{m.phoneNumber}</span>
                      </label>
                    ))}
                  </div>
                  <button
                    disabled={!couponDistributeCouponId || couponDistributeSelected.size === 0}
                    onClick={async () => {
                      const cpn = coupons.find(c => c.id === couponDistributeCouponId);
                      if (!cpn) return;
                      const memberIds = Array.from(couponDistributeSelected);
                      const expiresAt = new Date(Date.now() + (cpn.expiryDays || 30) * 86400000).toISOString();
                      const rows = memberIds.map(mid => ({
                        id: `mc-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
                        member_id: mid,
                        coupon_id: cpn.id,
                        status: 'available',
                        source: 'admin',
                        expires_at: expiresAt,
                      }));
                      const { error } = await supabase.from('member_coupons').insert(rows);
                      if (error) { showToast('派發失敗: ' + error.message, 'error'); return; }
                      await supabase.from('coupons').update({ distributed_count: cpn.distributedCount + memberIds.length }).eq('id', cpn.id);
                      setCoupons(prev => prev.map(c => c.id === cpn.id ? { ...c, distributedCount: c.distributedCount + memberIds.length } : c));
                      showToast(`已派發 ${memberIds.length} 張優惠券`);
                      setCouponDistributeSelected(new Set());
                    }}
                    className="w-full py-3 bg-slate-900 text-white rounded-2xl font-black text-xs shadow-xl disabled:opacity-30"
                  >
                    派發給 {couponDistributeSelected.size} 位會員
                  </button>
                </div>
              </div>
            )}

            {couponAdminTab === 'points' && (
              <div className="space-y-6">
                <p className="text-sm font-bold text-slate-500">設定消費金額與積分的兌換比例</p>
                <div className="bg-white rounded-[2rem] border border-slate-100 shadow-sm p-6 space-y-4">
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 mb-1 block">每消費多少元 = 1 積分</label>
                    <div className="flex items-center gap-3">
                      <span className="text-sm font-black text-slate-400">$</span>
                      <input type="number" min={1} value={pointsConfig.dollarsPerPoint} onChange={e => setPointsConfig({ ...pointsConfig, dollarsPerPoint: Math.max(1, Number(e.target.value) || 10) })} className="flex-1 p-3 bg-slate-50 rounded-xl text-sm font-bold border border-slate-100" />
                      <span className="text-sm font-black text-slate-400">= 1 積分</span>
                    </div>
                    <p className="text-[10px] text-slate-300 font-bold mt-2">例：客人消費 $300，比例設為 $10 = 1 積分，則獲得 30 積分（無條件捨去）</p>
                  </div>
                  <button
                    onClick={async () => {
                      await supabase.from('site_config').upsert({ id: 'points_config', value: pointsConfig });
                      showToast('積分設定已保存');
                    }}
                    className="w-full py-3 bg-slate-900 text-white rounded-2xl font-black text-xs shadow-xl"
                  >
                    保存積分設定
                  </button>
                </div>
              </div>
            )}

            {couponAdminTab === 'welcome' && (
              <div className="space-y-6">
                <p className="text-sm font-bold text-slate-500">新會員註冊時自動派發優惠券</p>
                <div className="bg-white rounded-[2rem] border border-slate-100 shadow-sm p-6 space-y-4">
                  <label className="flex items-center gap-3 cursor-pointer">
                    <input type="checkbox" checked={welcomeCouponsConfig.enabled} onChange={e => setWelcomeCouponsConfig(prev => ({ ...prev, enabled: e.target.checked }))} className="rounded" />
                    <span className="text-sm font-bold text-slate-700">啟用新會員自動派發優惠券</span>
                  </label>
                  {welcomeCouponsConfig.enabled && (
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-slate-500 block">選擇要自動派發的優惠券（可多選）</label>
                      {coupons.filter(c => c.isActive).map(c => (
                        <label key={c.id} className="flex items-center gap-3 p-2 rounded-xl hover:bg-slate-50 cursor-pointer">
                          <input type="checkbox" checked={welcomeCouponsConfig.couponTemplateIds.includes(c.id)} onChange={e => {
                            setWelcomeCouponsConfig(prev => ({
                              ...prev,
                              couponTemplateIds: e.target.checked
                                ? [...prev.couponTemplateIds, c.id]
                                : prev.couponTemplateIds.filter(id => id !== c.id)
                            }));
                          }} className="rounded" />
                          <span className="text-xs font-bold text-slate-700">{c.name}</span>
                          <span className="text-[10px] text-slate-300">
                            {c.couponType === 'fixed_amount' ? `$${c.discountValue} off` : c.couponType === 'percentage' ? `${c.discountValue}%` : c.couponType}
                          </span>
                        </label>
                      ))}
                    </div>
                  )}
                  <button
                    onClick={async () => {
                      await supabase.from('site_config').upsert({ id: 'welcome_coupons_config', value: welcomeCouponsConfig });
                      showToast('新會員優惠設定已保存');
                    }}
                    className="w-full py-3 bg-slate-900 text-white rounded-2xl font-black text-xs shadow-xl"
                  >
                    保存設定
                  </button>
                </div>
              </div>
            )}

            {/* ── Coupon Edit Modal ── */}
            {editingCoupon && (
              <div className="fixed inset-0 bg-black/50 z-[100] flex items-center justify-center p-4" onClick={() => setEditingCoupon(null)}>
                <div className="bg-white rounded-[2.5rem] shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
                  <div className="p-8 space-y-5">
                    <h3 className="text-lg font-black text-slate-900">{coupons.some(c => c.id === editingCoupon.id) ? '編輯優惠券' : '新增優惠券'}</h3>
                    <div><label className="text-[10px] font-bold text-slate-500 mb-1 block">優惠券名稱</label><input value={editingCoupon.name} onChange={e => setEditingCoupon({ ...editingCoupon, name: e.target.value })} className="w-full p-3 bg-slate-50 rounded-xl text-sm font-bold border border-slate-100" /></div>
                    <div><label className="text-[10px] font-bold text-slate-500 mb-1 block">描述（選填）</label><input value={editingCoupon.description || ''} onChange={e => setEditingCoupon({ ...editingCoupon, description: e.target.value })} className="w-full p-3 bg-slate-50 rounded-xl text-sm font-bold border border-slate-100" /></div>
                    <div><label className="text-[10px] font-bold text-slate-500 mb-1 block">類型</label>
                      <select value={editingCoupon.couponType} onChange={e => setEditingCoupon({ ...editingCoupon, couponType: e.target.value as CouponType })} className="w-full p-3 bg-slate-50 rounded-xl text-sm font-bold border border-slate-100">
                        <option value="fixed_amount">固定金額折扣</option>
                        <option value="percentage">百分比折扣</option>
                        <option value="free_delivery">免運費</option>
                        <option value="free_product">免費贈品</option>
                      </select>
                    </div>
                    {(editingCoupon.couponType === 'fixed_amount' || editingCoupon.couponType === 'percentage') && (
                      <div><label className="text-[10px] font-bold text-slate-500 mb-1 block">{editingCoupon.couponType === 'fixed_amount' ? '折扣金額 ($)' : '折扣百分比 (%)'}</label><input type="number" min={0} value={editingCoupon.discountValue} onChange={e => setEditingCoupon({ ...editingCoupon, discountValue: Number(e.target.value) || 0 })} className="w-full p-3 bg-slate-50 rounded-xl text-sm font-bold border border-slate-100" /></div>
                    )}
                    {editingCoupon.couponType === 'free_product' && (
                      <div><label className="text-[10px] font-bold text-slate-500 mb-1 block">關聯產品 ID</label><input value={editingCoupon.linkedProductId || ''} onChange={e => setEditingCoupon({ ...editingCoupon, linkedProductId: e.target.value })} className="w-full p-3 bg-slate-50 rounded-xl text-sm font-bold border border-slate-100" placeholder="輸入產品 ID" /></div>
                    )}
                    <div><label className="text-[10px] font-bold text-slate-500 mb-1 block">最低消費 ($)</label><input type="number" min={0} value={editingCoupon.minSpend} onChange={e => setEditingCoupon({ ...editingCoupon, minSpend: Number(e.target.value) || 0 })} className="w-full p-3 bg-slate-50 rounded-xl text-sm font-bold border border-slate-100" /></div>
                    <div><label className="text-[10px] font-bold text-slate-500 mb-1 block">有效期（天）</label><input type="number" min={1} value={editingCoupon.expiryDays} onChange={e => setEditingCoupon({ ...editingCoupon, expiryDays: Number(e.target.value) || 30 })} className="w-full p-3 bg-slate-50 rounded-xl text-sm font-bold border border-slate-100" /></div>
                    <label className="flex items-center gap-3 cursor-pointer"><input type="checkbox" checked={editingCoupon.isPointsShop} onChange={e => setEditingCoupon({ ...editingCoupon, isPointsShop: e.target.checked })} className="rounded" /><span className="text-sm font-bold text-slate-700">在積分商店上架</span></label>
                    {editingCoupon.isPointsShop && (
                      <div><label className="text-[10px] font-bold text-slate-500 mb-1 block">兌換所需積分</label><input type="number" min={1} value={editingCoupon.pointsCost || 0} onChange={e => setEditingCoupon({ ...editingCoupon, pointsCost: Number(e.target.value) || 0 })} className="w-full p-3 bg-slate-50 rounded-xl text-sm font-bold border border-slate-100" /></div>
                    )}
                    <label className="flex items-center gap-3 cursor-pointer"><input type="checkbox" checked={editingCoupon.isActive} onChange={e => setEditingCoupon({ ...editingCoupon, isActive: e.target.checked })} className="rounded" /><span className="text-sm font-bold text-slate-700">啟用</span></label>
                  </div>
                  <div className="p-8 bg-slate-50 border-t border-slate-100 flex justify-end gap-3">
                    <button onClick={() => setEditingCoupon(null)} className="px-6 py-3 bg-white text-slate-500 rounded-2xl font-black text-xs border border-slate-200">取消</button>
                    <button onClick={async () => {
                      if (!editingCoupon.name.trim()) { showToast('請輸入名稱', 'error'); return; }
                      const row = mapCouponToRow(editingCoupon);
                      const { error } = await supabase.from('coupons').upsert({ ...row, updated_at: new Date().toISOString() });
                      if (error) { showToast('保存失敗: ' + error.message, 'error'); return; }
                      setCoupons(prev => {
                        const exists = prev.find(c => c.id === editingCoupon.id);
                        return exists ? prev.map(c => c.id === editingCoupon.id ? editingCoupon : c) : [editingCoupon, ...prev];
                      });
                      setEditingCoupon(null);
                      showToast('優惠券已保存');
                    }} className="px-8 py-3 bg-slate-900 text-white rounded-2xl font-black text-xs shadow-xl flex items-center gap-2"><Save size={14}/> 保存</button>
                  </div>
                </div>
              </div>
            )}
          </div>
        );
      case 'pricing': {
        const wsRules: WholesalePricingRules = siteConfig.wholesalePricingRules || { targetMarginFactor: 0.88, priceTiers: [] };
        if (!wsRules.priceTiers) wsRules.priceTiers = [];
        const wsExampleCost = 100;
        const wsP0 = wsExampleCost / wsRules.targetMarginFactor;
        return (
          <div className="space-y-8 animate-fade-in pb-20">
            {/* ── Tab 切換 — only show when not pinned to a workspace ── */}
            {!moduleWorkspace && (
            <div className="flex gap-2">
              {([
                { id: 'retail' as const, label: '零售定價設定', icon: <ShoppingBag size={16}/> },
                { id: 'wholesale' as const, label: '批發定價設定', icon: <Truck size={16}/> },
              ]).map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setPricingSubTab(tab.id)}
                  className={`flex items-center gap-2 px-6 py-3 rounded-2xl text-sm font-black transition-all ${pricingSubTab === tab.id ? 'bg-slate-900 text-white shadow-xl' : 'bg-white text-slate-500 border border-slate-200 hover:bg-slate-50'}`}
                >
                  {tab.icon}
                  {tab.label}
                </button>
              ))}
            </div>
            )}

            {pricingSubTab === 'retail' && (() => {
              const rtFactor = siteConfig.pricingRules?.targetMarginFactor ?? 0.88;
              const rtExampleCost = 100;
              const rtSuggestedPrice = rtExampleCost / rtFactor;
              const rtMarginPct = Math.round((1 - rtFactor) * 100);
              // Global % discounts removed; pricing is now per-product memberPrice + coupon system

              const applyRetailFactor = (applyToOverrides: boolean) => {
                setProducts(prev => prev.map(p => {
                  if (!applyToOverrides && retailOverrideIds.has(p.id)) return p;
                  const linkedIng = ingredients.find(i => i.id === p.ingredientId);
                  const perLbCost = computeProductCost(p, linkedIng, costItems);
                  if (perLbCost <= 0) return p;
                  const packCost = computePackCost(perLbCost, p.packWeightLb, p.pricingMode);
                  return { ...p, price: roundPrice(packCost / rtFactor) };
                }));
                if (applyToOverrides) setRetailOverrideIds(new Set());
                setPendingApplyTab(null);
              };

              return (
              <>
                {/* ── 零售目標利潤率 ── */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm space-y-4">
                    <div className="flex items-center gap-2"><div className="p-2.5 bg-orange-50 text-orange-600 rounded-xl"><Percent size={18}/></div><h4 className="font-black text-sm">目標利潤率（零售基準）</h4></div>
                    <p className="text-[10px] text-slate-400 font-bold">Target Margin Factor — 從成本反算建議售價，套用後寫入各產品售價</p>
                    <div className="flex items-center gap-2">
                      <input
                        type="number" min="0.01" max="1" step="0.01"
                        value={rtFactor}
                        onChange={e => setSiteConfig({...siteConfig, pricingRules: {...siteConfig.pricingRules!, targetMarginFactor: Number(e.target.value) || 0.88}})}
                        className="flex-1 p-4 bg-slate-50 rounded-2xl font-black text-xl text-center border border-slate-100 focus:ring-2 focus:ring-orange-100"
                      />
                    </div>
                    <p className="text-[9px] text-slate-300 font-bold">0.88 = 12% 毛利、0.85 = 15% 毛利、0.80 = 20% 毛利</p>
                    <div className="flex gap-2 pt-1 flex-wrap">
                      <button onClick={async () => {
                        try {
                          const rulesWithOverrides = { ...siteConfig.pricingRules!, retailOverrideIds: [...retailOverrideIds] };
                          await supabase.from('site_config').upsert({ id: 'pricing_rules', value: rulesWithOverrides });
                          showToast('零售設定已儲存');
                        } catch (err: any) { showToast(`儲存失敗：${err.message}`, 'error'); }
                      }} className="flex items-center gap-1.5 px-4 py-2 bg-slate-900 text-white rounded-xl text-xs font-black shadow active:scale-95 transition-all"><Save size={13}/> 儲存設定</button>
                      <button onClick={() => {
                        if (retailOverrideIds.size > 0) { setPendingApplyTab('retail'); }
                        else { applyRetailFactor(true); showToast('已套用利潤率至全部產品'); }
                      }} className="flex items-center gap-1.5 px-4 py-2 bg-orange-500 text-white rounded-xl text-xs font-black shadow active:scale-95 transition-all"><Zap size={13}/> 套用至所有產品</button>
                    </div>
                  </div>
                  <div className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm space-y-4">
                    <div className="flex items-center gap-2"><div className="p-2.5 bg-slate-100 text-slate-600 rounded-xl"><Zap size={18}/></div><h4 className="font-black text-sm">定價預覽（成本基礎）</h4></div>
                    <p className="text-[10px] text-slate-400 font-bold">如果 成本/出成率 = $100</p>
                    <div className="space-y-2 text-xs">
                      <div className="flex justify-between items-center p-2.5 bg-slate-50 rounded-xl">
                        <span className="text-slate-500 font-bold">📦 成本</span>
                        <span className="font-black text-slate-900">${formatMoney(rtExampleCost)}</span>
                      </div>
                      <div className="flex justify-between items-center p-2.5 bg-orange-50 rounded-xl">
                        <div>
                          <span className="text-orange-600 font-bold">建議售價</span>
                          <span className="text-[9px] text-orange-400 ml-1">÷ {rtFactor} ({rtMarginPct}% 毛利)</span>
                        </div>
                        <span className="font-black text-orange-700">${formatMoney(rtSuggestedPrice)}</span>
                      </div>
                      <div className="flex justify-between items-center p-2.5 bg-blue-50 rounded-xl">
                        <span className="text-blue-600 font-bold">👤 會員價</span>
                        <span className="font-black text-blue-700">(由產品折扣價決定)</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* ── 衝突提示橫幅 ── */}
                {pendingApplyTab === 'retail' && (
                  <div className="bg-amber-50 border border-amber-200 rounded-[2rem] p-6 flex flex-col md:flex-row items-start md:items-center gap-4">
                    <div className="flex-1">
                      <p className="font-black text-amber-800 text-sm">有 {retailOverrideIds.size} 個產品已手動調整價格（橙色標示）</p>
                      <p className="text-[11px] text-amber-600 font-bold mt-1">套用新利潤率係數時，要覆蓋這些手動調整嗎？</p>
                    </div>
                    <div className="flex gap-2 flex-wrap">
                      <button onClick={() => { applyRetailFactor(true); showToast('已套用利潤率至全部產品，清除手動標記'); }} className="px-4 py-2 bg-amber-600 text-white rounded-xl text-xs font-black active:scale-95 transition-all">全部覆蓋，清除手動標記</button>
                      <button onClick={() => { applyRetailFactor(false); showToast(`已套用利潤率，保留 ${retailOverrideIds.size} 個手動價格`); }} className="px-4 py-2 bg-white border border-amber-300 text-amber-700 rounded-xl text-xs font-black active:scale-95 transition-all">只套用未修改的產品</button>
                      <button onClick={() => setPendingApplyTab(null)} className="px-4 py-2 bg-white border border-slate-200 text-slate-500 rounded-xl text-xs font-black active:scale-95 transition-all">取消</button>
                    </div>
                  </div>
                )}

                {/* ── 零售定價規則卡片 ── */}
                <div className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm space-y-4">
                  <div className="flex items-center gap-2"><div className="p-2.5 bg-blue-50 text-blue-600 rounded-xl"><Tag size={18}/></div><h4 className="font-black text-sm">定價說明</h4></div>
                  <p className="text-[10px] text-slate-400 font-bold">會員定價：訪客看「售價」，會員看「折扣價」（如有設定）。折扣透過優惠券系統派發（前往「優惠券/積分」管理）。</p>
                </div>

                {/* ── 零售全產品定價矩陣 ── */}
                <div className="bg-white rounded-[3rem] border border-slate-100 shadow-sm overflow-hidden">
                  <div className="p-8 pb-4 flex items-center justify-between flex-wrap gap-3">
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 bg-emerald-50 text-emerald-600 rounded-xl"><ClipboardList size={18}/></div>
                      <h4 className="font-black text-lg">全產品定價一覽</h4>
                      {retailOverrideIds.size > 0 && (
                        <span className="px-2.5 py-1 bg-amber-100 text-amber-700 rounded-full text-[10px] font-black">{retailOverrideIds.size} 手改</span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <button onClick={() => setShowCostColumns(v => !v)} className={`px-4 py-2 rounded-xl text-xs font-black transition-colors ${showCostColumns ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}>
                        {showCostColumns ? '隱藏成本' : '顯示成本'}
                      </button>
                      {retailOverrideIds.size > 0 && (
                        <button onClick={() => setRetailOverrideIds(new Set())} className="px-4 py-2 bg-amber-50 border border-amber-200 text-amber-700 rounded-xl text-xs font-black hover:bg-amber-100 transition-colors">
                          清除手動標記
                        </button>
                      )}
                      <button onClick={() => {
                        const allIds = products.map(p => p.id);
                        const current = siteConfig.pricingRules?.excludedProductIds || [];
                        if (current.length === 0) {
                          setSiteConfig({...siteConfig, pricingRules: {...siteConfig.pricingRules!, excludedProductIds: allIds}});
                          showToast('已排除全部產品');
                        } else {
                          setSiteConfig({...siteConfig, pricingRules: {...siteConfig.pricingRules!, excludedProductIds: []}});
                          showToast('已對全部產品實行折扣');
                        }
                      }} className="px-4 py-2 bg-slate-100 rounded-xl text-xs font-black text-slate-600 hover:bg-slate-200 transition-colors">
                        {(siteConfig.pricingRules?.excludedProductIds?.length || 0) > 0 ? '✓ 全部實行' : '✗ 全部排除'}
                      </button>
                      <button onClick={async () => {
                        try {
                          const rulesWithOverrides = { ...siteConfig.pricingRules!, retailOverrideIds: [...retailOverrideIds] };
                          await supabase.from('site_config').upsert({ id: 'pricing_rules', value: rulesWithOverrides });
                          await supabase.from('site_config').upsert({ id: 'site_branding', value: { logoText: siteConfig.logoText, logoIcon: siteConfig.logoIcon, logoUrl: siteConfig.logoUrl, accentColor: siteConfig.accentColor } });
                          for (const p of products) { await supabase.from('products').update({ price: p.price, member_price: p.memberPrice }).eq('id', p.id); }
                          showToast('零售定價已儲存');
                        } catch (err: any) {
                          showToast(`儲存失敗：${err.message}`, 'error');
                        }
                      }} className="px-4 py-2 bg-emerald-600 text-white rounded-xl text-xs font-black shadow-lg active:scale-95 transition-all flex items-center gap-1.5"><Save size={14}/> 儲存所有價格</button>
                    </div>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs">
                      <thead>
                        <tr className="bg-slate-50 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                          <th className="text-left px-6 py-3 w-10">參與</th>
                          <th className="text-left px-4 py-3">產品</th>
                          <th className="text-right px-4 py-3">售價</th>
                          <th className="text-right px-4 py-3">折扣價</th>
                          <th className="text-right px-4 py-3 text-blue-500">會員價</th>
                          {showCostColumns && <th className="text-right px-4 py-3 text-amber-500">成本</th>}
                          {showCostColumns && <th className="text-right px-4 py-3 text-emerald-500">毛利%</th>}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-50">
                        {products.map(p => {
                          const excluded = siteConfig.pricingRules?.excludedProductIds?.includes(p.id) || false;
                          const hasDiscount = p.memberPrice > 0 && p.memberPrice < p.price;
                          const base = hasDiscount ? p.memberPrice : p.price;
                          const memberP = hasDiscount ? p.memberPrice : p.price;
                          const linkedIng = ingredients.find(i => i.id === p.ingredientId);
                          const perLbCost = computeProductCost(p, linkedIng, costItems);
                          const totalCost = computePackCost(perLbCost, p.packWeightLb, p.pricingMode);
                          const marginPct = totalCost > 0 ? Math.round(((p.price - totalCost) / p.price) * 100) : null;
                          const isOverridden = retailOverrideIds.has(p.id);
                          return (
                            <tr key={p.id} className={`transition-colors ${excluded ? 'opacity-50' : ''} ${isOverridden ? 'bg-amber-50/60' : 'hover:bg-slate-50/50'}`}>
                              <td className="px-6 py-3">
                                <button onClick={() => {
                                  const ids = siteConfig.pricingRules?.excludedProductIds || [];
                                  const newIds = excluded ? ids.filter(x => x !== p.id) : [...ids, p.id];
                                  setSiteConfig({...siteConfig, pricingRules: {...siteConfig.pricingRules!, excludedProductIds: newIds}});
                                }} className={`w-5 h-5 rounded-md border-2 flex items-center justify-center transition-all ${excluded ? 'border-slate-200 bg-white' : 'border-emerald-500 bg-emerald-500 text-white'}`}>
                                  {!excluded && <Check size={12} strokeWidth={3}/>}
                                </button>
                              </td>
                              <td className="px-4 py-3">
                                <div className="flex items-center gap-2">
                                  <div className="w-8 h-8 bg-slate-50 rounded-lg flex items-center justify-center text-base overflow-hidden flex-shrink-0 border border-slate-100">
                                    {isMediaUrl(p.image) ? <img src={p.image} className="w-full h-full object-cover" alt="" /> : <span className="text-sm">{p.image || '📦'}</span>}
                                  </div>
                                  <div className="flex items-center gap-1.5">
                                    <span className="font-bold text-slate-700">{p.name}</span>
                                    {isOverridden && <span className="px-1.5 py-0.5 bg-amber-200 text-amber-800 rounded text-[9px] font-black">手改</span>}
                                  </div>
                                </div>
                              </td>
                              <td className="text-right px-4 py-3">
                                <input
                                  type="number" min="0" value={p.price}
                                  onChange={e => {
                                    setProducts(prev => prev.map(x => x.id === p.id ? { ...x, price: Number(e.target.value) || 0 } : x));
                                    setRetailOverrideIds(prev => new Set([...prev, p.id]));
                                  }}
                                  className={`w-20 p-1 rounded-lg font-bold text-right text-xs border ${isOverridden ? 'bg-amber-50 border-amber-300 text-amber-900' : 'bg-slate-50 border-slate-200 text-slate-900'}`}
                                />
                              </td>
                              <td className="text-right px-4 py-3">
                                <input
                                  type="number" min="0" value={p.memberPrice || ''}
                                  onChange={e => {
                                    setProducts(prev => prev.map(x => x.id === p.id ? { ...x, memberPrice: Number(e.target.value) || 0 } : x));
                                    setRetailOverrideIds(prev => new Set([...prev, p.id]));
                                  }}
                                  placeholder="—"
                                  className={`w-20 p-1 rounded-lg font-bold text-right text-xs border ${isOverridden ? 'bg-amber-50 border-amber-300 text-amber-900' : 'bg-slate-50 border-slate-200 text-slate-900'}`}
                                />
                              </td>
                              <td className="text-right px-4 py-3">
                                {hasDiscount ? <span className="font-black text-blue-600">${formatMoney(memberP)}</span> : <span className="text-slate-300">${formatMoney(base)}</span>}
                              </td>
                              {showCostColumns && (
                                <td className="text-right px-4 py-3 font-bold text-amber-600">{totalCost > 0 ? `$${formatMoney(totalCost)}` : <span className="text-slate-300">—</span>}</td>
                              )}
                              {showCostColumns && (
                                <td className={`text-right px-4 py-3 font-black ${marginPct !== null ? (marginPct >= 0 ? 'text-emerald-600' : 'text-rose-600') : 'text-slate-300'}`}>
                                  {marginPct !== null ? `${marginPct}%` : '—'}
                                </td>
                              )}
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              </>
              );
            })()}

            {pricingSubTab === 'wholesale' && moduleWorkspace !== 'COOLFOOD_RETAIL' && (() => {
              const wsOverrideCount = Object.keys(wholesalePriceOverrides).length;

              const applyWsFactor = (applyToOverrides: boolean) => {
                const newOverrides = { ...wholesalePriceOverrides };
                products.forEach(p => {
                  if (!applyToOverrides && wholesalePriceOverrides[p.id] != null) return;
                  const linkedIng = ingredients.find(i => i.id === p.ingredientId);
                  const perLbCost = computeProductCost(p, linkedIng, costItems);
                  const totalCost = computePackCost(perLbCost, p.packWeightLb, p.pricingMode);
                  if (totalCost <= 0) return;
                  delete newOverrides[p.id];
                });
                if (applyToOverrides) setWholesalePriceOverrides({});
                else setWholesalePriceOverrides(newOverrides);
                setPendingApplyTab(null);
              };

              return (
              <>
                {/* ── 批發定價全局參數 ── */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm space-y-4">
                    <div className="flex items-center gap-2"><div className="p-2.5 bg-orange-50 text-orange-600 rounded-xl"><Percent size={18}/></div><h4 className="font-black text-sm">目標利潤率（P0 基準）</h4></div>
                    <p className="text-[10px] text-slate-400 font-bold">Target Margin Factor — 從成本反算批發直銷價 P0（可在下方各別覆蓋）</p>
                    <div className="flex items-center gap-2">
                      <input
                        type="number" min="0.01" max="1" step="0.01"
                        value={wsRules.targetMarginFactor}
                        onChange={e => setSiteConfig({...siteConfig, wholesalePricingRules: {...wsRules, targetMarginFactor: Number(e.target.value) || 0.88}})}
                        className="flex-1 p-4 bg-slate-50 rounded-2xl font-black text-xl text-center border border-slate-100 focus:ring-2 focus:ring-orange-100"
                      />
                    </div>
                    <p className="text-[9px] text-slate-300 font-bold">0.88 = 12% 毛利、0.85 = 15% 毛利、0.80 = 20% 毛利</p>
                    <div className="flex gap-2 pt-1 flex-wrap">
                      <button onClick={async () => {
                        try {
                          await supabase.from('site_config').upsert({ id: 'wholesale_pricing_rules', value: wsRules });
                          await supabase.from('site_config').upsert({ id: 'wholesale_price_overrides', value: wholesalePriceOverrides });
                          showToast('批發設定已儲存');
                        } catch (err: any) { showToast(`儲存失敗：${err.message}`, 'error'); }
                      }} className="flex items-center gap-1.5 px-4 py-2 bg-slate-900 text-white rounded-xl text-xs font-black shadow active:scale-95 transition-all"><Save size={13}/> 儲存設定</button>
                      <button onClick={() => {
                        if (wsOverrideCount > 0) { setPendingApplyTab('wholesale'); }
                        else { applyWsFactor(true); showToast('已重設，所有產品跟隨利潤率'); }
                      }} className="flex items-center gap-1.5 px-4 py-2 bg-orange-500 text-white rounded-xl text-xs font-black shadow active:scale-95 transition-all"><Zap size={13}/> 套用至所有產品</button>
                    </div>
                  </div>
                  <div className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm space-y-4">
                    <div className="flex items-center gap-2"><div className="p-2.5 bg-slate-100 text-slate-600 rounded-xl"><Zap size={18}/></div><h4 className="font-black text-sm">定價預覽</h4></div>
                    <p className="text-[10px] text-slate-400 font-bold">如果 成本/出成率 = $100</p>
                    <div className="space-y-2 text-xs">
                      <div className="flex justify-between items-center p-2.5 bg-slate-50 rounded-xl">
                        <span className="text-slate-500 font-bold">📦 成本</span>
                        <span className="font-black text-slate-900">${formatMoney(wsExampleCost)}</span>
                      </div>
                      <div className="flex justify-between items-center p-2.5 bg-orange-50 rounded-xl">
                        <div>
                          <span className="text-orange-600 font-bold">P0 直銷價</span>
                          <span className="text-[9px] text-orange-400 ml-1">÷ {wsRules.targetMarginFactor}</span>
                        </div>
                        <span className="font-black text-orange-700">${formatMoney(wsP0)}</span>
                      </div>
                      {wsRules.priceTiers.map(tier => {
                        const tierPrice = wsP0 / tier.factor;
                        return (
                          <div key={tier.name} className="flex justify-between items-center p-2.5 bg-teal-50 rounded-xl">
                            <div>
                              <span className="text-teal-600 font-bold">{tier.name}</span>
                              <span className="text-[9px] text-teal-400 ml-1">P0 ÷ {tier.factor}{tier.description ? ` (${tier.description})` : ''}</span>
                            </div>
                            <span className="font-black text-teal-700">${formatMoney(tierPrice)}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>

                {/* ── 批發衝突提示橫幅 ── */}
                {pendingApplyTab === 'wholesale' && (
                  <div className="bg-amber-50 border border-amber-200 rounded-[2rem] p-6 flex flex-col md:flex-row items-start md:items-center gap-4">
                    <div className="flex-1">
                      <p className="font-black text-amber-800 text-sm">有 {wsOverrideCount} 個產品已手動設定 P0 價格（橙色標示）</p>
                      <p className="text-[11px] text-amber-600 font-bold mt-1">套用新利潤率係數時，要清除這些手動覆蓋嗎？</p>
                    </div>
                    <div className="flex gap-2 flex-wrap">
                      <button onClick={() => { applyWsFactor(true); showToast('已重設，全部產品跟隨利潤率'); }} className="px-4 py-2 bg-amber-600 text-white rounded-xl text-xs font-black active:scale-95 transition-all">全部覆蓋，清除手動標記</button>
                      <button onClick={() => { applyWsFactor(false); showToast(`已套用利潤率，保留 ${wsOverrideCount} 個手動價格`); }} className="px-4 py-2 bg-white border border-amber-300 text-amber-700 rounded-xl text-xs font-black active:scale-95 transition-all">只套用未修改的產品</button>
                      <button onClick={() => setPendingApplyTab(null)} className="px-4 py-2 bg-white border border-slate-200 text-slate-500 rounded-xl text-xs font-black active:scale-95 transition-all">取消</button>
                    </div>
                  </div>
                )}

                {/* ── 批發全產品定價一覽 ── */}
                <div className="bg-white rounded-[3rem] border border-slate-100 shadow-sm overflow-hidden">
                  <div className="p-8 pb-4 flex items-center justify-between flex-wrap gap-3">
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 bg-orange-50 text-orange-600 rounded-xl"><ClipboardList size={18}/></div>
                      <h4 className="font-black text-lg">批發全產品定價一覽</h4>
                      {wsOverrideCount > 0 && (
                        <span className="px-2.5 py-1 bg-amber-100 text-amber-700 rounded-full text-[10px] font-black">{wsOverrideCount} 手改</span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <button onClick={() => setShowCostColumns(v => !v)} className={`px-4 py-2 rounded-xl text-xs font-black transition-colors ${showCostColumns ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}>
                        {showCostColumns ? '隱藏成本' : '顯示成本'}
                      </button>
                      {wsOverrideCount > 0 && (
                        <button onClick={() => setWholesalePriceOverrides({})} className="px-4 py-2 bg-amber-50 border border-amber-200 text-amber-700 rounded-xl text-xs font-black hover:bg-amber-100 transition-colors">
                          清除手動標記
                        </button>
                      )}
                      <button onClick={async () => {
                        try {
                          await supabase.from('site_config').upsert({ id: 'wholesale_pricing_rules', value: wsRules });
                          await supabase.from('site_config').upsert({ id: 'wholesale_price_overrides', value: wholesalePriceOverrides });
                          showToast('批發定價已儲存');
                        } catch (err: any) { showToast(`儲存失敗：${err.message}`, 'error'); }
                      }} className="px-4 py-2 bg-emerald-600 text-white rounded-xl text-xs font-black shadow-lg active:scale-95 transition-all flex items-center gap-1.5"><Save size={14}/> 儲存所有覆蓋</button>
                    </div>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs">
                      <thead>
                        <tr className="bg-slate-50 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                          <th className="text-left px-4 py-3">產品</th>
                          {showCostColumns && <th className="text-right px-4 py-3 text-amber-500">成本</th>}
                          <th className="text-right px-4 py-3 text-slate-400">計算P0</th>
                          <th className="text-right px-4 py-3 text-orange-500">實際P0</th>
                          {wsRules.priceTiers.map(tier => (
                            <th key={tier.name} className="text-right px-4 py-3 text-teal-500">{tier.name}</th>
                          ))}
                          {showCostColumns && <th className="text-right px-4 py-3 text-emerald-500">毛利%</th>}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-50">
                        {products.map(p => {
                          const linkedIng = ingredients.find(i => i.id === p.ingredientId);
                          const perLbCost = computeProductCost(p, linkedIng, costItems);
                          const totalCost = computePackCost(perLbCost, p.packWeightLb, p.pricingMode);
                          const computedP0 = totalCost > 0 ? roundPrice(totalCost / wsRules.targetMarginFactor) : null;
                          const override = wholesalePriceOverrides[p.id];
                          const actualP0 = override != null ? override : (computedP0 ?? 0);
                          const isOverridden = override != null;
                          const marginPct = totalCost > 0 && actualP0 > 0 ? Math.round(((actualP0 - totalCost) / actualP0) * 100) : null;
                          return (
                            <tr key={p.id} className={`transition-colors ${isOverridden ? 'bg-amber-50/60' : 'hover:bg-slate-50/50'}`}>
                              <td className="px-4 py-3">
                                <div className="flex items-center gap-2">
                                  <div className="w-8 h-8 bg-slate-50 rounded-lg flex items-center justify-center text-base overflow-hidden flex-shrink-0 border border-slate-100">
                                    {isMediaUrl(p.image) ? <img src={p.image} className="w-full h-full object-cover" alt="" /> : <span className="text-sm">{p.image || '📦'}</span>}
                                  </div>
                                  <div className="flex items-center gap-1.5">
                                    <span className="font-bold text-slate-700">{p.name}</span>
                                    {isOverridden && <span className="px-1.5 py-0.5 bg-amber-200 text-amber-800 rounded text-[9px] font-black">手改</span>}
                                  </div>
                                </div>
                              </td>
                              {showCostColumns && (
                                <td className="text-right px-4 py-3 font-bold text-amber-600">{totalCost > 0 ? `$${formatMoney(totalCost)}` : <span className="text-slate-300">—</span>}</td>
                              )}
                              <td className="text-right px-4 py-3 text-slate-400 font-bold">
                                {computedP0 != null ? `$${formatMoney(computedP0)}` : <span className="text-slate-200">—</span>}
                              </td>
                              <td className="text-right px-4 py-3">
                                <input
                                  type="number" min="0"
                                  value={actualP0 || ''}
                                  placeholder={computedP0 != null ? `${computedP0}` : '—'}
                                  onChange={e => {
                                    const val = Number(e.target.value) || 0;
                                    if (val > 0) {
                                      setWholesalePriceOverrides(prev => ({ ...prev, [p.id]: val }));
                                    } else {
                                      setWholesalePriceOverrides(prev => { const n = { ...prev }; delete n[p.id]; return n; });
                                    }
                                  }}
                                  className={`w-20 p-1 rounded-lg font-bold text-right text-xs border ${isOverridden ? 'bg-amber-50 border-amber-300 text-amber-900' : 'bg-slate-50 border-slate-200 text-slate-900'}`}
                                />
                              </td>
                              {wsRules.priceTiers.map(tier => {
                                const tierPrice = actualP0 > 0 ? roundPrice(actualP0 / tier.factor) : null;
                                return (
                                  <td key={tier.name} className="text-right px-4 py-3 font-bold text-teal-600">
                                    {tierPrice != null ? `$${tierPrice}` : <span className="text-slate-300">—</span>}
                                  </td>
                                );
                              })}
                              {showCostColumns && (
                                <td className={`text-right px-4 py-3 font-black ${marginPct !== null ? (marginPct >= 0 ? 'text-emerald-600' : 'text-rose-600') : 'text-slate-300'}`}>
                                  {marginPct !== null ? `${marginPct}%` : '—'}
                                </td>
                              )}
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* ── P 等級管理 ── */}
                <div className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2"><div className="p-2.5 bg-teal-50 text-teal-600 rounded-xl"><Users size={18}/></div><h4 className="font-black text-sm">P 等級管理</h4></div>
                    <button onClick={() => {
                      const nextNum = wsRules.priceTiers.length > 0
                        ? Math.max(...wsRules.priceTiers.map(t => parseInt(t.name.replace('P', '')) || 0)) + 1
                        : 3;
                      const factor = parseFloat((1 - nextNum / 100).toFixed(4));
                      const newTier: WholesalePriceTier = { name: `P${nextNum}`, factor, description: '' };
                      setSiteConfig({...siteConfig, wholesalePricingRules: {...wsRules, priceTiers: [...wsRules.priceTiers, newTier]}});
                    }} className="px-4 py-2 bg-teal-600 text-white rounded-xl text-xs font-black shadow-lg active:scale-95 transition-all flex items-center gap-1.5"><Plus size={14}/> 新增 P 等級</button>
                  </div>
                  <p className="text-[10px] text-slate-400 font-bold">P0 為基準直銷價（成本 ÷ 目標利潤率）。其餘 P 等級為在 P0 之上再加成。P 數字越大，客戶付出的售價越高。</p>
                  <div className="bg-orange-50/60 border border-orange-100 rounded-2xl p-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <span className="font-black text-orange-700 text-sm">P0（直銷價）</span>
                        <span className="text-[10px] text-orange-400 ml-2 font-bold">= 成本 ÷ {wsRules.targetMarginFactor}（或手動覆蓋）</span>
                      </div>
                      <span className="font-black text-orange-700">基準 — 新批發會員默認</span>
                    </div>
                  </div>
                  {wsRules.priceTiers.length === 0 && (
                    <p className="text-center text-slate-300 font-bold text-sm py-4">尚未設定額外 P 等級，點擊右上角「新增 P 等級」</p>
                  )}
                  <div className="space-y-3">
                    {wsRules.priceTiers.map((tier, idx) => (
                      <div key={idx} className="p-5 bg-slate-50 rounded-2xl border border-slate-100 space-y-3">
                        <div className="grid grid-cols-3 gap-4 items-end">
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">等級名稱</label>
                            <input value={tier.name} onChange={e => {
                              const updated = [...wsRules.priceTiers];
                              updated[idx] = {...updated[idx], name: e.target.value};
                              setSiteConfig({...siteConfig, wholesalePricingRules: {...wsRules, priceTiers: updated}});
                            }} className="w-full p-3 bg-white rounded-2xl font-black text-sm border border-slate-100" placeholder="P3" />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">因子（P0 ÷ 此值）</label>
                            <input type="number" min="0.01" max="1" step="0.01" value={tier.factor} onChange={e => {
                              const updated = [...wsRules.priceTiers];
                              updated[idx] = {...updated[idx], factor: Number(e.target.value) || 0.97};
                              setSiteConfig({...siteConfig, wholesalePricingRules: {...wsRules, priceTiers: updated}});
                            }} className="w-full p-3 bg-white rounded-2xl font-black text-sm border border-slate-100" />
                            <p className="text-[9px] text-slate-300 font-bold">{tier.factor < 1 ? `加成 ${((1 - tier.factor) * 100).toFixed(1)}%` : '無加成'}</p>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="flex-1 space-y-1">
                              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">說明（選填）</label>
                              <input value={tier.description || ''} onChange={e => {
                                const updated = [...wsRules.priceTiers];
                                updated[idx] = {...updated[idx], description: e.target.value};
                                setSiteConfig({...siteConfig, wholesalePricingRules: {...wsRules, priceTiers: updated}});
                              }} className="w-full p-3 bg-white rounded-2xl font-bold text-sm border border-slate-100" placeholder="業務佣金" />
                            </div>
                            <button onClick={() => {
                              const updated = wsRules.priceTiers.filter((_, i) => i !== idx);
                              setSiteConfig({...siteConfig, wholesalePricingRules: {...wsRules, priceTiers: updated}});
                            }} className="p-2 text-rose-400 hover:bg-rose-50 rounded-xl transition-colors mt-5"><Trash2 size={16}/></button>
                          </div>
                        </div>
                        <div className="text-[10px] text-teal-600 font-bold">如果成本=$100 → {tier.name} 價 = ${formatMoney(wsExampleCost / wsRules.targetMarginFactor / tier.factor)}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* ── 批發公式說明卡片 ── */}
                <div className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm space-y-4">
                  <div className="flex items-center gap-2"><div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl"><ClipboardList size={18}/></div><h4 className="font-black text-sm">計算公式</h4></div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                    <div className="p-4 bg-orange-50 rounded-2xl space-y-1">
                      <p className="font-black text-orange-700">P0 價（直銷價）</p>
                      <p className="text-orange-600 font-bold">= 總成本 ÷ 目標利潤率（或手動覆蓋）</p>
                      <p className="text-[10px] text-orange-400 font-bold">新批發會員默認等級</p>
                    </div>
                    <div className="p-4 bg-teal-50 rounded-2xl space-y-1">
                      <p className="font-black text-teal-700">P{'{n}'} 價（加成等級）</p>
                      <p className="text-teal-600 font-bold">= P0 價 ÷ 等級因子</p>
                      <p className="text-[10px] text-teal-400 font-bold">例：P3 = P0 ÷ 0.97（加 3%）</p>
                    </div>
                  </div>
                </div>
              </>
              );
            })()}
          </div>
        );
      }
      case 'settings':
        return (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 animate-fade-in pb-20">
             <div className="bg-white p-10 rounded-[3.5rem] border border-slate-100 shadow-sm space-y-8">
                <div className="flex items-center gap-3"><div className="p-3 bg-blue-50 text-blue-600 rounded-2xl"><Globe size={20}/></div><h3 className="text-xl font-black">基本資訊</h3></div>
                <div className="space-y-6">
                   <div className="space-y-1"><label className="text-[10px] font-bold text-slate-400 ml-4 uppercase">商店名稱</label><input value={siteConfig.logoText} onChange={e => setSiteConfig({...siteConfig, logoText: e.target.value})} className="w-full p-4 bg-slate-50 rounded-2xl font-bold" /></div>
                   <div className="space-y-2">
                     <label className="text-[10px] font-bold text-slate-400 ml-4 uppercase">商店 Logo</label>
                     <div className="flex items-center gap-4">
                       <label className={`relative w-20 h-20 rounded-2xl border-2 border-dashed ${imageUploading === 'logo' ? 'border-blue-400 bg-blue-50' : 'border-slate-200 bg-slate-50'} flex items-center justify-center cursor-pointer hover:border-blue-400 hover:bg-blue-50 transition-all overflow-hidden group flex-shrink-0`}>
                         {imageUploading === 'logo' ? (
                           <RefreshCw size={20} className="text-blue-500 animate-spin" />
                         ) : isMediaUrl(siteConfig.logoUrl) ? (
                           <>
                             <img src={siteConfig.logoUrl} alt="Logo" className="w-full h-full object-contain p-1" />
                             <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center"><Upload size={16} className="text-white" /></div>
                           </>
                         ) : siteConfig.logoIcon ? (
                           <span className="text-3xl">{siteConfig.logoIcon}</span>
                         ) : (
                           <div className="text-center"><Upload size={16} className="mx-auto text-slate-300 mb-0.5" /><span className="text-[8px] text-slate-400 font-bold">上傳</span></div>
                         )}
                         <input type="file" accept="image/*" className="hidden" onChange={e => handleImageUpload(e.target.files, 'branding', async ([url]) => { if (isMediaUrl(siteConfig.logoUrl)) await deleteImage(siteConfig.logoUrl!); setSiteConfig({...siteConfig, logoUrl: url}); }, { uploadKey: 'logo' })} />
                       </label>
                       <div className="flex-1 space-y-1.5">
                         <input value={siteConfig.logoIcon} onChange={e => setSiteConfig({...siteConfig, logoIcon: e.target.value})} className="w-full p-3 bg-slate-50 rounded-2xl font-bold text-sm" placeholder="備用 Emoji 圖標（如 ❄️）" />
                         <p className="text-[9px] text-slate-400 font-bold ml-1">上傳 Logo 圖片（用於網站標題、瀏覽器圖標、SEO）。Emoji 為備用顯示。</p>
                       </div>
                     </div>
                   </div>
                </div>
                <button onClick={async () => {
                  try {
                    await supabase.from('site_config').upsert({ id: 'site_branding', value: { logoText: siteConfig.logoText, logoIcon: siteConfig.logoIcon, logoUrl: siteConfig.logoUrl, accentColor: siteConfig.accentColor } });
                    showToast('品牌設定已儲存');
                  } catch (err: any) { showToast(`儲存失敗：${err.message}`, 'error'); }
                }} className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-black text-sm shadow-xl active:scale-95 transition-all flex items-center justify-center gap-2"><Save size={16}/> 儲存品牌設定</button>
             </div>
             <div className="bg-white p-10 rounded-[3.5rem] border border-slate-100 shadow-sm space-y-6">
                <div className="flex items-center gap-3"><div className="p-3 bg-amber-50 text-amber-600 rounded-2xl"><Percent size={20}/></div><h3 className="text-xl font-black">定價管理</h3></div>
                <p className="text-sm text-slate-400 font-bold">定價設定已移至獨立模組。優惠券系統請前往「優惠券/積分」管理。</p>
                <button onClick={() => setAdminModule('pricing')} className="w-full py-4 bg-slate-900 text-white rounded-2xl font-black text-sm shadow-xl active:scale-95 transition-all flex items-center justify-center gap-2"><DollarSign size={16}/> 前往價錢設定</button>
             </div>
             {/* ── 運費設置卡片 ── */}
             <div className="bg-white p-10 rounded-[3.5rem] border border-slate-100 shadow-sm space-y-8 lg:col-span-2">
                <div className="flex items-center gap-3"><div className="p-3 bg-emerald-50 text-emerald-600 rounded-2xl"><Truck size={20}/></div><h3 className="text-xl font-black">運費設置</h3></div>
                <p className="text-xs text-slate-400 font-bold -mt-4">在此設定每種配送方式的運費及免運門檻，切勿在程式碼中寫死數字。</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {(['sf_delivery', 'sf_locker'] as const).map(key => {
                    const sc = shippingConfigs[key] || SHIPPING_FALLBACKS[key];
                    return (
                      <div key={key} className="p-6 bg-slate-50 rounded-3xl border border-slate-100 space-y-5">
                        <h4 className="font-black text-sm text-slate-700">{sc.label}</h4>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold text-slate-400 ml-1 uppercase">運費 (HKD)</label>
                          <input type="number" min="0" step="1" value={sc.fee} onChange={e => setShippingConfigs(prev => ({ ...prev, [key]: { ...prev[key], fee: Number(e.target.value) } }))} className="w-full p-4 bg-white rounded-2xl font-bold border border-slate-100 focus:ring-2 focus:ring-emerald-100 focus:border-emerald-200 transition-all" />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold text-slate-400 ml-1 uppercase">免運門檻 (HKD)</label>
                          <input type="number" min="0" step="1" value={sc.threshold} onChange={e => setShippingConfigs(prev => ({ ...prev, [key]: { ...prev[key], threshold: Number(e.target.value) } }))} className="w-full p-4 bg-white rounded-2xl font-bold border border-slate-100 focus:ring-2 focus:ring-emerald-100 focus:border-emerald-200 transition-all" />
                        </div>
                      </div>
                    );
                  })}
                </div>
                <button onClick={async () => {
                  try {
                    const entries = Object.values(shippingConfigs);
                    for (const sc of entries) {
                      const { error } = await supabase.from('shipping_configs').upsert({ id: sc.id, label: sc.label, fee: sc.fee, threshold: sc.threshold, updated_at: new Date().toISOString() });
                      if (error) throw error;
                    }
                    showToast('運費設置已儲存');
                  } catch (err: any) {
                    showToast(`儲存失敗：${err.message}`, 'error');
                  }
                }} className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-black text-sm shadow-xl active:scale-95 transition-all flex items-center justify-center gap-2"><Save size={16}/> 儲存運費設置</button>
             </div>
             {/* ── 湊單推薦產品管理 ── */}
             <div className="bg-white p-10 rounded-[3.5rem] border border-slate-100 shadow-sm space-y-8 lg:col-span-2">
                <div className="flex items-center gap-3"><div className="p-3 bg-orange-50 text-orange-600 rounded-2xl"><Zap size={20}/></div><h3 className="text-xl font-black">湊單推薦產品</h3></div>
                <p className="text-xs text-slate-400 font-bold -mt-4">挑選 2-3 個產品作為「差少少就免運」的推薦項目，會在結帳頁面顯示。</p>
                {/* 已選產品列表 */}
                {upsellProductIds.length > 0 && (
                  <div className="space-y-2">
                    {upsellProductIds.map(pid => {
                      const p = products.find(x => x.id === pid);
                      return (
                        <div key={pid} className="flex items-center justify-between p-3 bg-slate-50 rounded-2xl border border-slate-100">
                          <div className="flex items-center gap-3 min-w-0">
                            <div className="w-10 h-10 bg-white rounded-xl border border-slate-100 flex items-center justify-center text-lg overflow-hidden flex-shrink-0">
                              {isMediaUrl(p?.image) ? <img src={p!.image} className="w-full h-full object-cover" alt="" /> : <span>{p?.image || '📦'}</span>}
                            </div>
                            <div className="min-w-0"><p className="text-sm font-black text-slate-700 truncate">{p?.name || pid}</p><p className="text-[10px] text-slate-400 font-bold">{p ? `$${formatMoney(p.price)}` : '$?'}</p></div>
                          </div>
                          <button onClick={() => setUpsellProductIds(prev => prev.filter(x => x !== pid))} className="p-2 text-slate-300 hover:text-red-500 transition-colors"><X size={16}/></button>
                        </div>
                      );
                    })}
                  </div>
                )}
                {/* 新增產品下拉 */}
                {upsellProductIds.length < 5 && (
                  <select
                    value=""
                    onChange={e => { if (e.target.value) setUpsellProductIds(prev => [...prev, e.target.value]); }}
                    className="w-full p-4 bg-slate-50 rounded-2xl font-bold border border-slate-100 focus:ring-2 focus:ring-orange-100 focus:border-orange-200 transition-all"
                  >
                    <option value="">＋ 新增推薦產品...</option>
                    {products.filter(p => !upsellProductIds.includes(p.id)).map(p => (
                      <option key={p.id} value={p.id}>{p.name} — ${formatMoney(p.price)}</option>
                    ))}
                  </select>
                )}
                <button onClick={async () => {
                  try {
                    // 先清除舊資料，再插入新選擇
                    await supabase.from('upsell_configs').delete().neq('id', '');
                    if (upsellProductIds.length > 0) {
                      const rows = upsellProductIds.map(pid => ({ product_id: pid, is_active: true }));
                      const { error } = await supabase.from('upsell_configs').insert(rows);
                      if (error) throw error;
                    }
                    showToast('湊單推薦已儲存');
                  } catch (err: any) {
                    showToast(`儲存失敗：${err.message}`, 'error');
                  }
                }} className="w-full py-4 bg-orange-500 text-white rounded-2xl font-black text-sm shadow-xl active:scale-95 transition-all flex items-center justify-center gap-2"><Save size={16}/> 儲存湊單推薦</button>
             </div>
             {/* ── 進階功能開關 ── */}
             <div className="bg-white p-10 rounded-[3.5rem] border border-slate-100 shadow-sm space-y-8 lg:col-span-2">
                <div className="flex items-center gap-3"><div className="p-3 bg-rose-50 text-rose-600 rounded-2xl"><Package size={20}/></div><h3 className="text-xl font-black">進階功能開關</h3></div>
                <p className="text-xs text-slate-400 font-bold -mt-4">控制系統是否啟用庫存管理等後勤功能。關閉後前台不會檢查庫存，所有產品均可購買。</p>
                <div className="p-6 bg-slate-50 rounded-3xl border border-slate-100 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-black text-sm text-slate-700">庫存管控</h4>
                      <p className="text-xs text-slate-400 mt-0.5">啟用後，前台會檢查庫存數量、顯示缺貨狀態、下單時扣減庫存。關閉後系統如無限庫存運作。</p>
                    </div>
                    <button
                      onClick={() => setSiteConfig(prev => ({ ...prev, inventoryEnforcementEnabled: !prev.inventoryEnforcementEnabled }))}
                      className={`relative w-14 h-7 rounded-full transition-colors duration-200 flex-shrink-0 ${siteConfig.inventoryEnforcementEnabled ? 'bg-emerald-500' : 'bg-slate-300'}`}
                    >
                      <span className={`absolute top-0.5 left-0.5 w-6 h-6 bg-white rounded-full shadow transition-transform duration-200 ${siteConfig.inventoryEnforcementEnabled ? 'translate-x-7' : ''}`} />
                    </button>
                  </div>
                  <p className={`text-xs font-bold px-3 py-2 rounded-xl ${siteConfig.inventoryEnforcementEnabled ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'}`}>
                    {siteConfig.inventoryEnforcementEnabled ? '✅ 已啟用 — 前台會檢查庫存、扣減庫存、顯示缺貨' : '⚠️ 已關閉 — 前台不檢查庫存，所有產品均可無限購買'}
                  </p>
                </div>
                <button onClick={async () => {
                  try {
                    await supabase.from('site_config').upsert({ id: 'store_feature_flags', value: { inventoryEnforcementEnabled: siteConfig.inventoryEnforcementEnabled } });
                    showToast('功能開關已儲存');
                  } catch (err: any) { showToast(`儲存失敗：${err.message}`, 'error'); }
                }} className="w-full py-4 bg-rose-600 text-white rounded-2xl font-black text-sm shadow-xl active:scale-95 transition-all flex items-center justify-center gap-2"><Save size={16}/> 儲存功能開關</button>
             </div>
          </div>
        );
      case 'ingredients':
        return (
          <div className="space-y-8 animate-fade-in pb-20">
            {/* Sub-tab Navigation */}
            <div className="flex items-center gap-2">
              {[
                { id: 'list' as const, label: '原材料一覽', icon: <Layers size={16}/> },
                { id: 'categories' as const, label: '類別管理', icon: <Tag size={16}/> },
                { id: 'units' as const, label: '單位管理', icon: <Filter size={16}/> },
              ].map(tab => (
                <button key={tab.id} onClick={() => setIngredientSubTab(tab.id)} className={`px-5 py-2.5 rounded-xl text-sm font-black transition-all flex items-center gap-2 ${ingredientSubTab === tab.id ? 'bg-blue-600 text-white shadow-lg' : 'bg-white text-slate-500 border border-slate-200 hover:border-blue-300'}`}>
                  {tab.icon} {tab.label}
                </button>
              ))}
            </div>

            {/* Categories Management Sub-tab */}
            {ingredientSubTab === 'categories' && (
              <div className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm space-y-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-violet-50 text-violet-600 rounded-xl"><Tag size={18}/></div>
                    <div>
                      <h4 className="font-black text-lg">原材料類別管理</h4>
                      <p className="text-[10px] text-slate-400 font-bold">定義固定的原材料類別，供全系統（成本管理、產品關聯）統一使用</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setEditingIngredientCategory({ id: 'ic-' + Date.now(), name: '', emoji: '📦', sortOrder: ingredientCategoryList.length })}
                    className="px-5 py-3 bg-slate-900 text-white rounded-2xl font-black text-xs flex items-center gap-2 shadow-xl active:scale-95 transition-all"
                  >
                    <Plus size={16}/> 新增類別
                  </button>
                </div>

                {ingredientCategoryList.length === 0 && (
                  <div className="text-center py-16 text-slate-400">
                    <Tag size={32} className="mx-auto mb-3 opacity-30"/>
                    <p className="font-bold text-sm">尚未有類別</p>
                    <p className="text-xs mt-1">點擊「新增類別」開始建立</p>
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {ingredientCategoryList.map((cat, idx) => (
                    <div
                      key={cat.id}
                      draggable
                      onDragStart={() => { dragIngCatIdx.current = idx; }}
                      onDragOver={e => { e.preventDefault(); setDragOverIngCat(idx); }}
                      onDragLeave={() => setDragOverIngCat(null)}
                      onDrop={() => {
                        if (dragIngCatIdx.current !== null) reorderIngredientCategories(dragIngCatIdx.current, idx);
                        dragIngCatIdx.current = null;
                        setDragOverIngCat(null);
                      }}
                      onDragEnd={() => { dragIngCatIdx.current = null; setDragOverIngCat(null); }}
                      className={`p-5 rounded-2xl border flex items-center justify-between group transition-all cursor-grab active:cursor-grabbing ${dragOverIngCat === idx ? 'border-violet-400 bg-violet-50/50 scale-[1.02]' : 'bg-slate-50 border-slate-100 hover:border-violet-200'}`}
                    >
                      <div className="flex items-center gap-3">
                        <GripVertical size={16} className="text-slate-300 flex-shrink-0" />
                        <span className="text-3xl">{cat.emoji}</span>
                        <div>
                          <p className="font-black text-slate-900">{cat.name}</p>
                          <p className="text-[10px] text-slate-400 uppercase tracking-widest">{cat.id}</p>
                        </div>
                      </div>
                      <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onClick={() => setEditingIngredientCategory(cat)} className="p-2 text-slate-400 hover:text-blue-500 transition-colors"><Edit size={16}/></button>
                        <button onClick={() => setConfirmation({
                          title: '刪除類別',
                          message: `確定刪除「${cat.name}」？已設定此類別的原材料不受影響，只是類別標籤會保留原字串。`,
                          onConfirm: () => deleteIngredientCategory(cat.id),
                        })} className="p-2 text-slate-400 hover:text-rose-500 transition-colors"><Trash2 size={16}/></button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Units Management Sub-tab */}
            {ingredientSubTab === 'units' && (
              <div className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm space-y-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-purple-50 text-purple-600 rounded-xl"><Tag size={18}/></div>
                    <div>
                      <h4 className="font-black text-lg">單位管理</h4>
                      <p className="text-[10px] text-slate-400 font-bold">預設單位不可刪除，可自由新增自訂單位</p>
                    </div>
                  </div>
                  <button onClick={async () => {
                    try {
                      await supabase.from('site_config').upsert({ id: 'custom_units', value: customUnits });
                      showToast('單位設定已儲存');
                    } catch (err: any) { showToast(`儲存失敗：${err.message}`, 'error'); }
                  }} className="px-4 py-2 bg-emerald-600 text-white rounded-xl text-xs font-black shadow-lg active:scale-95 transition-all flex items-center gap-1.5"><Save size={14}/> 儲存</button>
                </div>

                {/* Default units (read-only) */}
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">預設單位</label>
                  <div className="flex flex-wrap gap-2">
                    {DEFAULT_UNITS.map(u => (
                      <div key={u.value} className="px-4 py-2.5 bg-slate-50 rounded-xl text-xs font-black text-slate-500 border border-slate-100 flex items-center gap-2">
                        <Lock size={10} className="text-slate-300" />
                        <span className="text-slate-700">{u.label}</span>
                        <span className="text-slate-300 text-[10px]">{u.value}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Custom units (editable) */}
                <div className="space-y-3">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">自訂單位</label>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="bg-slate-50 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                          <th className="text-left px-4 py-3">顯示名稱</th>
                          <th className="text-left px-4 py-3">值（英文縮寫）</th>
                          <th className="text-right px-4 py-3 w-20">操作</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-50">
                        {customUnits.map(u => (
                          <tr key={u.id} className="hover:bg-slate-50/50 transition-colors">
                            <td className="px-4 py-3">
                              <input value={u.label} onChange={e => setCustomUnits(prev => prev.map(x => x.id === u.id ? { ...x, label: e.target.value } : x))} className="w-full p-2 bg-slate-50 rounded-lg font-bold text-xs border border-slate-100 focus:ring-2 focus:ring-purple-100" placeholder="例：條" />
                            </td>
                            <td className="px-4 py-3">
                              <input value={u.value} onChange={e => setCustomUnits(prev => prev.map(x => x.id === u.id ? { ...x, value: e.target.value.replace(/\s/g, '') } : x))} className="w-full p-2 bg-slate-50 rounded-lg font-bold text-xs border border-slate-100 focus:ring-2 focus:ring-purple-100 font-mono" placeholder="例：strip" />
                            </td>
                            <td className="px-4 py-3 text-right">
                              <button onClick={() => setCustomUnits(prev => prev.filter(x => x.id !== u.id))} className="p-1.5 text-rose-400 hover:bg-rose-50 rounded-lg transition-colors"><Trash2 size={14}/></button>
                            </td>
                          </tr>
                        ))}
                        {customUnits.length === 0 && (
                          <tr><td colSpan={3} className="px-4 py-8 text-center text-slate-300 font-bold text-xs">尚無自訂單位，點擊下方新增</td></tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                  <button onClick={() => setCustomUnits(prev => [...prev, { id: `unit-${Date.now()}`, label: '', value: '' }])} className="px-4 py-2.5 border-2 border-dashed border-slate-200 rounded-xl text-xs font-black text-slate-400 hover:border-purple-400 hover:text-purple-600 transition-all flex items-center gap-1.5"><Plus size={14}/> 新增單位</button>
                </div>

                {/* Preview */}
                <div className="bg-purple-50/50 border border-purple-100 rounded-2xl p-4">
                  <label className="text-[10px] font-bold text-purple-400 uppercase tracking-widest">所有可用單位預覽</label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {allUnits.map(u => (
                      <span key={u.value} className="px-3 py-1.5 bg-white rounded-lg text-xs font-bold text-slate-600 border border-purple-100">{u.label}</span>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Ingredients List Sub-tab */}
            {ingredientSubTab === 'list' && <div className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm space-y-6">
              <div className="flex items-center justify-between flex-wrap gap-3">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 bg-blue-50 text-blue-600 rounded-xl"><Layers size={18}/></div>
                  <div>
                    <h4 className="font-black text-lg">原材料一覽</h4>
                    <p className="text-[10px] text-slate-400 font-bold">管理所有原材料的買入成本、供應商、類別及市場參考價</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  {/* CSV Export */}
                  <button onClick={() => {
                    const header = 'id,舊系統ID,名稱,英文名稱,買入成本,單位,供應商,市場參考價,類別,渠道,備註';
                    const csvEscape = (v: string) => {
                      if (!v) return '';
                      if (v.includes(',') || v.includes('"') || v.includes('\n')) return `"${v.replace(/"/g, '""')}"`;
                      return v;
                    };
                    const rows = ingredients.map(ing =>
                      [ing.id, csvEscape(ing.legacyId || ''), csvEscape(ing.name), csvEscape(ing.nameEn || ''), ing.baseCostPerLb, ing.unit, csvEscape(ing.supplier || ''), ing.marketBenchmark ?? '', csvEscape(ing.category || ''), ing.saleChannel || '', csvEscape(ing.notes || '')].join(',')
                    );
                    const csvContent = '\uFEFF' + [header, ...rows].join('\n');
                    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `原材料_${new Date().toISOString().slice(0, 10)}.csv`;
                    a.click();
                    URL.revokeObjectURL(url);
                    showToast('CSV 已匯出');
                  }} className="px-3 py-2 bg-emerald-50 text-emerald-600 rounded-xl text-xs font-black border border-emerald-200 hover:bg-emerald-100 transition-all flex items-center gap-1.5"><Download size={14}/> 匯出 CSV</button>
                  {/* CSV Import */}
                  <label className="px-3 py-2 bg-amber-50 text-amber-600 rounded-xl text-xs font-black border border-amber-200 hover:bg-amber-100 transition-all flex items-center gap-1.5 cursor-pointer"><Upload size={14}/> 匯入 CSV
                    <input type="file" accept=".csv" className="hidden" onChange={async (e) => {
                      const file = e.target.files?.[0];
                      if (!file) return;
                      e.target.value = '';
                      const text = await file.text();
                      const lines = text.replace(/^\uFEFF/, '').split('\n').map(l => l.trim()).filter(Boolean);
                      if (lines.length < 2) { showToast('CSV 檔案無資料列', 'error'); return; }
                      const parseCSVLine = (line: string): string[] => {
                        const result: string[] = [];
                        let current = '';
                        let inQuotes = false;
                        for (let i = 0; i < line.length; i++) {
                          const ch = line[i];
                          if (inQuotes) {
                            if (ch === '"' && line[i + 1] === '"') { current += '"'; i++; }
                            else if (ch === '"') { inQuotes = false; }
                            else { current += ch; }
                          } else {
                            if (ch === '"') { inQuotes = true; }
                            else if (ch === ',') { result.push(current); current = ''; }
                            else { current += ch; }
                          }
                        }
                        result.push(current);
                        return result;
                      };
                      const imported: Ingredient[] = [];
                      let skipped = 0;
                      for (let i = 1; i < lines.length; i++) {
                        const cols = parseCSVLine(lines[i]);
                        const name = (cols[2] || '').trim();
                        if (!name) { skipped++; continue; }
                          imported.push({
                          id: (cols[0] || '').trim() || `ing-${Date.now()}-${i}`,
                          legacyId: (cols[1] || '').trim() || undefined,
                          name,
                          nameEn: (cols[3] || '').trim() || undefined,
                          baseCostPerLb: Number(cols[4]) || 0,
                          unit: (cols[5] || 'lb').trim() || 'lb',
                          supplier: (cols[6] || '').trim() || undefined,
                          marketBenchmark: cols[7] && cols[7].trim() ? Number(cols[7]) : undefined,
                          category: (cols[8] || '').trim() || undefined,
                          notes: (cols[9] || '').trim() || undefined,
                        });
                      }
                      if (imported.length === 0) { showToast('無有效資料可匯入', 'error'); return; }
                      try {
                        const rows = imported.map(mapIngredientToRow);
                        const { error } = await supabase.from('ingredients').upsert(rows);
                        if (error) throw error;
                        setIngredients(prev => {
                          const map = new Map(prev.map(x => [x.id, x]));
                          imported.forEach(x => map.set(x.id, x));
                          return Array.from(map.values());
                        });
                        showToast(`已匯入 ${imported.length} 筆原材料${skipped > 0 ? `（跳過 ${skipped} 筆空行）` : ''}`);
                      } catch (err: any) {
                        showToast(`匯入失敗：${err.message}`, 'error');
                      }
                    }} />
                  </label>
                  {/* Download Template */}
                  <button onClick={() => {
                    const template = '\uFEFF' + 'id,舊系統ID,名稱,英文名稱,買入成本,單位,供應商,市場參考價,類別,備註\n'
                      + 'ing-001,OLD-101,美國 Prime 肋眼,US Prime Ribeye,45.5,lb,ABC Trading,52,牛肉,頂級部位\n'
                      + 'ing-002,OLD-102,澳洲 M5 和牛,AU M5 Wagyu,62,lb,XYZ Meats,70,牛肉,\n'
                      + 'ing-003,,西班牙黑毛豬,Iberico Pork,28.5,lb,,35,豬肉,梅頭部位';
                    const blob = new Blob([template], { type: 'text/csv;charset=utf-8;' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = '原材料_範本.csv';
                    a.click();
                    URL.revokeObjectURL(url);
                    showToast('範本已下載');
                  }} className="px-3 py-2 bg-slate-50 text-slate-500 rounded-xl text-xs font-black border border-slate-200 hover:bg-slate-100 transition-all flex items-center gap-1.5"><FileText size={14}/> 下載範本</button>
                  <button onClick={() => setEditingIngredient({ id: `ing-${Date.now()}`, name: '', baseCostPerLb: 0, unit: 'lb' })} className="px-4 py-2.5 bg-blue-600 text-white rounded-xl text-xs font-black shadow-lg active:scale-95 transition-all flex items-center gap-1.5"><Plus size={14}/> 新增原材料</button>
                </div>
              </div>

              {/* Filters */}
              <div className="flex items-center gap-3 flex-wrap">
                <div className="flex items-center gap-1.5">
                  <Filter size={14} className="text-slate-400" />
                  <span className="text-[10px] font-bold text-slate-400">篩選：</span>
                </div>
                <select value={ingredientCategoryFilter} onChange={e => { setIngredientCategoryFilter(e.target.value); setSelectedIngredientIds(new Set()); }} className="px-3 py-2 bg-slate-50 rounded-xl text-xs font-bold border border-slate-200">
                  <option value="all">全部類別</option>
                  <option value="uncategorized">未分類</option>
                  {ingredientCategories.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
                <span className="text-[10px] text-slate-300 font-bold ml-1">{filteredIngredients.length} / {ingredients.length} 筆</span>
              </div>

              {/* Batch action bar */}
              {selectedIngredientIds.size > 0 && (
                <div className="flex items-center gap-3 p-4 bg-blue-50 border border-blue-200 rounded-2xl animate-fade-in">
                  <span className="text-xs font-black text-blue-700">已選 {selectedIngredientIds.size} 項</span>
                  <select id="batchCategorySelect" className="px-3 py-1.5 bg-white rounded-lg text-xs font-bold border border-blue-200" defaultValue="">
                    <option value="" disabled>設定類別...</option>
                    {ingredientCategories.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                  <button onClick={async () => {
                    const sel = (document.getElementById('batchCategorySelect') as HTMLSelectElement)?.value;
                    if (!sel) { showToast('請先選擇類別', 'error'); return; }
                    const ids = Array.from(selectedIngredientIds);
                    try {
                      const { error } = await supabase.from('ingredients').update({ category: sel }).in('id', ids);
                      if (error) throw error;
                      setIngredients(prev => prev.map(ing => ids.includes(ing.id) ? { ...ing, category: sel } : ing));
                      setSelectedIngredientIds(new Set());
                      showToast(`已為 ${ids.length} 項設定類別「${sel}」`);
                    } catch (err: any) { showToast(`批量更新失敗：${err.message}`, 'error'); }
                  }} className="px-3 py-1.5 bg-blue-600 text-white rounded-lg text-xs font-black active:scale-95 transition-all">套用類別</button>
                  <button onClick={async () => {
                    if (!confirm(`確定刪除 ${selectedIngredientIds.size} 項原材料？關聯產品將取消關聯。`)) return;
                    const ids = Array.from(selectedIngredientIds);
                    try {
                      const { error } = await supabase.from('ingredients').delete().in('id', ids);
                      if (error) throw error;
                      setIngredients(prev => prev.filter(x => !ids.includes(x.id)));
                      setProducts(prev => prev.map(p => p.ingredientId && ids.includes(p.ingredientId) ? { ...p, ingredientId: undefined } : p));
                      setSelectedIngredientIds(new Set());
                      showToast(`已刪除 ${ids.length} 項原材料`);
                    } catch (err: any) { showToast(`批量刪除失敗：${err.message}`, 'error'); }
                  }} className="px-3 py-1.5 bg-rose-500 text-white rounded-lg text-xs font-black active:scale-95 transition-all ml-auto flex items-center gap-1"><Trash2 size={12}/> 批量刪除</button>
                </div>
              )}

              {/* CSV format hint */}
              <div className="bg-blue-50/60 border border-blue-100 rounded-2xl p-4 flex items-start gap-3">
                <FileText size={16} className="text-blue-400 mt-0.5 flex-shrink-0" />
                <div className="text-[10px] text-blue-600 font-bold leading-relaxed">
                  <p className="font-black text-blue-700 mb-1">CSV 批量匯入說明</p>
                  <p>1. 點擊「下載範本」取得 CSV 格式範例 → 2. 用 Excel / Google Sheets 開啟編輯 → 3. 填入原材料資料後存成 CSV → 4. 點「匯入 CSV」上傳</p>
                  <p className="mt-1 text-blue-400">欄位：ID, 舊系統ID, 名稱*, 英文名稱, 買入成本*, 單位, 供應商, 市場參考價, 類別, 備註。相同 ID 會覆蓋更新。</p>
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="bg-slate-50 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                      <th className="text-center px-2 py-3 w-10">
                        <button onClick={() => {
                          if (selectedIngredientIds.size === filteredIngredients.length) setSelectedIngredientIds(new Set());
                          else setSelectedIngredientIds(new Set(filteredIngredients.map(i => i.id)));
                        }} className={`w-5 h-5 rounded-md border-2 flex items-center justify-center transition-all mx-auto ${selectedIngredientIds.size === filteredIngredients.length && filteredIngredients.length > 0 ? 'border-blue-500 bg-blue-500 text-white' : 'border-slate-200 bg-white'}`}>
                          {selectedIngredientIds.size === filteredIngredients.length && filteredIngredients.length > 0 && <Check size={12} strokeWidth={3}/>}
                        </button>
                      </th>
                      <th className="text-left px-4 py-3">名稱</th>
                      <th className="text-left px-3 py-3">類別</th>
                      <th className="text-right px-4 py-3">買入成本</th>
                      <th className="text-center px-4 py-3">單位</th>
                      <th className="text-left px-4 py-3">供應商</th>
                      <th className="text-right px-4 py-3">市場參考價</th>
                      <th className="text-center px-4 py-3">關聯產品</th>
                      <th className="text-right px-4 py-3 w-24">操作</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {(() => {
                      const rows: React.ReactNode[] = [];
                      let lastCat: string | undefined = undefined;
                      filteredIngredients.forEach(ing => {
                        const catKey = ing.category || '';
                        if (catKey !== lastCat) {
                          lastCat = catKey;
                          const catObj = catKey ? ingredientCategoryList.find(c => c.name === catKey) : null;
                          rows.push(
                            <tr key={`__ing_cat_${catKey || 'none'}`} className="bg-violet-50/50">
                              <td colSpan={9} className="px-4 py-2">
                                {catObj ? (
                                  <span className="text-[10px] font-black text-violet-600 uppercase tracking-widest">{catObj.emoji} {catObj.name}</span>
                                ) : (
                                  <span className="text-[10px] font-black text-amber-500 uppercase tracking-widest">⚠ 無類別（請盡快設定）</span>
                                )}
                              </td>
                            </tr>
                          );
                        }
                        const linkedCount = products.filter(p => p.ingredientId === ing.id).length;
                        const isSelected = selectedIngredientIds.has(ing.id);
                        rows.push(
                        <tr key={ing.id} className={`hover:bg-slate-50/50 transition-colors ${isSelected ? 'bg-blue-50/40' : ''}`}>
                          <td className="text-center px-2 py-3">
                            <button onClick={() => setSelectedIngredientIds(prev => {
                              const next = new Set(prev);
                              if (next.has(ing.id)) next.delete(ing.id); else next.add(ing.id);
                              return next;
                            })} className={`w-5 h-5 rounded-md border-2 flex items-center justify-center transition-all mx-auto ${isSelected ? 'border-blue-500 bg-blue-500 text-white' : 'border-slate-200 bg-white'}`}>
                              {isSelected && <Check size={12} strokeWidth={3}/>}
                            </button>
                          </td>
                          <td className="px-4 py-3">
                            <div>
                              <span className="font-bold text-slate-700">{ing.name}</span>
                              {ing.nameEn && <span className="text-slate-400 text-[10px] ml-2">{ing.nameEn}</span>}
                            </div>
                          </td>
                          <td className="px-3 py-3">
                            <select
                              value={ing.category || ''}
                              onChange={async e => {
                                const cat = e.target.value || undefined;
                                const { error } = await supabase.from('ingredients').update({ category: cat ?? null }).eq('id', ing.id);
                                if (error) { showToast(`更新失敗：${error.message}`, 'error'); return; }
                                setIngredients(prev => prev.map(x => x.id === ing.id ? { ...x, category: cat } : x));
                              }}
                              className={`px-2.5 py-1 rounded-full text-[10px] font-black border-0 cursor-pointer focus:ring-2 focus:ring-violet-300 outline-none ${ing.category ? 'bg-violet-50 text-violet-600' : 'bg-slate-100 text-slate-400'}`}
                            >
                              <option value="">— 設定</option>
                              {ingredientCategories.map(c => <option key={c} value={c}>{c}</option>)}
                            </select>
                          </td>
                          <td className="text-right px-4 py-3 font-black text-blue-600">${formatMoney(ing.baseCostPerLb)}</td>
                          <td className="text-center px-4 py-3 text-slate-500">{ing.unit}</td>
                          <td className="px-4 py-3 text-slate-500">{ing.supplier || '—'}</td>
                          <td className="text-right px-4 py-3">{ing.marketBenchmark != null ? <span className="text-emerald-600 font-bold">${formatMoney(ing.marketBenchmark)}</span> : <span className="text-slate-300">—</span>}</td>
                          <td className="text-center px-4 py-3"><span className="bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full text-[10px] font-bold">{linkedCount} 個產品</span></td>
                          <td className="text-right px-4 py-3">
                            <div className="flex items-center justify-end gap-1">
                              <button onClick={() => setEditingIngredient({ ...ing })} className="p-1.5 text-blue-500 hover:bg-blue-50 rounded-lg transition-colors"><Edit size={14}/></button>
                              <button onClick={async () => {
                                if (!confirm(`確定刪除「${ing.name}」？關聯產品將取消關聯。`)) return;
                                const { error } = await supabase.from('ingredients').delete().eq('id', ing.id);
                                if (error) { showToast(`刪除失敗：${error.message}`, 'error'); return; }
                                setIngredients(prev => prev.filter(x => x.id !== ing.id));
                                setProducts(prev => prev.map(p => p.ingredientId === ing.id ? { ...p, ingredientId: undefined } : p));
                                showToast('已刪除原材料');
                              }} className="p-1.5 text-rose-400 hover:bg-rose-50 rounded-lg transition-colors"><Trash2 size={14}/></button>
                            </div>
                          </td>
                        </tr>
                        );
                      });
                      if (filteredIngredients.length === 0) {
                        rows.push(<tr key="empty"><td colSpan={9} className="px-4 py-12 text-center text-slate-300 font-bold text-sm">{ingredients.length === 0 ? '尚無原材料，點擊右上角「新增原材料」' : '無符合條件的原材料'}</td></tr>);
                      }
                      return rows;
                    })()}
                  </tbody>
                </table>
              </div>
            </div>}

            {/* Editing Ingredient Modal */}
            {editingIngredient && (
              <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30 backdrop-blur-sm animate-fade-in" onClick={() => setEditingIngredient(null)}>
                <div className="bg-white rounded-[2.5rem] w-full max-w-lg mx-4 shadow-2xl overflow-hidden" onClick={e => e.stopPropagation()}>
                  <div className="p-8 border-b border-slate-100 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 bg-blue-50 text-blue-600 rounded-xl"><Layers size={18}/></div>
                      <h3 className="font-black text-lg">{ingredients.find(i => i.id === editingIngredient.id) ? '編輯原材料' : '新增原材料'}</h3>
                    </div>
                    <button onClick={() => setEditingIngredient(null)} className="p-2 hover:bg-slate-100 rounded-xl transition-colors"><X size={18}/></button>
                  </div>
                  <div className="p-8 space-y-5 max-h-[60vh] overflow-y-auto">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">名稱 *</label>
                        <input value={editingIngredient.name} onChange={e => setEditingIngredient({ ...editingIngredient, name: e.target.value })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold text-sm border border-slate-100" placeholder="例：美國 Prime 肋眼" />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">英文名稱</label>
                        <input value={editingIngredient.nameEn || ''} onChange={e => setEditingIngredient({ ...editingIngredient, nameEn: e.target.value })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold text-sm border border-slate-100" placeholder="US Prime Ribeye" />
                      </div>
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">舊系統 ID</label>
                      <input value={editingIngredient.legacyId || ''} onChange={e => setEditingIngredient({ ...editingIngredient, legacyId: e.target.value || undefined })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold text-sm border border-slate-100 font-mono" placeholder="舊系統的原材料編號（選填）" />
                    </div>
                    <div className="grid grid-cols-3 gap-4">
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">買入成本 *</label>
                        <input type="number" min="0" step="0.01" value={editingIngredient.baseCostPerLb} onChange={e => setEditingIngredient({ ...editingIngredient, baseCostPerLb: Number(e.target.value) || 0 })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold text-sm border border-slate-100" />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">單位</label>
                        <select value={editingIngredient.unit} onChange={e => setEditingIngredient({ ...editingIngredient, unit: e.target.value })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold text-sm border border-slate-100">
                          {allUnits.map(u => <option key={u.value} value={u.value}>{u.label}</option>)}
                        </select>
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">市場參考價</label>
                        <input type="number" min="0" step="0.01" value={editingIngredient.marketBenchmark ?? ''} onChange={e => setEditingIngredient({ ...editingIngredient, marketBenchmark: e.target.value ? Number(e.target.value) : undefined })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold text-sm border border-slate-100" placeholder="—" />
                      </div>
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">類別</label>
                      <select value={editingIngredient.category || ''} onChange={e => setEditingIngredient({ ...editingIngredient, category: e.target.value || undefined })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold text-sm border border-slate-100">
                        <option value="">（未分類）</option>
                        {ingredientCategories.map(c => <option key={c} value={c}>{c}</option>)}
                      </select>
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">供應商</label>
                      <input value={editingIngredient.supplier || ''} onChange={e => setEditingIngredient({ ...editingIngredient, supplier: e.target.value })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold text-sm border border-slate-100" placeholder="例：ABC Trading Co." />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">備註</label>
                      <textarea value={editingIngredient.notes || ''} onChange={e => setEditingIngredient({ ...editingIngredient, notes: e.target.value })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold text-sm border border-slate-100 resize-none h-20" placeholder="任何額外備註..." />
                    </div>
                  </div>
                  <div className="p-6 border-t border-slate-100">
                    <button onClick={async () => {
                      if (!editingIngredient.name.trim()) { showToast('請填寫原材料名稱', 'error'); return; }
                      try {
                        const row = mapIngredientToRow(editingIngredient);
                        const { error } = await supabase.from('ingredients').upsert(row);
                        if (error) throw error;
                        setIngredients(prev => {
                          const exists = prev.find(x => x.id === editingIngredient.id);
                          if (exists) return prev.map(x => x.id === editingIngredient.id ? editingIngredient : x);
                          return [...prev, editingIngredient];
                        });
                        setEditingIngredient(null);
                        showToast('原材料已儲存');
                      } catch (err: any) {
                        showToast(`儲存失敗：${err.message}`, 'error');
                      }
                    }} className="w-full py-3.5 bg-blue-600 text-white rounded-2xl font-black text-sm shadow-xl active:scale-95 transition-all flex items-center justify-center gap-2"><Save size={16}/> 儲存原材料</button>
                  </div>
                </div>
              </div>
            )}
          </div>
        );
      case 'costs':
        // Costs module moved to WarehousePanel → 產品成本一覽
        return <WarehousePanel showToast={showToast} products={products} setProducts={setProducts} costItems={costItems} setCostItems={setCostItems} siteConfig={siteConfig} isMediaUrl={isMediaUrl} />;
      case 'language':
        return (
          <div className="space-y-8 animate-fade-in pb-20">
            <div className="bg-white p-10 rounded-[3.5rem] border border-slate-100 shadow-sm space-y-6">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-blue-50 text-blue-600 rounded-2xl"><Globe size={20}/></div>
                <div>
                  <h3 className="text-xl font-black">語言翻譯管理</h3>
                  <p className="text-xs text-slate-400 font-bold">管理前台的中英文翻譯。產品翻譯請到「編輯產品」設定。</p>
                </div>
              </div>
              {/* Translation overrides stored in site_config */}
              <Suspense fallback={null}><AdminLanguagePanel products={products} setProducts={setProducts} showToast={showToast} /></Suspense>
            </div>
          </div>
        );
      case 'recipes':
        return (
          <div className="space-y-6 animate-fade-in">
            {/* Sub-tabs */}
            <div className="flex gap-2">
              {[
                { id: 'recipes' as const, label: '食譜列表', icon: <BookOpen size={16}/> },
                { id: 'categories' as const, label: '食譜分類', icon: <Layers size={16}/> },
              ].map(tab => (
                <button key={tab.id} onClick={() => setRecipeAdminSubTab(tab.id)} className={`px-5 py-3 rounded-2xl text-xs font-black flex items-center gap-2 transition-all ${recipeAdminSubTab === tab.id ? 'bg-slate-900 text-white shadow-lg' : 'bg-white border border-slate-100 text-slate-400'}`}>
                  {tab.icon} {tab.label}
                </button>
              ))}
            </div>

            {recipeAdminSubTab === 'recipes' ? (
            <>
              <div className="flex justify-between items-center gap-3 flex-wrap">
                <p className="text-slate-400 font-bold text-sm">{recipes.length} 個食譜</p>
                <div className="flex gap-2">
                  <button disabled={aiRecipeLoading} onClick={() => {
                    setAiPromptModal({
                      title: 'AI 批量生成食譜',
                      placeholder: '例如：全部用氣炸鍋、以雞肉為主、適合小朋友吃的...',
                      onConfirm: async (instruction) => {
                        const BATCH_COUNT = 5;
                        const COOLDOWN_MS = 1000;
                        setAiRecipeLoading(true);
                        let successCount = 0;
                        let failCount = 0;
                        const catMap = recipeCategories.map(c => ({ id: c.id, name: c.name }));
                        const allTitles = recipes.map(r => r.title).filter(Boolean);
                        const imagePromises: Promise<void>[] = [];
                        for (let i = 0; i < BATCH_COUNT; i++) {
                          setAiBatchProgress({ current: i + 1, total: BATCH_COUNT, label: `正在生成第 ${i + 1}/${BATCH_COUNT} 個食譜...` });
                          try {
                            const res = await fetch('/api/generate-recipe', {
                              method: 'POST', headers: buildAdminHeaders(adminUser),
                              body: JSON.stringify({ action: 'single-recipe', payload: { title: '', linkedProductNames: [], categoryIds: catMap.map(c => c.id), categoryMap: catMap, existingTitles: allTitles, userInstruction: instruction || undefined } }),
                            });
                            const json = await res.json();
                            if (!json.ok) { failCount++; continue; }
                            const r = json.data;
                            const chefTip = typeof r.chef_tip === 'string' ? r.chef_tip : '';
                            const steps = Array.isArray(r.steps) ? r.steps : [];
                            if (chefTip && steps.length > 0) {
                              steps.push({ order: steps.length + 1, content: `💡 大廚小貼士：${chefTip}` });
                            }
                            const recipe: StandaloneRecipe = {
                              id: crypto.randomUUID(),
                              title: r.title || '',
                              description: r.description || '',
                              mediaUrl: '',
                              mediaType: 'image',
                              cookingTime: r.cooking_time || 0,
                              servingSize: r.serving_size || '1-2人份',
                              tags: [],
                              categoryIds: Array.isArray(r.category_ids) ? r.category_ids.filter((c: string) => recipeCategories.some(rc => rc.id === c)) : [],
                              ingredientsRaw: Array.isArray(r.ingredients) ? r.ingredients : [],
                              steps,
                              linkedProductIds: [],
                            };
                            if (recipe.title) {
                              const isDuplicate = allTitles.some(t => t.trim().toLowerCase() === recipe.title.trim().toLowerCase());
                              if (!isDuplicate) {
                                allTitles.push(recipe.title);
                                await upsertRecipe(recipe);
                                successCount++;
                                // Fire off image generation in background — don't block the loop
                                const savedRecipe = recipe;
                                imagePromises.push(
                                  generateAndUploadRecipeImage(savedRecipe.id, savedRecipe.title, savedRecipe.description)
                                    .then(imageUrl => {
                                      if (imageUrl) {
                                        supabase.from('recipes').update({ media_url: imageUrl, media_type: 'image' }).eq('id', savedRecipe.id);
                                        setRecipes(prev => prev.map(rec => rec.id === savedRecipe.id ? { ...rec, mediaUrl: imageUrl, mediaType: 'image' as const } : rec));
                                      }
                                    })
                                    .catch(() => {})
                                );
                              } else {
                                failCount++;
                              }
                            }
                          } catch { failCount++; }
                          if (i < BATCH_COUNT - 1) await new Promise(r => setTimeout(r, COOLDOWN_MS));
                        }
                        setAiBatchProgress({ current: BATCH_COUNT, total: BATCH_COUNT, label: `食譜已生成，AI 正在生成圖片中（${imagePromises.length} 張）...` });
                        await Promise.allSettled(imagePromises);
                        setAiBatchProgress(null);
                        setAiRecipeLoading(false);
                        const msg = failCount > 0
                          ? `AI 完成：${successCount} 個成功，${failCount} 個失敗`
                          : `AI 已生成 ${successCount} 個食譜（含 AI 圖片）`;
                        showToast(msg, failCount > 0 ? 'error' : 'success');
                      },
                    });
                  }} className="px-5 py-3 bg-purple-50 text-purple-600 border border-purple-200 rounded-2xl font-black text-xs flex items-center gap-2 hover:bg-purple-100 transition-all disabled:opacity-50">
                    {aiRecipeLoading ? <RefreshCw size={16} className="animate-spin" /> : <Sparkles size={16} />}
                    AI 批量生成食譜
                  </button>
                  <button onClick={() => setEditingRecipe(newEmptyRecipe())} className="px-5 py-3 bg-slate-900 text-white rounded-2xl font-black text-xs flex items-center gap-2 shadow-xl active:scale-95 transition-all">
                    <Plus size={16}/> {t.recipes.addRecipe}
                  </button>
                </div>
              </div>
              {/* Search + filter bar */}
              <div className="space-y-3">
                <div className="flex gap-2 flex-wrap items-center">
                  <div className="relative flex-1 min-w-[180px]">
                    <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input value={adminRecipeSearch} onChange={e => setAdminRecipeSearch(e.target.value)} placeholder="搜尋食譜名稱..." className="w-full pl-8 pr-3 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-bold placeholder:text-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900/10" />
                  </div>
                  <div className="flex gap-1.5">
                    {(['all', 'linked', 'unlinked'] as const).map(v => (
                      <button key={v} onClick={() => setAdminRecipeProductFilter(v)} className={`px-3 py-2 rounded-xl text-[10px] font-black border transition-all ${adminRecipeProductFilter === v ? 'bg-slate-900 text-white border-slate-900' : 'bg-white text-slate-400 border-slate-200 hover:border-slate-300'}`}>
                        {v === 'all' ? '全部' : v === 'linked' ? '有關聯產品' : '無關聯產品'}
                      </button>
                    ))}
                  </div>
                </div>
                {/* Category filter chips – method row */}
                {recipeCategories.some(c => c.categoryType === 'method') && (
                  <div className="flex gap-1.5 overflow-x-auto hide-scrollbar">
                    {recipeCategories.filter(c => c.categoryType === 'method').map(cat => {
                      const isActive = adminRecipeCategoryFilter.includes(cat.id);
                      return (
                        <button key={cat.id} onClick={() => setAdminRecipeCategoryFilter(prev => isActive ? prev.filter(c => c !== cat.id) : [...prev, cat.id])} className={`px-2.5 py-1 rounded-full text-[10px] font-black border whitespace-nowrap transition-all flex items-center gap-1 ${isActive ? 'bg-amber-500 text-white border-amber-500' : 'bg-white text-slate-400 border-slate-200'}`}>
                          {cat.icon} {cat.name}
                        </button>
                      );
                    })}
                  </div>
                )}
                {/* Meat type filter chips */}
                {recipeCategories.some(c => c.categoryType === 'meat') && (
                  <div className="flex gap-1.5 overflow-x-auto hide-scrollbar">
                    {recipeCategories.filter(c => c.categoryType === 'meat').map(cat => {
                      const isActive = adminRecipeCategoryFilter.includes(cat.id);
                      return (
                        <button key={cat.id} onClick={() => setAdminRecipeCategoryFilter(prev => isActive ? prev.filter(c => c !== cat.id) : [...prev, cat.id])} className={`px-2.5 py-1 rounded-full text-[10px] font-black border whitespace-nowrap transition-all flex items-center gap-1 ${isActive ? 'bg-rose-500 text-white border-rose-500' : 'bg-white text-slate-400 border-slate-200'}`}>
                          {cat.icon} {cat.name}
                        </button>
                      );
                    })}
                    {(adminRecipeCategoryFilter.length > 0 || adminRecipeSearch || adminRecipeProductFilter !== 'all') && (
                      <button onClick={() => { setAdminRecipeCategoryFilter([]); setAdminRecipeSearch(''); setAdminRecipeProductFilter('all'); }} className="flex items-center gap-1 text-[10px] font-bold text-slate-400 hover:text-slate-600 transition-colors px-2">
                        <X size={10} /> 清除
                      </button>
                    )}
                  </div>
                )}
              </div>

              {(() => {
                const filtered = recipes.filter(r => {
                  if (adminRecipeSearch && !r.title.toLowerCase().includes(adminRecipeSearch.toLowerCase())) return false;
                  if (adminRecipeProductFilter === 'linked' && r.linkedProductIds.length === 0) return false;
                  if (adminRecipeProductFilter === 'unlinked' && r.linkedProductIds.length > 0) return false;
                  if (adminRecipeCategoryFilter.length > 0 && !adminRecipeCategoryFilter.every(cid => r.categoryIds.includes(cid))) return false;
                  return true;
                });
                return (
                  <>
                    <p className="text-[10px] text-slate-400 font-bold -mt-1">顯示 {filtered.length} / {recipes.length} 個食譜</p>
                    {filtered.length === 0 && (
                      <div className="bg-white p-12 rounded-[3rem] border border-slate-100 shadow-sm text-center text-slate-400 font-bold">{t.recipes.noRecipes}</div>
                    )}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {filtered.map(r => (
                        <div key={r.id} className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden hover:shadow-md transition-all group relative">
                          {/* Delete button */}
                          <button onClick={(e) => { e.stopPropagation(); setConfirmation({ title: '刪除食譜', message: `確定刪除「${r.title || '（未命名）'}」？此操作無法還原。`, onConfirm: () => deleteRecipe(r.id) }); }} className="absolute top-3 right-3 z-10 p-1.5 bg-white/90 hover:bg-rose-50 rounded-lg text-slate-300 hover:text-rose-500 transition-all opacity-0 group-hover:opacity-100 shadow-sm">
                            <Trash2 size={14} />
                          </button>
                          <div className="cursor-pointer" onClick={() => setEditingRecipe(r)}>
                            {r.mediaUrl && isMediaUrl(r.mediaUrl) && (
                              <div className="aspect-video bg-slate-100 overflow-hidden">
                                {r.mediaType === 'video' ? (
                                  <video src={r.mediaUrl} className="w-full h-full object-cover" muted />
                                ) : (
                                  <img src={r.mediaUrl} alt={r.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                                )}
                              </div>
                            )}
                            <div className="p-5 space-y-2">
                              <h4 className="font-black text-slate-900 text-base pr-6">{r.title || '（未命名）'}</h4>
                              {r.description && <p className="text-xs text-slate-400 font-medium line-clamp-2">{r.description}</p>}
                              <div className="flex flex-wrap gap-1.5">
                                {r.cookingTime > 0 && <span className="px-2 py-0.5 bg-amber-50 text-amber-600 rounded-lg text-[9px] font-black border border-amber-100"><Clock size={9} className="inline mr-0.5" />{r.cookingTime}{t.recipes.minutes}</span>}
                                {r.categoryIds.map(cid => { const c = recipeCategories.find(x => x.id === cid); return c ? <span key={cid} className={`px-2 py-0.5 rounded-lg text-[9px] font-black border ${c.categoryType === 'meat' ? 'bg-rose-50 text-rose-700 border-rose-100' : 'bg-amber-50 text-amber-700 border-amber-100'}`}>{c.icon} {c.name}</span> : null; })}
                                {r.tags.map(tag => <span key={tag} className="px-2 py-0.5 bg-blue-50 text-blue-600 rounded-lg text-[9px] font-black border border-blue-100">{tag}</span>)}
                              </div>
                              <div className="flex items-center gap-2 text-[10px] text-slate-400 font-bold pt-1">
                                <span>{r.linkedProductIds.length} 關聯產品</span>
                                <span>·</span>
                                <span>{r.steps.length} 步驟</span>
                                <span>·</span>
                                <span>{r.servingSize}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </>
                );
              })()}
            </>
            ) : (
            /* ── Recipe Categories sub-tab ── */
            <div className="space-y-8">
              <div className="flex justify-between items-center">
                <p className="text-slate-400 font-bold text-sm">{recipeCategories.length} 個食譜分類</p>
                <button onClick={() => setEditingRecipeCategory({ id: '', name: '', icon: '📁', sortOrder: recipeCategories.length, categoryType: 'method' })} className="px-5 py-3 bg-slate-900 text-white rounded-2xl font-black text-xs flex items-center gap-2 shadow-xl active:scale-95 transition-all">
                  <Plus size={16}/> 新增分類
                </button>
              </div>
              {recipeCategories.length === 0 && (
                <div className="bg-white p-12 rounded-[3rem] border border-slate-100 shadow-sm text-center text-slate-400 font-bold">尚未有食譜分類</div>
              )}

              {/* Section 1: Cooking methods */}
              {recipeCategories.some(c => c.categoryType === 'method') && (
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <span className="text-base">🍳</span>
                    <h5 className="font-black text-slate-900 text-sm">料理方式</h5>
                    <span className="text-[10px] text-slate-400 font-bold">({recipeCategories.filter(c => c.categoryType === 'method').length})</span>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {recipeCategories.filter(c => c.categoryType === 'method').map((cat, idx) => (
                      <div
                        key={cat.id}
                        draggable
                        onDragStart={() => { dragRecipeMethodCatIdx.current = idx; }}
                        onDragOver={e => { e.preventDefault(); setDragOverRecipeMethodCat(idx); }}
                        onDragLeave={() => setDragOverRecipeMethodCat(null)}
                        onDrop={() => {
                          if (dragRecipeMethodCatIdx.current !== null) reorderRecipeCategories('method', dragRecipeMethodCatIdx.current, idx);
                          dragRecipeMethodCatIdx.current = null;
                          setDragOverRecipeMethodCat(null);
                        }}
                        onDragEnd={() => { dragRecipeMethodCatIdx.current = null; setDragOverRecipeMethodCat(null); }}
                        className={`bg-white p-5 rounded-2xl border shadow-sm flex items-center justify-between transition-all cursor-grab active:cursor-grabbing ${dragOverRecipeMethodCat === idx ? 'border-amber-400 bg-amber-50/30 scale-[1.02]' : 'border-slate-100 hover:shadow-md'}`}
                      >
                        <div className="flex items-center gap-3">
                          <GripVertical size={16} className="text-slate-300 flex-shrink-0" />
                          <span className="text-2xl">{cat.icon}</span>
                          <div>
                            <p className="font-black text-slate-900">{cat.name}</p>
                            <p className="text-[10px] text-slate-400 font-bold">{cat.id}</p>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <button onClick={() => setEditingRecipeCategory(cat)} className="p-2 bg-slate-50 rounded-xl text-slate-400 hover:text-blue-600"><Edit size={16} /></button>
                          <button onClick={() => setConfirmation({ title: '刪除分類', message: `確定刪除「${cat.name}」？`, onConfirm: () => deleteRecipeCategory(cat.id) })} className="p-2 bg-slate-50 rounded-xl text-slate-400 hover:text-rose-600"><Trash2 size={16} /></button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Section 2: Meat types */}
              {recipeCategories.some(c => c.categoryType === 'meat') && (
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <span className="text-base">🥩</span>
                    <h5 className="font-black text-slate-900 text-sm">肉類種類</h5>
                    <span className="text-[10px] text-slate-400 font-bold">({recipeCategories.filter(c => c.categoryType === 'meat').length})</span>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {recipeCategories.filter(c => c.categoryType === 'meat').map((cat, idx) => (
                      <div
                        key={cat.id}
                        draggable
                        onDragStart={() => { dragRecipeMeatCatIdx.current = idx; }}
                        onDragOver={e => { e.preventDefault(); setDragOverRecipeMeatCat(idx); }}
                        onDragLeave={() => setDragOverRecipeMeatCat(null)}
                        onDrop={() => {
                          if (dragRecipeMeatCatIdx.current !== null) reorderRecipeCategories('meat', dragRecipeMeatCatIdx.current, idx);
                          dragRecipeMeatCatIdx.current = null;
                          setDragOverRecipeMeatCat(null);
                        }}
                        onDragEnd={() => { dragRecipeMeatCatIdx.current = null; setDragOverRecipeMeatCat(null); }}
                        className={`bg-white p-5 rounded-2xl border shadow-sm flex items-center justify-between transition-all cursor-grab active:cursor-grabbing ${dragOverRecipeMeatCat === idx ? 'border-rose-400 bg-rose-50/50 scale-[1.02]' : 'border-rose-50 hover:shadow-md'}`}
                      >
                        <div className="flex items-center gap-3">
                          <GripVertical size={16} className="text-slate-300 flex-shrink-0" />
                          <span className="text-2xl">{cat.icon}</span>
                          <div>
                            <p className="font-black text-slate-900">{cat.name}</p>
                            <p className="text-[10px] text-slate-400 font-bold">{cat.id}</p>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <button onClick={() => setEditingRecipeCategory(cat)} className="p-2 bg-rose-50 rounded-xl text-slate-400 hover:text-blue-600"><Edit size={16} /></button>
                          <button onClick={() => setConfirmation({ title: '刪除分類', message: `確定刪除「${cat.name}」？`, onConfirm: () => deleteRecipeCategory(cat.id) })} className="p-2 bg-rose-50 rounded-xl text-slate-400 hover:text-rose-600"><Trash2 size={16} /></button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Recipe Category Editor inline */}
              {editingRecipeCategory && (
                <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm space-y-4">
                  <h4 className="font-black text-slate-900">{editingRecipeCategory.id ? '編輯分類' : '新增分類'}</h4>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-slate-400 uppercase">分類 ID</label>
                      <input value={editingRecipeCategory.id} onChange={e => setEditingRecipeCategory({ ...editingRecipeCategory, id: e.target.value.toLowerCase().replace(/\s+/g, '-') })} className="w-full p-2.5 bg-slate-50 rounded-xl font-bold text-xs" placeholder="例如：airfryer" />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-slate-400 uppercase">名稱</label>
                      <input value={editingRecipeCategory.name} onChange={e => setEditingRecipeCategory({ ...editingRecipeCategory, name: e.target.value })} className="w-full p-2.5 bg-slate-50 rounded-xl font-bold text-xs" placeholder="例如：氣炸鍋" />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-slate-400 uppercase">圖示</label>
                      <input value={editingRecipeCategory.icon} onChange={e => setEditingRecipeCategory({ ...editingRecipeCategory, icon: e.target.value })} className="w-full p-2.5 bg-slate-50 rounded-xl font-bold text-xs" placeholder="🍟" />
                    </div>
                    <div className="space-y-1 col-span-2">
                      <label className="text-[9px] font-bold text-slate-400 uppercase">分類類型</label>
                      <div className="flex gap-2">
                        {(['method', 'meat'] as const).map(type => (
                          <button key={type} onClick={() => setEditingRecipeCategory({ ...editingRecipeCategory, categoryType: type })} className={`flex-1 py-2 rounded-xl text-xs font-black border transition-all ${editingRecipeCategory.categoryType === type ? (type === 'meat' ? 'bg-rose-500 text-white border-rose-500' : 'bg-amber-500 text-white border-amber-500') : 'bg-slate-50 text-slate-400 border-slate-200 hover:border-slate-300'}`}>
                            {type === 'method' ? '🍳 料理方式' : '🥩 肉類種類'}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-3 justify-end">
                    <button onClick={() => setEditingRecipeCategory(null)} className="px-5 py-2 bg-white border border-slate-200 rounded-xl font-black text-xs">取消</button>
                    <button onClick={() => {
                      if (!editingRecipeCategory.id.trim() || !editingRecipeCategory.name.trim()) { showToast('請輸入 ID 和名稱', 'error'); return; }
                      upsertRecipeCategory(editingRecipeCategory);
                      setEditingRecipeCategory(null);
                    }} className="px-5 py-2 bg-slate-900 text-white rounded-xl font-black text-xs">保存</button>
                  </div>
                </div>
              )}
            </div>
            )}
          </div>
        );
      case 'admin_management': {
        return (
          <div className="space-y-8 animate-fade-in pb-20">
            {/* Header */}
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-500 text-sm font-bold mt-1">管理可登入後台的帳戶、角色及功能權限</p>
              </div>
            </div>

            {/* Tab bar */}
            <div className="flex gap-2">
              <button onClick={() => setStaffMgmtTab('staff')} className={`px-5 py-2.5 rounded-2xl font-black text-sm transition-all ${staffMgmtTab === 'staff' ? 'bg-blue-600 text-white shadow-xl' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'}`}>
                <Users size={14} className="inline mr-1.5 -mt-0.5"/> 員工帳戶
              </button>
              <button onClick={() => { setStaffMgmtTab('roles'); loadStaffRoles(); }} className={`px-5 py-2.5 rounded-2xl font-black text-sm transition-all ${staffMgmtTab === 'roles' ? 'bg-blue-600 text-white shadow-xl' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'}`}>
                <ShieldCheck size={14} className="inline mr-1.5 -mt-0.5"/> 角色管理
              </button>
            </div>

            {/* Role legend */}
            <div className="flex flex-wrap items-center gap-3 text-xs font-bold text-slate-500">
              {ALL_STAFF_ROLES.map(role => (
                <span key={role} className="flex items-center gap-1.5">
                  <span className="text-sm">{ADMIN_ROLE_ICONS[role]}</span>
                  <span className={`${ADMIN_ROLE_COLORS[role].text} font-black`}>{ADMIN_ROLE_LABELS[role]}</span>
                </span>
              ))}
            </div>

            {/* ═══ Staff Tab ═══ */}
            {staffMgmtTab === 'staff' && (
              <>
                <div className="flex justify-end">
                  <button
                    onClick={() => setEditingAdminAccount({ isNew: true, newPhone: '', role: 'admin', permissions: { ...DEFAULT_ADMIN_PERMISSIONS, admin_management: { ...NO_ACCESS } } })}
                    className="flex items-center gap-2 bg-blue-600 text-white px-5 py-3 rounded-2xl font-black text-sm shadow-xl active:scale-95 transition-all"
                  >
                    <Plus size={16}/> 新增員工
                  </button>
                </div>

                {adminAccounts.length === 0 ? (
                  <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm p-16 text-center text-slate-400">
                    <ShieldCheck size={40} className="mx-auto mb-3 opacity-30" />
                    <p className="font-black">尚無員工帳戶</p>
                    <p className="text-sm mt-1">點擊「新增員工」開始設置</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
                    {adminAccounts.map(acc => {
                      const rc = ADMIN_ROLE_COLORS[acc.role] || ADMIN_ROLE_COLORS.admin;
                      const icon = ADMIN_ROLE_ICONS[acc.role] || '👤';
                      return (
                        <div key={acc.id} className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm p-6 space-y-4">
                          <div className="flex items-start justify-between">
                            <div className="flex items-center gap-3">
                              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl flex-shrink-0 ${rc.bg}`}>
                                {icon}
                              </div>
                              <div>
                                <div className="flex items-center gap-2">
                                  <p className="font-black text-slate-900">{acc.name}</p>
                                  {acc.id === adminUser?.id && <span className="text-[10px] font-black bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full">本人</span>}
                                </div>
                                <p className="text-xs text-slate-400 font-bold">{acc.phone}</p>
                                <span className={`inline-block mt-1 text-[10px] font-black px-2 py-0.5 rounded-full ${rc.bg} ${rc.text}`}>
                                  {ADMIN_ROLE_LABELS[acc.role] || acc.role}
                                </span>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <button
                                onClick={() => setEditingAdminAccount({ ...acc, isNew: false })}
                                className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all"
                                title="編輯權限"
                              >
                                <Pencil size={16}/>
                              </button>
                              {acc.id !== adminUser?.id && (
                                <button
                                  onClick={() => revokeAdminAccess(acc.id, acc.name)}
                                  className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all"
                                  title="撤銷權限"
                                >
                                  <Trash2 size={16}/>
                                </button>
                              )}
                            </div>
                          </div>

                          {/* Permissions grid with CRUD detail */}
                          <div>
                            <p className="text-[10px] font-black text-slate-400 uppercase mb-2">功能權限</p>
                            <div className="flex flex-wrap gap-1.5">
                              {(Object.keys(ADMIN_PERMISSION_LABELS) as (keyof AdminPermissions)[]).map(key => {
                                const perm = acc.role === 'super_admin' ? FULL_ACCESS : acc.permissions[key];
                                if (!hasAnyAccess(perm)) return null;
                                const ops = CRUD_OPS.filter(op => perm[op]);
                                const isFullAccess = ops.length === 5;
                                return (
                                  <span key={key} className={`text-[10px] font-bold px-2 py-1 rounded-lg ${isFullAccess ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700'}`} title={ops.map(o => CRUD_OP_LABELS[o]).join(', ')}>
                                    {ADMIN_PERMISSION_LABELS[key]}{!isFullAccess && <span className="ml-0.5 opacity-60">({ops.map(o => CRUD_OP_LABELS[o][0]).join('')})</span>}
                                  </span>
                                );
                              })}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </>
            )}

            {/* ═══ Roles Tab ═══ */}
            {staffMgmtTab === 'roles' && (
              <>
                <div className="flex justify-end">
                  <button
                    onClick={() => setEditingStaffRole({
                      isNew: true,
                      name: '',
                      displayName: '',
                      isSystem: false,
                      modulePermissions: { ...DEFAULT_ADMIN_PERMISSIONS, admin_management: { ...NO_ACCESS } },
                      sortOrder: staffRoles.length,
                    })}
                    className="flex items-center gap-2 bg-blue-600 text-white px-5 py-3 rounded-2xl font-black text-sm shadow-xl active:scale-95 transition-all"
                  >
                    <Plus size={16}/> 新增角色
                  </button>
                </div>

                <div className="space-y-4">
                  {staffRoles.map(role => {
                    const rc = ADMIN_ROLE_COLORS[role.name as AdminRole] || { bg: 'bg-slate-100', text: 'text-slate-700' };
                    const icon = ADMIN_ROLE_ICONS[role.name as AdminRole] || '👤';
                    const enabledModules = Object.entries(role.modulePermissions).filter(([, v]) => hasAnyAccess(normalizePermValue(v as any))).map(([k]) => k);
                    return (
                      <div key={role.id} className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm p-6 space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <span className="text-2xl">{icon}</span>
                            <div>
                              <p className="font-black text-slate-900">{role.displayName}</p>
                              <p className="text-[10px] text-slate-400 font-bold">{role.name} {role.isSystem && '（系統角色）'}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => setEditingStaffRole({ ...role, isNew: false })}
                              className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all"
                            >
                              <Pencil size={16}/>
                            </button>
                            {!role.isSystem && (
                              <button
                                onClick={() => deleteStaffRole(role.id, role.displayName)}
                                className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all"
                              >
                                <Trash2 size={16}/>
                              </button>
                            )}
                          </div>
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {enabledModules.map(key => {
                            const perm = normalizePermValue((role.modulePermissions as any)[key]);
                            const ops = CRUD_OPS.filter(op => perm[op]);
                            const isFullAccess = ops.length === 5;
                            return (
                              <span key={key} className={`text-[10px] font-bold px-2 py-1 rounded-lg ${isFullAccess ? rc.bg + ' ' + rc.text : 'bg-amber-50 text-amber-700'}`} title={ops.map(o => CRUD_OP_LABELS[o]).join(', ')}>
                                {ADMIN_PERMISSION_LABELS[key as keyof AdminPermissions] || key}{!isFullAccess && <span className="ml-0.5 opacity-60">({ops.map(o => CRUD_OP_LABELS[o][0]).join('')})</span>}
                              </span>
                            );
                          })}
                          {enabledModules.length === 0 && <span className="text-[10px] text-slate-300 font-bold">無權限</span>}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </>
            )}

            {/* ═══ Edit / Add Staff Modal ═══ */}
            {editingAdminAccount && (
              <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
                <div className="bg-white rounded-[2.5rem] shadow-2xl w-full max-w-xl max-h-[90vh] overflow-y-auto">
                  <div className="p-8 space-y-6">
                    <div className="flex items-center justify-between">
                      <h3 className="text-xl font-black">{editingAdminAccount.isNew ? '新增員工' : '編輯員工'}</h3>
                      <button onClick={() => setEditingAdminAccount(null)} className="p-2 text-slate-400 hover:text-slate-600 rounded-xl"><X size={20}/></button>
                    </div>

                    {editingAdminAccount.isNew && (
                      <div className="space-y-1">
                        <label className="text-[10px] font-black text-slate-400 uppercase">會員電話號碼</label>
                        <input
                          type="text"
                          value={editingAdminAccount.newPhone || ''}
                          onChange={e => setEditingAdminAccount(prev => prev ? { ...prev, newPhone: e.target.value } : null)}
                          placeholder="輸入已存在的會員電話"
                          className="w-full p-4 bg-slate-50 rounded-2xl font-bold focus:ring-2 focus:ring-blue-100 focus:border-blue-200 border border-transparent transition-all"
                        />
                        <p className="text-[10px] text-slate-400 font-bold ml-1">此電話必須已在「會員管理」中存在</p>
                      </div>
                    )}

                    {!editingAdminAccount.isNew && (
                      <div className="bg-slate-50 rounded-2xl p-4 flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white font-black">{(editingAdminAccount.name || '?').charAt(0)}</div>
                        <div>
                          <p className="font-black text-slate-900">{editingAdminAccount.name}</p>
                          <p className="text-xs text-slate-400">{editingAdminAccount.phone}</p>
                        </div>
                      </div>
                    )}

                    {/* Role selector */}
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase">角色</label>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                        {ALL_STAFF_ROLES.map(role => {
                          const selected = editingAdminAccount.role === role;
                          const rc = ADMIN_ROLE_COLORS[role];
                          const icon = ADMIN_ROLE_ICONS[role];
                          return (
                            <button
                              key={role}
                              onClick={() => {
                                const matchedTemplate = staffRoles.find(r => r.name === role);
                                const templatePerms = matchedTemplate?.modulePermissions;
                                let newPerms: AdminPermissions;
                                if (role === 'super_admin') {
                                  const all: any = {};
                                  Object.keys(DEFAULT_ADMIN_PERMISSIONS).forEach(k => all[k] = { ...FULL_ACCESS });
                                  newPerms = all as AdminPermissions;
                                } else if (templatePerms) {
                                  const p: any = {};
                                  Object.keys(DEFAULT_ADMIN_PERMISSIONS).forEach(k => p[k] = normalizePermValue((templatePerms as any)[k]));
                                  newPerms = p as AdminPermissions;
                                } else {
                                  newPerms = { ...DEFAULT_ADMIN_PERMISSIONS, admin_management: { ...NO_ACCESS } };
                                }
                                setEditingAdminAccount(prev => prev ? { ...prev, role, permissions: newPerms } : null);
                              }}
                              className={`p-3 rounded-2xl border-2 text-left transition-all ${
                                selected ? `${rc.bg} ${rc.text} border-current shadow-lg` : 'bg-slate-50 text-slate-500 border-transparent hover:border-slate-200'
                              }`}
                            >
                              <span className="text-lg">{icon}</span>
                              <p className="text-xs font-black mt-1">{ADMIN_ROLE_LABELS[role]}</p>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* CRUD Permissions Matrix (Enterprise Security — not for super_admin) */}
                    {editingAdminAccount.role !== 'super_admin' && (
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <label className="text-[10px] font-black text-slate-400 uppercase">功能模組權限（CRUD）</label>
                          <div className="flex gap-2">
                            <button
                              onClick={() => setEditingAdminAccount(prev => {
                                if (!prev) return null;
                                const all: any = {};
                                Object.keys(DEFAULT_ADMIN_PERMISSIONS).forEach(k => all[k] = k !== 'admin_management' ? { ...FULL_ACCESS } : { ...NO_ACCESS });
                                return { ...prev, permissions: all };
                              })}
                              className="text-[10px] font-black text-blue-600 hover:underline"
                            >全選</button>
                            <button
                              onClick={() => setEditingAdminAccount(prev => {
                                if (!prev) return null;
                                const none: any = {};
                                Object.keys(DEFAULT_ADMIN_PERMISSIONS).forEach(k => none[k] = { ...NO_ACCESS });
                                return { ...prev, permissions: none };
                              })}
                              className="text-[10px] font-black text-slate-400 hover:underline"
                            >全不選</button>
                          </div>
                        </div>
                        {/* Column headers */}
                        <div className="flex items-center gap-1 pl-[140px]">
                          {CRUD_OPS.map(op => (
                            <span key={op} className="w-10 text-center text-[9px] font-black text-slate-300 uppercase">{CRUD_OP_LABELS[op]}</span>
                          ))}
                        </div>
                        {PERMISSION_GROUPS.map(group => (
                          <div key={group.label}>
                            <p className="text-[10px] font-black text-slate-300 uppercase mb-1.5">{group.label}</p>
                            <div className="space-y-1">
                              {group.keys.filter(k => k !== 'admin_management').map(key => {
                                const perm = normalizePermValue((editingAdminAccount.permissions as any)?.[key]);
                                const allOn = CRUD_OPS.every(op => perm[op]);
                                return (
                                  <div key={key} className="flex items-center gap-1 p-2 bg-slate-50 rounded-xl hover:bg-slate-100 transition-all">
                                    <button
                                      onClick={() => {
                                        const newPerm = allOn ? { ...NO_ACCESS } : { ...FULL_ACCESS };
                                        setEditingAdminAccount(prev => prev ? {
                                          ...prev,
                                          permissions: { ...(prev.permissions || DEFAULT_ADMIN_PERMISSIONS), [key]: newPerm }
                                        } : null);
                                      }}
                                      className={`w-[132px] text-left text-xs font-bold truncate ${allOn ? 'text-slate-900' : perm.read ? 'text-slate-600' : 'text-slate-400'}`}
                                      title="切換全部權限"
                                    >
                                      {ADMIN_PERMISSION_LABELS[key]}
                                    </button>
                                    {CRUD_OPS.map(op => (
                                      <label key={op} className="w-10 flex justify-center cursor-pointer">
                                        <input
                                          type="checkbox"
                                          checked={perm[op]}
                                          onChange={e => {
                                            const updated = { ...perm, [op]: e.target.checked };
                                            if (op === 'read' && !e.target.checked) {
                                              updated.create = false; updated.update = false; updated.delete = false; updated.export = false;
                                            }
                                            setEditingAdminAccount(prev => prev ? {
                                              ...prev,
                                              permissions: { ...(prev.permissions || DEFAULT_ADMIN_PERMISSIONS), [key]: updated }
                                            } : null);
                                          }}
                                          className="w-4 h-4 rounded accent-blue-600"
                                        />
                                      </label>
                                    ))}
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {editingAdminAccount.role === 'super_admin' && (
                      <div className="bg-violet-50 rounded-2xl p-4 text-center text-sm text-violet-700 font-bold">
                        👑 超級管理員擁有全部功能的存取權，包括員工與權限管理
                      </div>
                    )}

                    <div className="flex gap-3 pt-2">
                      <button onClick={() => setEditingAdminAccount(null)} className="flex-1 py-4 bg-slate-100 text-slate-700 rounded-2xl font-black text-sm active:scale-95 transition-all">取消</button>
                      <button
                        onClick={async () => {
                          const perms = editingAdminAccount.permissions as AdminPermissions || DEFAULT_ADMIN_PERMISSIONS;
                          const role = (editingAdminAccount.role || 'admin') as AdminRole;
                          if (editingAdminAccount.isNew) {
                            await grantAdminAccess(editingAdminAccount.newPhone || '', role, perms);
                          } else if (editingAdminAccount.id) {
                            await updateAdminAccount(editingAdminAccount.id, role, perms);
                          }
                        }}
                        className="flex-1 py-4 bg-blue-600 text-white rounded-2xl font-black text-sm shadow-xl active:scale-95 transition-all flex items-center justify-center gap-2"
                      >
                        <Save size={16}/> {editingAdminAccount.isNew ? '確認授權' : '儲存更改'}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ═══ Edit / Add Role Modal ═══ */}
            {editingStaffRole && (
              <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
                <div className="bg-white rounded-[2.5rem] shadow-2xl w-full max-w-xl max-h-[90vh] overflow-y-auto">
                  <div className="p-8 space-y-6">
                    <div className="flex items-center justify-between">
                      <h3 className="text-xl font-black">{editingStaffRole.isNew ? '新增角色' : '編輯角色'}</h3>
                      <button onClick={() => setEditingStaffRole(null)} className="p-2 text-slate-400 hover:text-slate-600 rounded-xl"><X size={20}/></button>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <label className="text-[10px] font-black text-slate-400 uppercase">角色代碼（英文）</label>
                        <input
                          type="text"
                          value={editingStaffRole.name || ''}
                          onChange={e => setEditingStaffRole(prev => prev ? { ...prev, name: e.target.value.toLowerCase().replace(/\s/g, '_') } : null)}
                          placeholder="e.g. driver"
                          disabled={!!editingStaffRole.isSystem}
                          className="w-full p-4 bg-slate-50 rounded-2xl font-bold focus:ring-2 focus:ring-blue-100 border border-transparent transition-all disabled:opacity-50"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-black text-slate-400 uppercase">顯示名稱</label>
                        <input
                          type="text"
                          value={editingStaffRole.displayName || ''}
                          onChange={e => setEditingStaffRole(prev => prev ? { ...prev, displayName: e.target.value } : null)}
                          placeholder="e.g. 司機"
                          className="w-full p-4 bg-slate-50 rounded-2xl font-bold focus:ring-2 focus:ring-blue-100 border border-transparent transition-all"
                        />
                      </div>
                    </div>

                    {/* CRUD Permission matrix grouped */}
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <label className="text-[10px] font-black text-slate-400 uppercase">模組權限（CRUD）</label>
                        <div className="flex gap-2">
                          <button
                            onClick={() => setEditingStaffRole(prev => {
                              if (!prev) return null;
                              const all: any = {};
                              Object.keys(DEFAULT_ADMIN_PERMISSIONS).forEach(k => all[k] = { ...FULL_ACCESS });
                              return { ...prev, modulePermissions: all };
                            })}
                            className="text-[10px] font-black text-blue-600 hover:underline"
                          >全選</button>
                          <button
                            onClick={() => setEditingStaffRole(prev => {
                              if (!prev) return null;
                              const none: any = {};
                              Object.keys(DEFAULT_ADMIN_PERMISSIONS).forEach(k => none[k] = { ...NO_ACCESS });
                              return { ...prev, modulePermissions: none };
                            })}
                            className="text-[10px] font-black text-slate-400 hover:underline"
                          >全不選</button>
                        </div>
                      </div>
                      {/* Column headers */}
                      <div className="flex items-center gap-1 pl-[140px]">
                        {CRUD_OPS.map(op => (
                          <span key={op} className="w-10 text-center text-[9px] font-black text-slate-300 uppercase">{CRUD_OP_LABELS[op]}</span>
                        ))}
                      </div>
                      {PERMISSION_GROUPS.map(group => (
                        <div key={group.label}>
                          <p className="text-[10px] font-black text-slate-300 uppercase mb-1.5">{group.label}</p>
                          <div className="space-y-1">
                            {group.keys.map(key => {
                              const perm = normalizePermValue((editingStaffRole.modulePermissions as any)?.[key]);
                              const allOn = CRUD_OPS.every(op => perm[op]);
                              return (
                                <div key={key} className="flex items-center gap-1 p-2 bg-slate-50 rounded-xl hover:bg-slate-100 transition-all">
                                  <button
                                    onClick={() => {
                                      const newPerm = allOn ? { ...NO_ACCESS } : { ...FULL_ACCESS };
                                      setEditingStaffRole(prev => prev ? {
                                        ...prev,
                                        modulePermissions: { ...(prev.modulePermissions || DEFAULT_ADMIN_PERMISSIONS), [key]: newPerm }
                                      } : null);
                                    }}
                                    className={`w-[132px] text-left text-xs font-bold truncate ${allOn ? 'text-slate-900' : perm.read ? 'text-slate-600' : 'text-slate-400'}`}
                                    title="切換全部權限"
                                  >
                                    {ADMIN_PERMISSION_LABELS[key]}
                                  </button>
                                  {CRUD_OPS.map(op => (
                                    <label key={op} className="w-10 flex justify-center cursor-pointer">
                                      <input
                                        type="checkbox"
                                        checked={perm[op]}
                                        onChange={e => {
                                          const updated = { ...perm, [op]: e.target.checked };
                                          if (op === 'read' && !e.target.checked) {
                                            updated.create = false; updated.update = false; updated.delete = false; updated.export = false;
                                          }
                                          setEditingStaffRole(prev => prev ? {
                                            ...prev,
                                            modulePermissions: { ...(prev.modulePermissions || DEFAULT_ADMIN_PERMISSIONS), [key]: updated }
                                          } : null);
                                        }}
                                        className="w-4 h-4 rounded accent-blue-600"
                                      />
                                    </label>
                                  ))}
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="flex gap-3 pt-2">
                      <button onClick={() => setEditingStaffRole(null)} className="flex-1 py-4 bg-slate-100 text-slate-700 rounded-2xl font-black text-sm active:scale-95 transition-all">取消</button>
                      <button
                        onClick={() => saveStaffRole(editingStaffRole)}
                        disabled={!editingStaffRole.name || !editingStaffRole.displayName}
                        className="flex-1 py-4 bg-blue-600 text-white rounded-2xl font-black text-sm shadow-xl active:scale-95 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                      >
                        <Save size={16}/> {editingStaffRole.isNew ? '建立角色' : '儲存更改'}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        );
      }
      default: return null;
    }
  };

  const renderGlobalModals = () => (
    <>
      {/* ── 一鍵回購 Modal（訪客輸入手機號碼）── */}
      {reorderModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[5500] flex items-center justify-center p-6 animate-fade-in" onClick={() => setReorderModalOpen(false)}>
          <div className="bg-white w-full max-w-sm rounded-[2rem] shadow-2xl p-7 space-y-4 animate-scale-up" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2"><Clock size={18} className="text-amber-500" /><h3 className="text-base font-black text-slate-900">一鍵回購</h3></div>
              <button onClick={() => setReorderModalOpen(false)} className="p-2 bg-slate-100 rounded-full text-slate-400 active:scale-90"><X size={16}/></button>
            </div>
            <p className="text-[11px] text-slate-400 font-bold">輸入上次落單用嘅手機號碼，即刻幫你填返成份清單。</p>
            <input
              type="tel"
              inputMode="numeric"
              placeholder="手機號碼（如 91234567）"
              value={reorderPhone}
              onChange={e => handleReorderPhoneCheck(e.target.value)}
              className="w-full p-4 bg-slate-50 rounded-2xl font-bold text-sm border border-slate-100 focus:ring-2 focus:ring-amber-100 focus:border-amber-200 transition-all"
              autoFocus
            />
            {/* 動態提示 */}
            {reorderHint.text && (
              <div className="px-1">
                <p className="text-[11px] text-slate-400 font-bold leading-relaxed">{reorderHint.text}</p>
                {reorderHint.type === 'member' && (
                  <button onClick={() => { setReorderModalOpen(false); setView('profile'); }} className="text-[11px] text-blue-500 font-black mt-1 hover:underline">立即登入 →</button>
                )}
              </div>
            )}
            <button
              disabled={reorderPhone.length < 6 || reorderLoading}
              onClick={() => handleReorderByPhone(reorderPhone)}
              className="w-full py-4 bg-amber-500 text-white rounded-2xl font-black text-sm shadow-xl active:scale-95 transition-all disabled:opacity-40 flex items-center justify-center gap-2"
            >
              {reorderLoading ? <RefreshCw size={16} className="animate-spin" /> : <Clock size={16}/>}
              {reorderLoading ? '查詢中...' : '搵返上次嘅清單'}
            </button>
          </div>
        </div>
      )}

      {selectedProduct && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[5500] flex items-end justify-center animate-fade-in" onClick={() => setSelectedProduct(null)}>
          <div className="bg-white w-full max-w-md rounded-t-[3rem] shadow-2xl p-8 space-y-6 animate-slide-up overflow-y-auto max-h-[90vh] hide-scrollbar" onClick={e => e.stopPropagation()}>
             <div className="flex justify-between items-start">
               <div className="w-32 h-32 bg-slate-50 rounded-[2rem] flex items-center justify-center text-6xl border border-slate-100 overflow-hidden">
                  {isMediaUrl(selectedProduct.image) ? <img src={selectedProduct.image} className="w-full h-full object-cover" alt={selectedProduct.imageAlt || pName(selectedProduct)} /> : selectedProduct.image}
               </div>
               <button onClick={() => setSelectedProduct(null)} className="p-3 bg-slate-100 rounded-full text-slate-400 active:scale-90 transition-transform"><X size={20}/></button>
             </div>
             {selectedProduct.gallery && selectedProduct.gallery.length > 0 && (
               <div className="flex gap-2 overflow-x-auto hide-scrollbar pb-1 -mt-2">
                 {selectedProduct.gallery.map((url, i) => (
                   <div key={i} className="w-16 h-16 rounded-xl overflow-hidden border border-slate-100 flex-shrink-0">
                     <img src={url} loading="lazy" alt="" className="w-full h-full object-cover" />
                   </div>
                 ))}
               </div>
             )}
             <div className="space-y-2">
               <h3 className="text-2xl font-black text-slate-900 leading-tight">{pName(selectedProduct)}</h3>
               <div className="flex flex-wrap gap-2">
                 {selectedProduct.tags.map(tg => <span key={tg} className="px-2.5 py-1 bg-blue-50 text-blue-600 rounded-lg text-[10px] font-black border border-blue-100 uppercase tracking-tight">{tg}</span>)}
               </div>
               {(selectedProduct.origin || selectedProduct.weight) && (
                 <div className="flex gap-3 text-[11px] text-slate-400 font-bold">
                   {selectedProduct.origin && <span>產地：{selectedProduct.origin}</span>}
                   {selectedProduct.weight && <span>重量：{selectedProduct.weight}</span>}
                 </div>
               )}
             </div>
             {(pDesc(selectedProduct)) && (
               <p className="text-sm text-slate-600 font-medium leading-relaxed">{pDesc(selectedProduct)}</p>
             )}
             {/* Standalone recipes linked to this product (bidirectional) */}
             {(() => {
               const linkedRecipes = getRecipesForProduct(selectedProduct.id);
               if (linkedRecipes.length === 0) return null;
               return (
                 <div className="space-y-2">
                   <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-1.5"><BookOpen size={12} /> {t.recipes.recommendedRecipes}</p>
                   {linkedRecipes.map(r => (
                     <button key={r.id} onClick={() => { setSelectedProduct(null); setSelectedRecipe(r); }} className="w-full p-3 bg-amber-50/50 rounded-xl border border-amber-100/50 text-left hover:bg-amber-50 transition-all">
                       <div className="flex items-center gap-3">
                         {r.mediaUrl && isMediaUrl(r.mediaUrl) ? (
                           <img src={r.mediaUrl} alt={r.title} className="w-10 h-10 rounded-lg object-cover flex-shrink-0" />
                         ) : (
                           <div className="w-10 h-10 bg-amber-100 rounded-lg flex items-center justify-center flex-shrink-0"><BookOpen size={16} className="text-amber-600" /></div>
                         )}
                         <div className="min-w-0 flex-1">
                           <p className="text-xs font-black text-slate-700 truncate">{r.title}</p>
                           <div className="flex gap-1.5 mt-0.5">
                             {r.cookingTime > 0 && <span className="text-[9px] text-amber-600 font-bold"><Clock size={8} className="inline mr-0.5" />{r.cookingTime}{t.recipes.minutes}</span>}
                             {r.tags.slice(0, 2).map(tag => <span key={tag} className="text-[9px] text-blue-500 font-bold">{tag}</span>)}
                           </div>
                         </div>
                         <ChevronRight size={14} className="text-slate-300 flex-shrink-0" />
                       </div>
                     </button>
                   ))}
                 </div>
               );
             })()}
             {selectedProduct.purchaseLimit && (
               <div className="flex items-center gap-2 px-4 py-2.5 bg-orange-50 border border-orange-100 rounded-2xl">
                 <span className="text-orange-500 text-sm">⚠️</span>
                 <p className="text-[11px] font-black text-orange-600">每單只限買 {selectedProduct.purchaseLimit} 件</p>
               </div>
             )}
             <div className="flex items-center justify-between p-6 bg-slate-900 text-white rounded-[2.5rem] shadow-xl">
               {hideWholesalePrice ? (
                 <>
                   <div><p className="text-[10px] font-bold text-white/40 uppercase tracking-widest mb-1">批發價格</p><p className="text-lg font-bold text-amber-400">登入後查看價格</p></div>
                   <button onClick={() => { setSelectedProduct(null); setView('profile'); }} className="bg-amber-500 text-white px-8 py-5 rounded-[1.5rem] font-black text-sm shadow-2xl active:scale-95 transition-all">登入 / 註冊</button>
                 </>
               ) : (
                 <>
                   <div><p className="text-[10px] font-bold text-white/40 uppercase tracking-widest mb-1">精選價</p><p className="text-3xl font-black">${formatMoney(getPrice(selectedProduct))}</p>{getPrice(selectedProduct) < selectedProduct.price && <p className="text-xs text-white/40 line-through">${formatMoney(selectedProduct.price)}</p>}</div>
                   <button onClick={() => { updateCart(selectedProduct, 1); setSelectedProduct(null); showToast('已加入購物車'); }} className={`${accentClass} text-white px-10 py-5 rounded-[1.5rem] font-black text-sm shadow-2xl active:scale-95 transition-all`}>立即選購</button>
                 </>
               )}
             </div>
          </div>
        </div>
      )}

      {/* ── Recipe Editor Modal (Admin) ── */}
      {editingRecipe && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[6000] flex items-center justify-center p-6 animate-fade-in">
          <div className="bg-white w-full max-w-3xl rounded-[3rem] shadow-2xl overflow-hidden flex flex-col max-h-[95vh] animate-scale-up">
            <div className="p-8 border-b border-slate-50 flex justify-between items-center bg-slate-900 text-white">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center"><BookOpen size={22}/></div>
                <div>
                  <h4 className="text-2xl font-black tracking-tight">{editingRecipe.title || t.recipes.editRecipe}</h4>
                  <p className="text-[10px] font-bold text-white/40 uppercase tracking-[0.2em]">{editingRecipe.id.slice(0, 8)}</p>
                </div>
              </div>
              <button onClick={() => setEditingRecipe(null)} className="p-3 bg-white/10 rounded-full hover:bg-white/20 transition-all text-white"><X size={20}/></button>
            </div>
            <div className="flex-1 overflow-y-auto p-10 space-y-6 hide-scrollbar">
              {/* Title + AI generate button */}
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t.recipes.recipeTitle}</label>
                <div className="flex gap-2">
                  <input value={editingRecipe.title} onChange={e => setEditingRecipe({ ...editingRecipe, title: e.target.value })} className="flex-1 p-3 bg-slate-50 rounded-2xl font-bold" placeholder="例如：氣炸鍋牛扒" />
                  <button type="button" disabled={aiRecipeLoading} onClick={() => openAiRecipePrompt(editingRecipe)} className="px-4 py-3 bg-purple-50 text-purple-600 rounded-2xl font-black text-xs hover:bg-purple-100 transition-all disabled:opacity-50 flex items-center gap-1.5 flex-shrink-0">
                    {aiRecipeLoading ? <RefreshCw size={14} className="animate-spin" /> : <Sparkles size={14} />}
                    AI 寫食譜
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t.recipes.description}</label>
                <textarea value={editingRecipe.description} onChange={e => setEditingRecipe({ ...editingRecipe, description: e.target.value })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold min-h-[60px]" placeholder="簡短介紹這道菜..." />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Media: upload + URL */}
                <div className="space-y-2 md:col-span-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">封面圖片 / 影片</label>
                  <div className="flex items-start gap-4">
                    <label className={`relative flex-shrink-0 w-28 h-28 rounded-2xl border-2 border-dashed ${imageUploading === `recipe-${editingRecipe.id}` ? 'border-blue-400 bg-blue-50' : 'border-slate-200 bg-slate-50'} flex items-center justify-center cursor-pointer hover:border-blue-400 hover:bg-blue-50 transition-all overflow-hidden group`}>
                      {imageUploading === `recipe-${editingRecipe.id}` ? (
                        <RefreshCw size={22} className="text-blue-500 animate-spin" />
                      ) : editingRecipe.mediaUrl && isMediaUrl(editingRecipe.mediaUrl) ? (
                        <img src={editingRecipe.mediaUrl} alt="" className="w-full h-full object-cover" />
                      ) : (
                        <div className="text-center"><Upload size={20} className="mx-auto text-slate-300 mb-1" /><span className="text-[9px] text-slate-400 font-bold">上傳圖片</span></div>
                      )}
                      {editingRecipe.mediaUrl && isMediaUrl(editingRecipe.mediaUrl) && <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center"><Upload size={18} className="text-white" /></div>}
                      <input type="file" accept="image/*" className="hidden" onChange={e => handleImageUpload(e.target.files, `recipes/${editingRecipe.id}`, async ([url]) => { if (isMediaUrl(editingRecipe.mediaUrl)) await deleteImage(editingRecipe.mediaUrl); setEditingRecipe({ ...editingRecipe, mediaUrl: url, mediaType: 'image' }); }, { uploadKey: `recipe-${editingRecipe.id}` })} />
                    </label>
                    <div className="flex-1 space-y-2">
                      <input value={editingRecipe.mediaUrl} onChange={e => setEditingRecipe({ ...editingRecipe, mediaUrl: e.target.value })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold text-xs" placeholder="或貼上圖片 / 影片 / YouTube URL" />
                      <select value={editingRecipe.mediaType} onChange={e => setEditingRecipe({ ...editingRecipe, mediaType: e.target.value as 'image' | 'video' })} className="w-full p-2 bg-slate-50 rounded-xl font-bold text-xs">
                        <option value="image">{t.recipes.image}</option>
                        <option value="video">{t.recipes.video}</option>
                      </select>
                      <button
                        type="button"
                        disabled={imageUploading === `ai-recipe-${editingRecipe.id}` || !editingRecipe.title.trim()}
                        onClick={async () => {
                          if (!editingRecipe.title.trim()) return;
                          setImageUploading(`ai-recipe-${editingRecipe.id}`);
                          try {
                            const url = await generateAndUploadRecipeImage(editingRecipe.id, editingRecipe.title, editingRecipe.description);
                            if (url) setEditingRecipe(prev => prev ? { ...prev, mediaUrl: url, mediaType: 'image' } : prev);
                            else showToast('AI 圖片生成失敗，請稍後重試', 'error');
                          } finally {
                            setImageUploading(null);
                          }
                        }}
                        className="w-full py-2 bg-purple-50 text-purple-600 border border-purple-200 rounded-xl font-black text-xs flex items-center justify-center gap-1.5 hover:bg-purple-100 transition-all disabled:opacity-50"
                      >
                        {imageUploading === `ai-recipe-${editingRecipe.id}` ? <><RefreshCw size={13} className="animate-spin" /> AI 生成圖片中...</> : <><Sparkles size={13} /> AI 生成封面圖片</>}
                      </button>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t.recipes.cookingTime} ({t.recipes.minutes})</label>
                  <input type="number" min="0" value={editingRecipe.cookingTime || ''} onChange={e => setEditingRecipe({ ...editingRecipe, cookingTime: Number(e.target.value) || 0 })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold" placeholder="15" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">份量</label>
                  <select value={editingRecipe.servingSize} onChange={e => setEditingRecipe({ ...editingRecipe, servingSize: e.target.value })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold">
                    {SERVING_SIZES.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>

                {/* Recipe categories */}
                <div className="space-y-2 md:col-span-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">食譜分類</label>
                  <div className="flex flex-wrap gap-2">
                    {recipeCategories.map(cat => {
                      const isSelected = editingRecipe.categoryIds.includes(cat.id);
                      return (
                        <button key={cat.id} type="button" onClick={() => {
                          const next = isSelected ? editingRecipe.categoryIds.filter(c => c !== cat.id) : [...editingRecipe.categoryIds, cat.id];
                          setEditingRecipe({ ...editingRecipe, categoryIds: next });
                        }} className={`px-3 py-1.5 rounded-xl text-xs font-black border transition-all ${isSelected ? 'bg-amber-500 text-white border-amber-500 shadow-md' : 'bg-slate-50 text-slate-500 border-slate-200 hover:border-amber-300'}`}>
                          {cat.icon} {cat.name}
                        </button>
                      );
                    })}
                    {recipeCategories.length === 0 && <p className="text-[9px] text-slate-400 font-bold">到「食譜分類」子頁籤新增分類</p>}
                  </div>
                </div>

                {/* Tags (special notes) */}
                <div className="space-y-2 md:col-span-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">標籤 / 備註</label>
                  <input value={editingRecipe.tags.join(', ')} onChange={e => setEditingRecipe({ ...editingRecipe, tags: e.target.value.split(',').map(v => v.trim()).filter(Boolean) })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold text-xs" placeholder="特別備註，例如：無麩質、低卡、減肥餐" />
                </div>
              </div>

              {/* ── 關聯產品選擇（with search） ── */}
              <div className="space-y-3 p-5 bg-gradient-to-r from-blue-50/60 to-indigo-50/60 rounded-2xl border border-blue-100/60">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <ShoppingBag size={14} className="text-blue-600" />
                    <label className="text-[10px] font-bold text-blue-700 uppercase tracking-widest">{t.recipes.selectProducts}</label>
                  </div>
                  <button type="button" disabled={aiRecipeLoading} onClick={() => openAiRecipePrompt(editingRecipe)} className="px-3 py-1.5 rounded-xl text-[9px] font-black bg-purple-50 text-purple-600 border border-purple-200 hover:bg-purple-100 transition-all disabled:opacity-50 flex items-center gap-1">
                    {aiRecipeLoading ? <RefreshCw size={10} className="animate-spin" /> : <Sparkles size={10} />} AI 寫食譜
                  </button>
                </div>
                <div className="relative">
                  <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-300" />
                  <input value={recipeProductSearch} onChange={e => setRecipeProductSearch(e.target.value)} className="w-full pl-9 pr-3 py-2 bg-white rounded-xl text-xs font-bold border border-slate-100" placeholder={t.recipes.searchProducts} />
                </div>
                <div className="flex flex-wrap gap-2 max-h-40 overflow-y-auto hide-scrollbar">
                  {products.filter(p => !recipeProductSearch || p.name.toLowerCase().includes(recipeProductSearch.toLowerCase())).map(p => {
                    const isLinked = editingRecipe.linkedProductIds.includes(p.id);
                    return (
                      <button key={p.id} type="button" onClick={() => {
                        const ids = editingRecipe.linkedProductIds;
                        const next = isLinked ? ids.filter(x => x !== p.id) : [...ids, p.id];
                        setEditingRecipe({ ...editingRecipe, linkedProductIds: next });
                      }} className={`px-3 py-1.5 rounded-xl text-xs font-black border transition-all ${isLinked ? 'bg-blue-600 text-white border-blue-600 shadow-md' : 'bg-white text-slate-500 border-slate-200 hover:border-blue-300'}`}>
                        {isMediaUrl(p.image) ? <img src={p.image} alt="" className="w-4 h-4 rounded inline-block mr-1.5 object-cover" /> : <span className="mr-1">{p.image}</span>}
                        {p.name}
                      </button>
                    );
                  })}
                </div>
                {editingRecipe.linkedProductIds.length === 0 && <p className="text-[9px] text-blue-400 font-bold">{t.recipes.noProductsLinked}</p>}
              </div>

              {/* ── 食材清單 ── */}
              <div className="space-y-3 p-5 bg-gradient-to-r from-amber-50/60 to-orange-50/60 rounded-2xl border border-amber-100/60">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <UtensilsCrossed size={14} className="text-amber-600" />
                    <label className="text-[10px] font-bold text-amber-700 uppercase tracking-widest">{t.recipes.rawIngredients}</label>
                  </div>
                  <button type="button" onClick={() => setEditingRecipe({ ...editingRecipe, ingredientsRaw: [...editingRecipe.ingredientsRaw, { name: '', amount: '' }] })} className="px-3 py-1.5 rounded-xl text-[10px] font-black border border-amber-200 text-amber-600 hover:bg-amber-100 transition-all flex items-center gap-1">
                    <Plus size={12} /> {t.recipes.addIngredient}
                  </button>
                </div>
                {/* Quick-add common ingredients */}
                <div className="flex flex-wrap gap-1.5">
                  {COMMON_INGREDIENTS.map(name => {
                    const exists = editingRecipe.ingredientsRaw.some(i => i.name === name);
                    return (
                      <button key={name} type="button" onClick={() => {
                        if (exists) {
                          setEditingRecipe({ ...editingRecipe, ingredientsRaw: editingRecipe.ingredientsRaw.filter(i => i.name !== name) });
                        } else {
                          setEditingRecipe({ ...editingRecipe, ingredientsRaw: [...editingRecipe.ingredientsRaw, { name, amount: '適量' }] });
                        }
                      }} className={`px-2 py-0.5 rounded-lg text-[10px] font-bold border transition-all ${exists ? 'bg-amber-500 text-white border-amber-500' : 'bg-white text-slate-500 border-slate-200 hover:border-amber-300'}`}>
                        {name}
                      </button>
                    );
                  })}
                </div>
                {editingRecipe.ingredientsRaw.map((ing, idx) => (
                  <div key={idx} className="flex gap-2 items-center">
                    <input value={ing.name} onChange={e => {
                      const next = [...editingRecipe.ingredientsRaw];
                      next[idx] = { ...next[idx], name: e.target.value };
                      setEditingRecipe({ ...editingRecipe, ingredientsRaw: next });
                    }} className="flex-1 p-2.5 bg-white rounded-xl font-bold text-xs border border-slate-100" placeholder={t.recipes.ingredientName} />
                    <input value={ing.amount} onChange={e => {
                      const next = [...editingRecipe.ingredientsRaw];
                      next[idx] = { ...next[idx], amount: e.target.value };
                      setEditingRecipe({ ...editingRecipe, ingredientsRaw: next });
                    }} className="w-24 p-2.5 bg-white rounded-xl font-bold text-xs border border-slate-100" placeholder={t.recipes.ingredientAmount} />
                    <button type="button" onClick={() => {
                      setEditingRecipe({ ...editingRecipe, ingredientsRaw: editingRecipe.ingredientsRaw.filter((_, i) => i !== idx) });
                    }} className="p-1.5 text-slate-300 hover:text-rose-500 transition-colors"><Trash2 size={14} /></button>
                  </div>
                ))}
              </div>

              {/* ── 步驟 ── */}
              <div className="space-y-3 p-5 bg-gradient-to-r from-emerald-50/60 to-teal-50/60 rounded-2xl border border-emerald-100/60">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <ClipboardList size={14} className="text-emerald-600" />
                    <label className="text-[10px] font-bold text-emerald-700 uppercase tracking-widest">{t.recipes.steps}</label>
                  </div>
                  <button type="button" onClick={() => {
                    const maxOrder = editingRecipe.steps.length > 0 ? Math.max(...editingRecipe.steps.map(s => s.order)) : 0;
                    setEditingRecipe({ ...editingRecipe, steps: [...editingRecipe.steps, { order: maxOrder + 1, content: '' }] });
                  }} className="px-3 py-1.5 rounded-xl text-[10px] font-black border border-emerald-200 text-emerald-600 hover:bg-emerald-100 transition-all flex items-center gap-1">
                    <Plus size={12} /> {t.recipes.addStep}
                  </button>
                </div>
                {editingRecipe.steps.sort((a, b) => a.order - b.order).map((step, idx) => (
                  <div key={idx} className="flex gap-2 items-start">
                    <div className="w-8 h-8 bg-emerald-100 rounded-full flex items-center justify-center text-emerald-700 font-black text-xs flex-shrink-0 mt-1">{step.order}</div>
                    <textarea value={step.content} onChange={e => {
                      const next = [...editingRecipe.steps];
                      next[idx] = { ...next[idx], content: e.target.value };
                      setEditingRecipe({ ...editingRecipe, steps: next });
                    }} className="flex-1 p-2.5 bg-white rounded-xl font-bold text-xs border border-slate-100 min-h-[60px]" placeholder={`${t.recipes.step} ${step.order}`} />
                    <button type="button" onClick={() => {
                      const filtered = editingRecipe.steps.filter((_, i) => i !== idx);
                      const reordered = filtered.map((s, i) => ({ ...s, order: i + 1 }));
                      setEditingRecipe({ ...editingRecipe, steps: reordered });
                    }} className="p-1.5 text-slate-300 hover:text-rose-500 transition-colors mt-1"><Trash2 size={14} /></button>
                  </div>
                ))}
              </div>
            </div>
            <div className="p-8 bg-slate-50 border-t border-slate-100 flex justify-between items-center">
              <button onClick={() => {
                setConfirmation({
                  title: t.recipes.deleteRecipe,
                  message: t.recipes.confirmDelete,
                  onConfirm: () => { deleteRecipe(editingRecipe.id); setEditingRecipe(null); }
                });
              }} className="px-5 py-3 bg-rose-50 text-rose-600 border border-rose-200 rounded-2xl font-black text-xs hover:bg-rose-100 transition-all">
                <Trash2 size={14} className="inline mr-1" /> {t.recipes.deleteRecipe}
              </button>
              <div className="flex gap-3">
                <button onClick={() => setEditingRecipe(null)} className="px-6 py-3 bg-white border border-slate-200 rounded-2xl font-black text-xs">{t.recipes.cancel}</button>
                <button onClick={() => {
                  if (!editingRecipe.title.trim()) { showToast('請輸入食譜名稱', 'error'); return; }
                  upsertRecipe(editingRecipe);
                  setEditingRecipe(null);
                }} className="px-6 py-3 bg-slate-900 text-white rounded-2xl font-black text-xs">{t.recipes.save}</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── Recipe Detail Modal (Storefront) ── */}
      {selectedRecipe && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[5500] flex items-end justify-center animate-fade-in" onClick={() => setSelectedRecipe(null)}>
          <div className="bg-white w-full max-w-md rounded-t-[3rem] shadow-2xl overflow-y-auto max-h-[92vh] hide-scrollbar animate-slide-up" onClick={e => e.stopPropagation()}>
            {/* Media */}
            {selectedRecipe.mediaUrl && isMediaUrl(selectedRecipe.mediaUrl) && (
              <div className="relative aspect-video bg-slate-100">
                {selectedRecipe.mediaType === 'video' ? (
                  <video src={selectedRecipe.mediaUrl} controls className="w-full h-full object-cover" />
                ) : (
                  <img src={selectedRecipe.mediaUrl} alt={selectedRecipe.title} className="w-full h-full object-cover" />
                )}
                <button onClick={() => setSelectedRecipe(null)} className="absolute top-4 right-4 p-3 bg-white/90 backdrop-blur rounded-full text-slate-500 active:scale-90 transition-transform shadow-lg"><X size={20}/></button>
              </div>
            )}
            {!(selectedRecipe.mediaUrl && isMediaUrl(selectedRecipe.mediaUrl)) && (
              <div className="flex justify-end p-6 pb-0">
                <button onClick={() => setSelectedRecipe(null)} className="p-3 bg-slate-100 rounded-full text-slate-400 active:scale-90 transition-transform"><X size={20}/></button>
              </div>
            )}
            <div className="p-6 space-y-5">
              {/* Title & tags */}
              <div className="space-y-2">
                <h3 className="text-2xl font-black text-slate-900 leading-tight">{selectedRecipe.title}</h3>
                <div className="flex flex-wrap gap-2">
                  {selectedRecipe.cookingTime > 0 && <span className="px-2.5 py-1 bg-amber-50 text-amber-600 rounded-lg text-[10px] font-black border border-amber-100 flex items-center gap-1"><Clock size={10} />{selectedRecipe.cookingTime} {t.recipes.minutes}</span>}
                  {selectedRecipe.tags.map(tag => <span key={tag} className="px-2.5 py-1 bg-blue-50 text-blue-600 rounded-lg text-[10px] font-black border border-blue-100">{tag}</span>)}
                </div>
                {selectedRecipe.description && <p className="text-sm text-slate-500 font-medium leading-relaxed">{selectedRecipe.description}</p>}
              </div>

              {/* Unified ingredient list: linked products first, then raw ingredients */}
              {(selectedRecipe.linkedProductIds.length > 0 || selectedRecipe.ingredientsRaw.length > 0) && (
                <div className="space-y-2.5">
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-1.5"><UtensilsCrossed size={12} /> {t.recipes.ingredients}</p>
                  {selectedRecipe.servingSize && <p className="text-[10px] text-slate-400 font-bold">📍 {selectedRecipe.servingSize}</p>}
                  <div className="bg-slate-50 rounded-xl p-3 space-y-2">
                    {/* Linked products listed first */}
                    {selectedRecipe.linkedProductIds.map(pid => {
                      const p = products.find(x => x.id === pid);
                      if (!p) return null;
                      const itemInCart = cart.find(i => i.id === p.id);
                      const qty = itemInCart?.qty || 0;
                      return (
                        <div key={p.id} className="flex items-center gap-2.5 py-1.5">
                          <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center overflow-hidden border border-slate-100 flex-shrink-0">
                            {isMediaUrl(p.image) ? <img src={p.image} alt={pName(p)} className="w-full h-full object-cover" /> : <span className="text-sm">{p.image}</span>}
                          </div>
                          <span className="flex-1 text-xs font-bold text-slate-800">{pName(p)}</span>
                          <div className="flex items-center gap-1.5">
                            <span className="text-[10px] text-blue-600 font-bold">${formatMoney(getPrice(p))}</span>
                            <div className="flex items-center rounded-full p-0.5 border border-slate-100 bg-white shadow-sm">
                              {qty > 0 && (
                                <><button onClick={(e) => updateCart(p, -1, e)} className="w-6 h-6 flex items-center justify-center text-slate-300 active:scale-75"><Minus size={12}/></button><span className="mx-1 text-[11px] font-black text-slate-900 w-3 text-center">{qty}</span></>
                              )}
                              <button onClick={(e) => updateCart(p, 1, e)} className={`w-6 h-6 rounded-full flex items-center justify-center ${accentClass} text-white active:scale-90`}><Plus size={12}/></button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                    {/* Divider if both exist */}
                    {selectedRecipe.linkedProductIds.length > 0 && selectedRecipe.ingredientsRaw.length > 0 && <div className="border-t border-slate-200/60 my-1" />}
                    {/* Raw ingredients */}
                    {selectedRecipe.ingredientsRaw.map((ing, i) => (
                      <div key={i} className="flex justify-between text-xs py-0.5">
                        <span className="font-bold text-slate-700">{ing.name}</span>
                        <span className="text-slate-400 font-medium">{ing.amount}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Steps */}
              {selectedRecipe.steps.length > 0 && (
                <div className="space-y-3">
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-1.5"><ClipboardList size={12} /> {t.recipes.steps}</p>
                  {selectedRecipe.steps.sort((a, b) => a.order - b.order).map(step => (
                    <div key={step.order} className="flex gap-3">
                      <div className="w-7 h-7 bg-slate-900 rounded-full flex items-center justify-center text-white font-black text-[10px] flex-shrink-0 mt-0.5">{step.order}</div>
                      <p className="text-sm text-slate-700 font-medium leading-relaxed flex-1">{step.content}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Payment handled via Stripe Checkout (full-page redirect) */}

      {editingProduct && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[6000] flex items-center justify-center p-6 animate-fade-in">
          <div className="bg-white w-full max-w-3xl rounded-[3rem] shadow-2xl overflow-hidden flex flex-col max-h-[95vh] animate-scale-up">
            <div className="p-8 border-b border-slate-50 flex justify-between items-center bg-slate-900 text-white">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center"><Package size={22}/></div>
                <div>
                  <h4 className="text-2xl font-black tracking-tight">編輯產品</h4>
                  <p className="text-[10px] font-bold text-white/40 uppercase tracking-[0.2em]">{editingProduct.id}</p>
                </div>
              </div>
              <button onClick={() => setEditingProduct(null)} className="p-3 bg-white/10 rounded-full hover:bg-white/20 transition-all text-white"><X size={20}/></button>
            </div>
            <div className="flex-1 overflow-y-auto p-10 space-y-6 hide-scrollbar">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">名稱</label>
                  <input value={editingProduct.name} onChange={e => setEditingProduct({ ...editingProduct, name: e.target.value })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">商品 ID</label>
                  <input value={editingProduct.id} onChange={e => setEditingProduct({ ...editingProduct, id: e.target.value })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">ID (舊系統)</label>
                  <input value={editingProduct.legacyId || ''} onChange={e => setEditingProduct({ ...editingProduct, legacyId: e.target.value || undefined })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold font-mono" placeholder="選填，舊系統產品編號" />
                </div>
                <div className="space-y-2 md:col-span-2 p-4 bg-gradient-to-r from-emerald-50/60 to-teal-50/60 rounded-2xl border border-emerald-100/60">
                  <div className="flex items-center gap-2 mb-1">
                    <Coins size={14} className="text-emerald-600" />
                    <label className="text-[10px] font-bold text-emerald-700 uppercase tracking-widest">定價預覽</label>
                    <span className="text-[9px] text-slate-400 font-bold ml-auto">售價由系統根據成本 × 利潤率自動計算，前往「價錢設定」套用</span>
                  </div>
                  {(() => {
                    const linkedIng = ingredients.find(i => i.id === editingProduct.ingredientId);
                    const perLbCost = computeProductCost(editingProduct, linkedIng, costItems);
                    const packCost = editingProduct.pricingMode === 'fixed_pack' && editingProduct.packWeightLb
                      ? perLbCost * editingProduct.packWeightLb : perLbCost;
                    const rtFactor = siteConfig.pricingRules?.targetMarginFactor || 0.88;
                    const wsFactor = siteConfig.wholesalePricingRules?.targetMarginFactor || 0.88;
                    const suggestedRetail = packCost > 0 ? roundPrice(packCost / rtFactor) : 0;
                    const suggestedP0 = packCost > 0 ? roundPrice(packCost / wsFactor) : 0;
                    return (
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                        <div className="p-2.5 bg-white rounded-xl border border-emerald-100">
                          <p className="text-[9px] text-slate-400 font-bold">成本/磅</p>
                          <p className="font-black text-slate-800">${formatMoney(perLbCost)}</p>
                        </div>
                        {editingProduct.pricingMode === 'fixed_pack' && editingProduct.packWeightLb ? (
                          <div className="p-2.5 bg-white rounded-xl border border-emerald-100">
                            <p className="text-[9px] text-slate-400 font-bold">成本/包 ({editingProduct.packWeightLb}磅)</p>
                            <p className="font-black text-amber-700">${formatMoney(packCost)}</p>
                          </div>
                        ) : null}
                        <div className="p-2.5 bg-white rounded-xl border border-emerald-100">
                          <p className="text-[9px] text-slate-400 font-bold">建議零售價</p>
                          <p className="font-black text-blue-600">${formatMoney(suggestedRetail)}</p>
                        </div>
                        <div className="p-2.5 bg-white rounded-xl border border-emerald-100">
                          <p className="text-[9px] text-slate-400 font-bold">建議批發 P0</p>
                          <p className="font-black text-orange-600">${formatMoney(suggestedP0)}</p>
                        </div>
                        <div className="p-2.5 bg-white rounded-xl border border-slate-100">
                          <p className="text-[9px] text-slate-400 font-bold">當前售價</p>
                          <p className="font-black text-slate-800">${formatMoney(editingProduct.price)}</p>
                        </div>
                      </div>
                    );
                  })()}
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">銷售渠道</label>
                  <select value={editingProduct.saleChannel || 'both'} onChange={e => setEditingProduct({ ...editingProduct, saleChannel: e.target.value as SaleChannel })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold">
                    <option value="both">零售 + 批發</option>
                    <option value="retail">僅零售</option>
                    <option value="wholesale">僅批發</option>
                  </select>
                </div>
                {/* ── Product Group & Variant Info ── */}
                {(() => {
                  const group = editingProduct.groupId ? productGroups.find(g => g.id === editingProduct.groupId) : null;
                  const siblings = editingProduct.groupId ? products.filter(p => p.groupId === editingProduct.groupId && p.id !== editingProduct.id) : [];
                  const classLabel = group?.classification === 'raw_material' ? '🥩 原材料' : group?.classification === 'third_party' ? '📦 第三方產品' : group?.classification === 'in_house' ? '🏭 自製產品' : null;
                  return (
                <div className="space-y-3 md:col-span-2 p-4 bg-gradient-to-r from-violet-50/60 to-purple-50/60 rounded-2xl border border-violet-100/60">
                  <div className="flex items-center gap-2 mb-1">
                    <Package size={14} className="text-violet-600" />
                    <label className="text-[10px] font-bold text-violet-700 uppercase tracking-widest">產品類型 / 規格設定</label>
                  </div>

                  {group ? (
                    <>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="px-2.5 py-1 bg-violet-100 text-violet-700 rounded-lg text-[10px] font-black">{classLabel}</span>
                        <span className="text-xs font-bold text-slate-700">{group.name}</span>
                        {(() => { const lbl = deriveVariantLabel(editingProduct.processingTypeId, editingProduct.pricingMode, editingProduct.packSize, group?.classification) || editingProduct.variantLabel; return lbl ? <span className="px-2 py-0.5 bg-white border border-violet-200 text-violet-600 rounded-md text-[10px] font-bold">規格: {lbl}</span> : null; })()}
                      </div>
                      {siblings.length > 0 && (
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-[9px] font-bold text-slate-400">同組規格:</span>
                          {siblings.map(s => (
                            <button key={s.id} onClick={() => setEditingProduct(s)} className="px-2 py-0.5 bg-white border border-slate-200 text-slate-600 rounded-md text-[10px] font-bold hover:border-violet-300 hover:text-violet-600 transition-colors">
                              {s.variantLabel || s.name}
                            </button>
                          ))}
                          <button onClick={async () => {
                            if (!group) return;
                            const newVariant: Product = {
                              id: 'P-' + Date.now(),
                              name: group.name,
                              categories: editingProduct.categories,
                              price: 0,
                              memberPrice: 0,
                              stock: 0,
                              trackInventory: true,
                              tags: editingProduct.tags,
                              image: editingProduct.image,
                              saleChannel: editingProduct.saleChannel,
                              productType: editingProduct.productType,
                              groupId: group.id,
                              parentIngredientId: editingProduct.parentIngredientId,
                              ingredientId: editingProduct.ingredientId,
                              variantLabel: '',
                              pricingMode: 'fixed_pack',
                            };
                            setEditingProduct(newVariant);
                          }} className="px-2 py-0.5 bg-violet-50 border border-dashed border-violet-300 text-violet-500 rounded-md text-[10px] font-bold hover:bg-violet-100 transition-colors flex items-center gap-0.5">
                            <Plus size={10} /> 新增規格
                          </button>
                        </div>
                      )}
                    </>
                  ) : (
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="text-[9px] font-bold text-slate-500 ml-1">產品類型</label>
                        <select value={editingProduct.productType || 'standalone'} onChange={e => setEditingProduct({ ...editingProduct, productType: e.target.value as ProductType })} className="w-full p-2.5 bg-white rounded-xl font-bold text-xs border border-slate-100">
                          <option value="standalone">獨立成品</option>
                          <option value="third_party">第三方產品</option>
                          <option value="raw_material">原材料</option>
                          <option value="in_house">自製產品</option>
                        </select>
                      </div>
                      {(editingProduct.productType === 'processed' || editingProduct.productType === 'raw_material') && (
                        <div className="space-y-1">
                          <label className="text-[9px] font-bold text-slate-500 ml-1">來源原材料</label>
                          <select value={editingProduct.parentIngredientId || ''} onChange={e => {
                            const val = e.target.value || undefined;
                            setEditingProduct({ ...editingProduct, parentIngredientId: val, ingredientId: val });
                          }} className="w-full p-2.5 bg-white rounded-xl font-bold text-xs border border-slate-100">
                            <option value="">— 選擇原材料 —</option>
                            {ingredientCategories.map(cat => {
                              const catIngs = ingredients.filter(i => i.category === cat);
                              if (catIngs.length === 0) return null;
                              return <optgroup key={cat} label={cat}>{catIngs.map(ing => <option key={ing.id} value={ing.id}>{ing.name} (${formatMoney(ing.baseCostPerLb)}/{ing.unit})</option>)}</optgroup>;
                            })}
                            {ingredients.filter(i => !i.category).length > 0 && <optgroup label="未分類">{ingredients.filter(i => !i.category).map(ing => <option key={ing.id} value={ing.id}>{ing.name} (${formatMoney(ing.baseCostPerLb)}/{ing.unit})</option>)}</optgroup>}
                          </select>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Variant-specific fields */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-slate-500 ml-1">規格標籤（自動）</label>
                      <div className="w-full p-2.5 bg-violet-50 rounded-xl font-bold text-xs border border-violet-200 text-violet-700 min-h-[36px] flex items-center">
                        {deriveVariantLabel(editingProduct.processingTypeId, editingProduct.pricingMode, editingProduct.packSize, group?.classification) || editingProduct.variantLabel || <span className="text-slate-300">由加工方式及包裝規格自動產生</span>}
                      </div>
                    </div>
                    {(group?.classification === 'raw_material' || editingProduct.productType === 'raw_material' || editingProduct.productType === 'processed') && (
                      <div className="space-y-1">
                        <label className="text-[9px] font-bold text-slate-500 ml-1">加工方式</label>
                        <select value={editingProduct.processingTypeId || ''} onChange={e => {
                          const ptId = e.target.value || undefined;
                          const pt = processingTypes.find(p => p.id === ptId);
                          const parentIng = ingredients.find(i => i.id === editingProduct.parentIngredientId);
                          const ingCategory = parentIng?.category?.toLowerCase() || '';
                          const isBLS = ingCategory.includes('牛') || ingCategory.includes('羊') || ingCategory.includes('海鮮');
                          const autoSurcharge = pt ? (isBLS ? pt.surchargeBeefLambSeafood : pt.surchargePorkChicken) : 0;
                          const reverseMap: Record<number, string> = { 1: '1磅/包', 2: '2磅/包', 5: '5磅/包', 10: '10磅/箱', 0.66: '300g/包', 1.1: '500g/包', 2.2: '1kg/包', 11: '5kg/包' };
                          const autoPackSize = pt?.requiresRepackaging && pt.defaultPackWeightLb ? (reverseMap[pt.defaultPackWeightLb] || `${pt.defaultPackWeightLb}磅/包`) : editingProduct.packSize;
                          const weightMap: Record<string, number> = { '1磅/包': 1, '2磅/包': 2, '5磅/包': 5, '10磅/箱': 10, '300g/包': 0.66, '500g/包': 1.1, '1kg/包': 2.2, '5kg/包': 11 };
                          setEditingProduct({
                            ...editingProduct,
                            processingTypeId: ptId,
                            processingCost: autoSurcharge,
                            packSize: autoPackSize,
                            packWeightLb: autoPackSize ? (weightMap[autoPackSize] ?? pt?.defaultPackWeightLb ?? editingProduct.packWeightLb) : editingProduct.packWeightLb,
                          });
                        }} className="w-full p-2.5 bg-white rounded-xl font-bold text-xs border border-slate-100">
                          <option value="">原件（不加工）</option>
                          {processingTypes.filter(pt => pt.code !== 'whole').map(pt => (
                            <option key={pt.id} value={pt.id}>{pt.name}{pt.spec ? ` (${pt.spec})` : ''}</option>
                          ))}
                        </select>
                      </div>
                    )}
                    {(group?.classification === 'raw_material' || editingProduct.productType === 'raw_material' || editingProduct.productType === 'processed') && (
                      <div className="space-y-1">
                        <label className="text-[9px] font-bold text-slate-500 ml-1">計價方式</label>
                        <select value={editingProduct.pricingMode || 'fixed_pack'} onChange={e => setEditingProduct({ ...editingProduct, pricingMode: e.target.value as PricingMode })} className="w-full p-2.5 bg-white rounded-xl font-bold text-xs border border-slate-100">
                          <option value="fixed_pack">定裝 (固定包裝)</option>
                          <option value="by_piece">抄碼 (按件計價)</option>
                        </select>
                      </div>
                    )}
                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-slate-500 ml-1">包裝規格</label>
                      <select value={editingProduct.packSize || ''} onChange={e => {
                        const val = e.target.value;
                        const weightMap: Record<string, number> = { '1磅/包': 1, '2磅/包': 2, '5磅/包': 5, '10磅/箱': 10, '300g/包': 0.66, '500g/包': 1.1, '1kg/包': 2.2, '5kg/包': 11 };
                        setEditingProduct({
                          ...editingProduct,
                          packSize: val || undefined,
                          packWeightLb: weightMap[val] ?? editingProduct.packWeightLb,
                        });
                      }} className="w-full p-2.5 bg-white rounded-xl font-bold text-xs border border-slate-100">
                        <option value="">— 選擇規格 —</option>
                        <option value="1磅/包">1磅/包</option>
                        <option value="2磅/包">2磅/包</option>
                        <option value="5磅/包">5磅/包</option>
                        <option value="10磅/箱">10磅/箱</option>
                        <option value="300g/包">300g/包</option>
                        <option value="500g/包">500g/包</option>
                        <option value="1kg/包">1kg/包</option>
                        <option value="5kg/包">5kg/包</option>
                        {editingProduct.packSize && !['1磅/包','2磅/包','5磅/包','10磅/箱','300g/包','500g/包','1kg/包','5kg/包'].includes(editingProduct.packSize) && (
                          <option value={editingProduct.packSize}>{editingProduct.packSize} (自訂)</option>
                        )}
                      </select>
                    </div>
                  </div>

                  {/* Cost preview for raw material variants */}
                  {editingProduct.parentIngredientId && editingProduct.processingTypeId && (() => {
                    const parentIng = ingredients.find(i => i.id === editingProduct.parentIngredientId);
                    const pt = processingTypes.find(p => p.id === editingProduct.processingTypeId);
                    if (!parentIng || !pt) return null;
                    const ingCategory = parentIng.category?.toLowerCase() || '';
                    const isBLS = ingCategory.includes('牛') || ingCategory.includes('羊') || ingCategory.includes('海鮮');
                    const surcharge = isBLS ? pt.surchargeBeefLambSeafood : pt.surchargePorkChicken;
                    const yr = editingProduct.yieldRate || 1;
                    const suggestedCost = (parentIng.baseCostPerLb / yr) + surcharge + (editingProduct.packagingCost || 0);
                    return (
                      <div className="mt-2 p-3 bg-white rounded-xl border border-violet-100 text-xs space-y-1">
                        <div className="flex justify-between"><span className="text-slate-400">原材料成本</span><span className="font-bold">${formatMoney(parentIng.baseCostPerLb)}/{parentIng.unit}</span></div>
                        <div className="flex justify-between"><span className="text-slate-400">加工費 ({pt.name})</span><span className="font-bold text-violet-600">+${formatMoney(surcharge)}/磅</span></div>
                        {yr < 1 && <div className="flex justify-between"><span className="text-slate-400">出成率</span><span className="font-bold">{(yr * 100).toFixed(0)}%</span></div>}
                        <div className="flex justify-between border-t border-slate-100 pt-1 mt-1"><span className="text-slate-500 font-bold">建議成本</span><span className="font-black text-amber-700">${formatMoney(suggestedCost)}/磅</span></div>
                        <div className="flex justify-between"><span className="text-slate-500 font-bold">當前售價</span><span className="font-black text-blue-600">${formatMoney(editingProduct.price)}/磅</span></div>
                      </div>
                    );
                  })()}
                </div>
                  );
                })()}

                {/* Cost note — editing moved to 材料與倉務 → 產品成本一覽 */}
                <div className="md:col-span-2 p-3 bg-amber-50/60 rounded-xl border border-amber-100/60 flex items-center gap-2">
                  <Coins size={14} className="text-amber-500 flex-shrink-0" />
                  <p className="text-[10px] text-amber-700 font-bold">成本設定已移至「材料與倉務 → 產品成本一覽」，在該處統一管理原材料成本、出成率、加工費等。</p>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">庫存</label>
                  <input type="number" value={editingProduct.stock} onChange={e => setEditingProduct({ ...editingProduct, stock: Number(e.target.value) })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">是否追蹤庫存</label>
                  <select value={editingProduct.trackInventory ? 'true' : 'false'} onChange={e => setEditingProduct({ ...editingProduct, trackInventory: e.target.value === 'true' })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold">
                    <option value="true">是</option>
                    <option value="false">否</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">限購數量</label>
                  <input
                    type="number"
                    min="1"
                    step="1"
                    value={editingProduct.purchaseLimit ?? ''}
                    onChange={e => setEditingProduct({ ...editingProduct, purchaseLimit: e.target.value ? Math.max(1, parseInt(e.target.value, 10)) : undefined })}
                    placeholder="留空 = 不限購"
                    className="w-full p-3 bg-slate-50 rounded-2xl font-bold"
                  />
                  <p className="text-[9px] text-slate-400 font-bold">每位客人每單最多購買數量。留空代表不限。</p>
                </div>
                <div className="space-y-2 md:col-span-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">產品分類</label>
                  <div className="flex flex-wrap gap-2">
                    {categories.map(cat => {
                      const isSelected = editingProduct.categories.includes(cat.id);
                      return (
                        <button key={cat.id} type="button" onClick={() => {
                          const next = isSelected
                            ? editingProduct.categories.filter(c => c !== cat.id)
                            : [...editingProduct.categories, cat.id];
                          setEditingProduct({ ...editingProduct, categories: next });
                        }} className={`px-3 py-1.5 rounded-xl text-xs font-black border transition-all ${isSelected ? 'bg-blue-600 text-white border-blue-600 shadow-md' : 'bg-slate-50 text-slate-500 border-slate-200 hover:border-blue-300'}`}>
                          {cat.icon} {cat.name}
                        </button>
                      );
                    })}
                    <button type="button" onClick={() => {
                      const newName = prompt('輸入新分類名稱：');
                      if (!newName?.trim()) return;
                      const newId = newName.trim().toLowerCase().replace(/\s+/g, '-');
                      if (categories.find(c => c.id === newId)) {
                        if (!editingProduct.categories.includes(newId)) setEditingProduct({ ...editingProduct, categories: [...editingProduct.categories, newId] });
                        return;
                      }
                      const newCat = { id: newId, name: newName.trim(), icon: '📦' };
                      upsertCategory(newCat);
                      setEditingProduct({ ...editingProduct, categories: [...editingProduct.categories, newId] });
                    }} className="px-3 py-1.5 rounded-xl text-xs font-black border-2 border-dashed border-slate-300 text-slate-400 hover:border-blue-400 hover:text-blue-500 transition-all flex items-center gap-1">
                      <Plus size={12} /> 新增分類
                    </button>
                  </div>
                  {editingProduct.categories.length === 0 && <p className="text-[9px] text-amber-500 font-bold">尚未選擇分類</p>}
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">標籤 (逗號分隔)</label>
                  <input value={editingProduct.tags.join(',')} onChange={e => setEditingProduct({ ...editingProduct, tags: e.target.value.split(',').map(v => v.trim()).filter(Boolean) })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold" />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">產品圖片</label>
                  <div className="flex items-start gap-4">
                    <label className={`relative flex-shrink-0 w-28 h-28 rounded-2xl border-2 border-dashed ${imageUploading === `product-${editingProduct.id}` ? 'border-blue-400 bg-blue-50' : 'border-slate-200 bg-slate-50'} flex items-center justify-center cursor-pointer hover:border-blue-400 hover:bg-blue-50 transition-all overflow-hidden group`}>
                      {imageUploading === `product-${editingProduct.id}` ? (
                        <RefreshCw size={22} className="text-blue-500 animate-spin" />
                      ) : isMediaUrl(editingProduct.image) ? (
                        <img src={editingProduct.image} alt="" className="w-full h-full object-cover" />
                      ) : editingProduct.image ? (
                        <span className="text-4xl">{editingProduct.image}</span>
                      ) : (
                        <div className="text-center"><Upload size={20} className="mx-auto text-slate-300 mb-1" /><span className="text-[9px] text-slate-400 font-bold">上傳圖片</span></div>
                      )}
                      {isMediaUrl(editingProduct.image) && <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center"><Upload size={18} className="text-white" /></div>}
                      <input type="file" accept="image/*" className="hidden" onChange={e => handleImageUpload(e.target.files, `products/${editingProduct.id}`, async ([url]) => { if (isMediaUrl(editingProduct.image)) await deleteImage(editingProduct.image); setEditingProduct({ ...editingProduct, image: url }); }, { uploadKey: `product-${editingProduct.id}` })} />
                    </label>
                    <div className="flex-1 space-y-2">
                      <input value={editingProduct.image} onChange={e => setEditingProduct({ ...editingProduct, image: e.target.value })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold text-xs" placeholder="或貼上圖片 URL / Emoji" />
                      <p className="text-[9px] text-slate-400 font-bold">點擊左方上傳圖片，或直接輸入 URL / Emoji</p>
                    </div>
                  </div>
                </div>
                {/* ── SEO 圖片 & 搜尋引擎優化 ── */}
                <div className="space-y-3 md:col-span-2 p-4 bg-gradient-to-r from-emerald-50/60 to-blue-50/60 rounded-2xl border border-emerald-100/60">
                  <div className="flex items-center gap-2 mb-1">
                    <Search size={14} className="text-emerald-600" />
                    <label className="text-[10px] font-bold text-emerald-700 uppercase tracking-widest">Google SEO 優化</label>
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <label className="text-[9px] font-bold text-slate-500 ml-1">圖片 Alt 文字 <span className="text-slate-300">（Google 圖片搜尋用）</span></label>
                      <button type="button" disabled={aiFieldLoading === 'image-alt'} onClick={() => generateProductField('image-alt', (text) => setEditingProduct(prev => prev ? { ...prev, imageAlt: text } : prev))} className="flex items-center gap-1 px-2 py-0.5 bg-purple-50 text-purple-600 rounded-lg text-[8px] font-black hover:bg-purple-100 transition-all disabled:opacity-50">
                        {aiFieldLoading === 'image-alt' ? <RefreshCw size={8} className="animate-spin" /> : <Sparkles size={8} />} AI
                      </button>
                    </div>
                    <input value={editingProduct.imageAlt || ''} onChange={e => setEditingProduct({ ...editingProduct, imageAlt: e.target.value })} className="w-full p-2.5 bg-white rounded-xl font-bold text-xs border border-slate-100" placeholder={`例：${editingProduct.name || '澳洲M5和牛肉眼'} - 急凍真空包裝`} />
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <label className="text-[9px] font-bold text-slate-500 ml-1">SEO 標題 <span className="text-slate-300">（留空則用產品名稱）</span></label>
                      <button type="button" disabled={aiFieldLoading === 'seo-title'} onClick={() => generateProductField('seo-title', (text) => setEditingProduct(prev => prev ? { ...prev, seoTitle: text } : prev))} className="flex items-center gap-1 px-2 py-0.5 bg-purple-50 text-purple-600 rounded-lg text-[8px] font-black hover:bg-purple-100 transition-all disabled:opacity-50">
                        {aiFieldLoading === 'seo-title' ? <RefreshCw size={8} className="animate-spin" /> : <Sparkles size={8} />} AI
                      </button>
                    </div>
                    <input value={editingProduct.seoTitle || ''} onChange={e => setEditingProduct({ ...editingProduct, seoTitle: e.target.value })} className="w-full p-2.5 bg-white rounded-xl font-bold text-xs border border-slate-100" placeholder={`例：${editingProduct.name || '澳洲M5和牛肉眼'} | 香港急凍肉網購`} />
                    {(editingProduct.seoTitle || '').length > 0 && <p className={`text-[8px] font-bold ml-1 ${(editingProduct.seoTitle || '').length > 60 ? 'text-red-500' : 'text-slate-300'}`}>{(editingProduct.seoTitle || '').length}/60 字元{(editingProduct.seoTitle || '').length > 60 ? ' ⚠️ 太長，Google 會截斷' : ''}</p>}
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <label className="text-[9px] font-bold text-slate-500 ml-1">SEO 描述 <span className="text-slate-300">（建議 50-160 字元）</span></label>
                      <button type="button" disabled={aiFieldLoading === 'seo-description'} onClick={() => generateProductField('seo-description', (text) => setEditingProduct(prev => prev ? { ...prev, seoDescription: text } : prev))} className="flex items-center gap-1 px-2 py-0.5 bg-purple-50 text-purple-600 rounded-lg text-[8px] font-black hover:bg-purple-100 transition-all disabled:opacity-50">
                        {aiFieldLoading === 'seo-description' ? <RefreshCw size={8} className="animate-spin" /> : <Sparkles size={8} />} AI
                      </button>
                    </div>
                    <textarea value={editingProduct.seoDescription || ''} onChange={e => setEditingProduct({ ...editingProduct, seoDescription: e.target.value })} className="w-full p-2.5 bg-white rounded-xl font-bold text-xs border border-slate-100 min-h-[60px]" placeholder={`例：新鮮急凍${editingProduct.name || '澳洲M5和牛肉眼'}，順豐冷鏈配送，真空包裝保持鮮度。`} />
                    {(editingProduct.seoDescription || '').length > 0 && <p className={`text-[8px] font-bold ml-1 ${(editingProduct.seoDescription || '').length > 160 ? 'text-red-500' : (editingProduct.seoDescription || '').length < 50 ? 'text-amber-500' : 'text-emerald-500'}`}>{(editingProduct.seoDescription || '').length}/160 字元{(editingProduct.seoDescription || '').length > 160 ? ' ⚠️ 太長' : (editingProduct.seoDescription || '').length < 50 ? ' ⚠️ 太短，建議 50+ 字元' : ' ✓ 長度適中'}</p>}
                  </div>
                  <p className="text-[8px] text-slate-400 font-bold leading-relaxed">以上欄位有助你的產品在 Google 搜尋及 Google 圖片搜尋排名更高。填寫時以客人會搜尋的關鍵字為主。</p>
                </div>
                {/* ── 產品相簿 (Gallery) ── */}
                <div className="space-y-2 md:col-span-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">產品相簿（最多 10 張）</label>
                  <div className="flex gap-2 flex-wrap">
                    {(editingProduct.gallery || []).map((url, idx) => (
                      <div key={idx} className="relative w-20 h-20 rounded-xl overflow-hidden border border-slate-100 group">
                        <img src={url} alt="" className="w-full h-full object-cover" />
                        <button type="button" onClick={async () => {
                          await deleteImage(url);
                          setEditingProduct({ ...editingProduct, gallery: (editingProduct.gallery || []).filter((_, i) => i !== idx) });
                        }} className="absolute top-0.5 right-0.5 w-5 h-5 bg-black/60 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"><X size={10} className="text-white" /></button>
                      </div>
                    ))}
                    {(editingProduct.gallery || []).length < 10 && (
                      <label className={`w-20 h-20 rounded-xl border-2 border-dashed ${imageUploading === `gallery-${editingProduct.id}` ? 'border-blue-400 bg-blue-50' : 'border-slate-200 bg-slate-50'} flex items-center justify-center cursor-pointer hover:border-blue-400 hover:bg-blue-50 transition-all`}>
                        {imageUploading === `gallery-${editingProduct.id}` ? <RefreshCw size={16} className="text-blue-500 animate-spin" /> : <Plus size={18} className="text-slate-300" />}
                        <input type="file" accept="image/*" multiple className="hidden" onChange={e => handleImageUpload(e.target.files, `products/${editingProduct.id}/gallery`, (urls) => {
                          const current = editingProduct.gallery || [];
                          const merged = [...current, ...urls].slice(0, 10);
                          setEditingProduct({ ...editingProduct, gallery: merged });
                        }, { multi: true, uploadKey: `gallery-${editingProduct.id}` })} />
                      </label>
                    )}
                  </div>
                  {(editingProduct.gallery || []).length > 0 && <p className="text-[9px] text-slate-400 font-bold">{(editingProduct.gallery || []).length}/10 張 · 懸浮圖片可刪除</p>}
                </div>
                <div className="space-y-2 md:col-span-2">
                  <div className="flex items-center justify-between">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">商品描述</label>
                    <button type="button" disabled={aiDescLoading} onClick={() => {
                      if (!editingProduct.name.trim()) { showToast('填寫產品名稱讓 AI 可以跟據名稱作出描述', 'error'); return; }
                      setAiPromptModal({
                        title: 'AI 寫描述',
                        placeholder: '例如：語氣輕鬆一點、強調適合氣炸鍋...',
                        onConfirm: async (instruction) => {
                          setAiDescLoading(true);
                          try {
                            const res = await fetch('/api/generate-recipe', {
                              method: 'POST', headers: buildAdminHeaders(adminUser),
                              body: JSON.stringify({ action: 'single-product-desc', payload: { productName: editingProduct.name, userInstruction: instruction || undefined } }),
                            });
                            const json = await res.json();
                            if (!json.ok) throw new Error(json.error || 'AI error');
                            const text = json.data.description || '';
                            if (text) { setEditingProduct(prev => prev ? { ...prev, description: text } : prev); showToast('AI 已生成描述'); }
                            else showToast('AI 無法生成描述', 'error');
                          } catch { showToast('AI 生成失敗，請稍後重試', 'error'); }
                          setAiDescLoading(false);
                        },
                      });
                    }} className="flex items-center gap-1 px-2.5 py-1 bg-purple-50 text-purple-600 rounded-lg text-[9px] font-black hover:bg-purple-100 transition-all disabled:opacity-50">
                      {aiDescLoading ? <RefreshCw size={10} className="animate-spin" /> : <Sparkles size={10} />}
                      AI 寫描述
                    </button>
                  </div>
                  <textarea value={editingProduct.description || ''} onChange={e => setEditingProduct({ ...editingProduct, description: e.target.value })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold min-h-[100px]" />
                </div>
                {/* ── English Translation ── */}
                <div className="space-y-3 md:col-span-2 p-4 bg-gradient-to-r from-blue-50/60 to-indigo-50/60 rounded-2xl border border-blue-100/60">
                  <div className="flex items-center gap-2 mb-1">
                    <Globe size={14} className="text-blue-600" />
                    <label className="text-[10px] font-bold text-blue-700 uppercase tracking-widest">English Translation</label>
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <label className="text-[9px] font-bold text-slate-500 ml-1">Product Name (EN)</label>
                      <button type="button" disabled={aiFieldLoading === 'name-en'} onClick={() => generateProductField('name-en', (text) => setEditingProduct(prev => prev ? { ...prev, nameEn: text } : prev))} className="flex items-center gap-1 px-2 py-0.5 bg-purple-50 text-purple-600 rounded-lg text-[8px] font-black hover:bg-purple-100 transition-all disabled:opacity-50">
                        {aiFieldLoading === 'name-en' ? <RefreshCw size={8} className="animate-spin" /> : <Sparkles size={8} />} AI
                      </button>
                    </div>
                    <input value={editingProduct.nameEn || ''} onChange={e => setEditingProduct({ ...editingProduct, nameEn: e.target.value })} className="w-full p-2.5 bg-white rounded-xl font-bold text-xs border border-slate-100" placeholder={`e.g. Australian M5 Wagyu Ribeye`} />
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <label className="text-[9px] font-bold text-slate-500 ml-1">Description (EN)</label>
                      <button type="button" disabled={aiFieldLoading === 'desc-en'} onClick={() => generateProductField('desc-en', (text) => setEditingProduct(prev => prev ? { ...prev, descriptionEn: text } : prev))} className="flex items-center gap-1 px-2 py-0.5 bg-purple-50 text-purple-600 rounded-lg text-[8px] font-black hover:bg-purple-100 transition-all disabled:opacity-50">
                        {aiFieldLoading === 'desc-en' ? <RefreshCw size={8} className="animate-spin" /> : <Sparkles size={8} />} AI
                      </button>
                    </div>
                    <textarea value={editingProduct.descriptionEn || ''} onChange={e => setEditingProduct({ ...editingProduct, descriptionEn: e.target.value })} className="w-full p-2.5 bg-white rounded-xl font-bold text-xs border border-slate-100 min-h-[60px]" placeholder="English product description" />
                  </div>
                  <p className="text-[8px] text-slate-400 font-bold leading-relaxed">When the customer switches language to English, these will be displayed instead of the Chinese name/description.</p>
                </div>
              </div>
            </div>
            <div className="p-8 bg-slate-50 border-t border-slate-100 flex justify-end gap-3">
              <button onClick={() => setEditingProduct(null)} className="px-6 py-3 bg-white border border-slate-200 rounded-2xl font-black text-xs">取消</button>
              <button onClick={() => {
                const group = editingProduct.groupId ? productGroups.find(g => g.id === editingProduct.groupId) : null;
                const autoLabel = deriveVariantLabel(editingProduct.processingTypeId, editingProduct.pricingMode, editingProduct.packSize, group?.classification);
                const finalLabel = autoLabel || editingProduct.variantLabel || '';
                const finalName = group ? `${group.name} ${finalLabel}`.trim() : editingProduct.name;
                const toSave = { ...editingProduct, variantLabel: finalLabel, name: finalName };
                if (!toSave.name.trim()) { showToast('請輸入產品名稱', 'error'); return; }
                upsertProduct(toSave);
                setEditingProduct(null);
              }} className="px-6 py-3 bg-slate-900 text-white rounded-2xl font-black text-xs">保存</button>
            </div>
          </div>
        </div>
      )}

      {/* ── New Product Wizard (classification picker + multi-spec setup) ── */}
      {newProductWizard && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[6000] flex items-center justify-center p-6 animate-fade-in">
          <div className="bg-white w-full max-w-3xl rounded-[3rem] shadow-2xl overflow-hidden flex flex-col max-h-[90vh] animate-scale-up">
            <div className="p-8 border-b border-slate-50 flex justify-between items-center bg-slate-900 text-white">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center"><Plus size={22}/></div>
                <div>
                  <h4 className="text-2xl font-black tracking-tight">新增產品</h4>
                  <p className="text-[10px] font-bold text-white/40 uppercase tracking-[0.2em]">產品 → 規格 (可多款)</p>
                </div>
              </div>
              <button onClick={() => setNewProductWizard(null)} className="p-3 bg-white/10 rounded-full hover:bg-white/20 transition-all text-white"><X size={20}/></button>
            </div>
            <div className="flex-1 overflow-y-auto p-8 space-y-6">
              {/* Step 1: Classification */}
              <div className="grid grid-cols-3 gap-4">
                {([
                  { key: 'raw_material' as ProductClassification, icon: '🥩', label: '原材料', desc: '肉類、海鮮等，可設定加工方式' },
                  { key: 'third_party' as ProductClassification, icon: '📦', label: '第三方產品', desc: '外購品牌（如丸類），可分裝' },
                  { key: 'in_house' as ProductClassification, icon: '🏭', label: '自製產品', desc: '自家醃製、醬料等' },
                ]).map(opt => (
                  <button
                    key={opt.key}
                    onClick={() => setNewProductWizard(w => w ? { ...w, classification: opt.key, specs: [] } : w)}
                    className={`p-4 rounded-2xl border-2 text-left transition-all ${newProductWizard.classification === opt.key ? 'border-violet-500 bg-violet-50 shadow-lg shadow-violet-100' : 'border-slate-200 bg-white hover:border-violet-300'}`}
                  >
                    <div className="text-2xl mb-1">{opt.icon}</div>
                    <div className="text-sm font-black text-slate-800">{opt.label}</div>
                    <div className="text-[9px] text-slate-400 font-bold mt-0.5">{opt.desc}</div>
                  </button>
                ))}
              </div>

              {/* Step 2: Product name + raw material link */}
              {newProductWizard.classification && (
                <div className="space-y-4 p-5 bg-slate-50/80 rounded-2xl border border-slate-200">
                  <h5 className="text-xs font-black text-slate-700">產品基本資料</h5>
                  <div className="grid grid-cols-2 gap-4">
                    {newProductWizard.classification === 'raw_material' ? (
                      <div className="space-y-1 col-span-2">
                        <label className="text-[9px] font-bold text-slate-500 ml-1">選擇原材料 *（產品名稱跟隨原材料）</label>
                        <select value={newProductWizard.ingredientId} onChange={e => {
                          const ing = ingredients.find(i => i.id === e.target.value);
                          setNewProductWizard(w => w ? { ...w, ingredientId: e.target.value, productName: ing?.name || '' } : w);
                        }} className="w-full p-3 bg-white rounded-xl font-bold text-sm border border-slate-200">
                          <option value="">— 選擇原材料 —</option>
                          {ingredientCategories.map(cat => {
                            const catIngs = ingredients.filter(i => i.category === cat);
                            if (catIngs.length === 0) return null;
                            return <optgroup key={cat} label={cat}>{catIngs.map(ing => <option key={ing.id} value={ing.id}>{ing.name} (${formatMoney(ing.baseCostPerLb)}/{ing.unit})</option>)}</optgroup>;
                          })}
                          {ingredients.filter(i => !i.category).length > 0 && <optgroup label="未分類">{ingredients.filter(i => !i.category).map(ing => <option key={ing.id} value={ing.id}>{ing.name} (${formatMoney(ing.baseCostPerLb)}/{ing.unit})</option>)}</optgroup>}
                        </select>
                      </div>
                    ) : (
                      <div className="space-y-1 col-span-2">
                        <label className="text-[9px] font-bold text-slate-500 ml-1">產品名稱 *</label>
                        <input value={newProductWizard.productName} onChange={e => setNewProductWizard(w => w ? { ...w, productName: e.target.value } : w)} className="w-full p-3 bg-white rounded-xl font-bold text-sm border border-slate-200" placeholder={newProductWizard.classification === 'third_party' ? '例：四海牛丸' : '例：秘製醃豬扒'} />
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Step 3: Add specs */}
              {newProductWizard.classification && (newProductWizard.ingredientId || newProductWizard.productName) && (
                <div className="space-y-4 p-5 bg-violet-50/50 rounded-2xl border border-violet-200">
                  <div className="flex items-center justify-between">
                    <h5 className="text-xs font-black text-violet-700">規格列表</h5>
                    <button onClick={() => setNewProductWizard(w => w ? { ...w, specs: [...w.specs, { pricingMode: 'fixed_pack', packSize: '', price: 0 }] } : w)} className="flex items-center gap-1 px-3 py-1.5 bg-violet-600 text-white rounded-xl text-[10px] font-black hover:bg-violet-700">
                      <Plus size={12}/> 新增規格
                    </button>
                  </div>

                  {newProductWizard.specs.length === 0 && (
                    <p className="text-center text-slate-400 text-xs font-bold py-4">請點擊「新增規格」添加至少一款規格（如原件抄碼、切絲、切粒…）</p>
                  )}

                  {newProductWizard.specs.map((spec, si) => (
                    <div key={si} className="bg-white rounded-xl p-4 border border-violet-100 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-black text-violet-600">規格 #{si + 1}</span>
                        <button onClick={() => setNewProductWizard(w => w ? { ...w, specs: w.specs.filter((_, i) => i !== si) } : w)} className="p-1 text-rose-400 hover:text-rose-600"><Trash2 size={12}/></button>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <label className="text-[8px] font-bold text-slate-400 ml-0.5">規格名稱（自動）</label>
                          <div className="w-full p-2.5 bg-violet-50 rounded-lg font-bold text-xs border border-violet-200 text-violet-700 min-h-[36px] flex items-center">
                            {deriveVariantLabel(spec.processingTypeId, spec.pricingMode, spec.packSize, newProductWizard.classification ?? undefined) || <span className="text-slate-300">選擇加工方式及包裝後自動產生</span>}
                          </div>
                        </div>
                        <div className="space-y-1">
                          <label className="text-[8px] font-bold text-slate-400 ml-0.5">計價方式</label>
                          <div className="flex gap-1">
                            <button onClick={() => {
                              const next = [...newProductWizard.specs]; next[si] = { ...next[si], pricingMode: 'fixed_pack' };
                              setNewProductWizard(w => w ? { ...w, specs: next } : w);
                            }} className={`flex-1 p-2 rounded-lg text-[10px] font-black border transition-all ${spec.pricingMode === 'fixed_pack' ? 'border-violet-500 bg-violet-100 text-violet-700' : 'border-slate-200 bg-white text-slate-500'}`}>📦 定裝</button>
                            <button onClick={() => {
                              const next = [...newProductWizard.specs]; next[si] = { ...next[si], pricingMode: 'by_piece' };
                              setNewProductWizard(w => w ? { ...w, specs: next } : w);
                            }} className={`flex-1 p-2 rounded-lg text-[10px] font-black border transition-all ${spec.pricingMode === 'by_piece' ? 'border-pink-500 bg-pink-100 text-pink-700' : 'border-slate-200 bg-white text-slate-500'}`}>🏷️ 抄碼</button>
                          </div>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        {newProductWizard.classification === 'raw_material' && (
                          <div className="space-y-1">
                            <label className="text-[8px] font-bold text-slate-400 ml-0.5">加工方式</label>
                            <select value={spec.processingTypeId || ''} onChange={e => {
                              const ptId = e.target.value || undefined;
                              const next = [...newProductWizard.specs];
                              next[si] = { ...next[si], processingTypeId: ptId };
                              setNewProductWizard(w => w ? { ...w, specs: next } : w);
                            }} className="w-full p-2 bg-slate-50 rounded-lg font-bold text-xs border border-slate-100">
                              <option value="">原件（不加工）</option>
                              {processingTypes.filter(pt => pt.code !== 'whole').map(pt => (
                                <option key={pt.id} value={pt.id}>{pt.name}{pt.spec ? ` (${pt.spec})` : ''}</option>
                              ))}
                            </select>
                          </div>
                        )}
                        <div className="space-y-1">
                          <label className="text-[8px] font-bold text-slate-400 ml-0.5">包裝規格</label>
                          <select value={spec.packSize || ''} onChange={e => {
                            const val = e.target.value;
                            const weightMap: Record<string, number> = { '1磅/包': 1, '2磅/包': 2, '5磅/包': 5, '10磅/箱': 10, '300g/包': 0.66, '500g/包': 1.1, '1kg/包': 2.2, '5kg/包': 11 };
                            const next = [...newProductWizard.specs]; next[si] = { ...next[si], packSize: val, packWeightLb: weightMap[val] ?? next[si].packWeightLb };
                            setNewProductWizard(w => w ? { ...w, specs: next } : w);
                          }} className="w-full p-2 bg-slate-50 rounded-lg font-bold text-xs border border-slate-100">
                            <option value="">— 選擇 —</option>
                            <option value="1磅/包">1磅/包</option>
                            <option value="2磅/包">2磅/包</option>
                            <option value="5磅/包">5磅/包</option>
                            <option value="10磅/箱">10磅/箱</option>
                            <option value="300g/包">300g/包</option>
                            <option value="500g/包">500g/包</option>
                            <option value="1kg/包">1kg/包</option>
                            <option value="5kg/包">5kg/包</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="p-8 bg-slate-50 border-t border-slate-100 flex justify-end gap-3">
              <button onClick={() => setNewProductWizard(null)} className="px-6 py-3 bg-white border border-slate-200 rounded-2xl font-black text-xs">取消</button>
              <button
                disabled={
                  !newProductWizard.classification ||
                  (newProductWizard.classification === 'raw_material' && !newProductWizard.ingredientId) ||
                  (newProductWizard.classification !== 'raw_material' && !newProductWizard.productName.trim()) ||
                  newProductWizard.specs.length === 0
                }
                onClick={async () => {
                  const wiz = newProductWizard;
                  if (!wiz.classification || wiz.specs.length === 0) return;

                  let groupName = '';
                  let ingId: string | undefined;
                  let parentIngId: string | undefined;
                  let prodType: ProductType = 'standalone';

                  if (wiz.classification === 'raw_material') {
                    const ing = ingredients.find(i => i.id === wiz.ingredientId);
                    if (!ing) return;
                    groupName = ing.name;
                    ingId = ing.id;
                    parentIngId = ing.id;
                    prodType = 'raw_material';
                  } else if (wiz.classification === 'third_party') {
                    groupName = wiz.productName;
                    prodType = 'third_party';
                  } else {
                    groupName = wiz.productName;
                    prodType = 'in_house';
                  }

                  const newGroup: ProductGroup = {
                    id: crypto.randomUUID(),
                    name: groupName,
                    classification: wiz.classification,
                    ingredientId: ingId,
                    isActive: true,
                  };
                  const savedGroup = await upsertProductGroup(newGroup);
                  if (!savedGroup) return;

                  const newProducts: Product[] = wiz.specs.map((spec, i) => {
                    const autoLabel = deriveVariantLabel(spec.processingTypeId, spec.pricingMode, spec.packSize, wiz.classification ?? undefined);
                    return {
                    id: 'P-' + Date.now() + '-' + i,
                    name: `${groupName} ${autoLabel}`.trim(),
                    categories: [],
                    price: 0,
                    memberPrice: 0,
                    stock: 0,
                    trackInventory: true,
                    tags: [],
                    image: wiz.classification === 'raw_material' ? '🥩' : wiz.classification === 'in_house' ? '🏭' : '📦',
                    saleChannel: 'wholesale' as SaleChannel,
                    productType: prodType,
                    groupId: savedGroup.id,
                    parentIngredientId: parentIngId,
                    ingredientId: ingId,
                    variantLabel: autoLabel,
                    pricingMode: spec.pricingMode,
                    processingTypeId: spec.processingTypeId,
                    processingSpec: spec.processingSpec,
                    packSize: spec.packSize || undefined,
                    packWeightLb: spec.packWeightLb,
                  }; });

                  const success = await upsertProducts(newProducts);
                  if (success) {
                    setNewProductWizard(null);
                    setExpandedGroupIds(prev => new Set([...prev, savedGroup.id]));
                    showToast(`已建立「${groupName}」及 ${newProducts.length} 款規格`);
                  }
                }}
                className="px-6 py-3 bg-violet-600 text-white rounded-2xl font-black text-xs disabled:opacity-30 transition-all hover:bg-violet-700 flex items-center gap-2"
              >
                建立產品及規格 ({newProductWizard.specs.length} 款)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── Ingredient Category Edit Modal ── */}
      {editingIngredientCategory && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[6000] flex items-center justify-center p-6 animate-fade-in">
          <div className="bg-white w-full max-w-md rounded-[3rem] shadow-2xl overflow-hidden flex flex-col animate-scale-up">
            <div className="p-8 border-b border-slate-50 flex justify-between items-center bg-violet-900 text-white">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center text-2xl">{editingIngredientCategory.emoji || '📦'}</div>
                <div>
                  <h4 className="text-2xl font-black tracking-tight">{editingIngredientCategory.name || '新增類別'}</h4>
                  <p className="text-[10px] font-bold text-white/40 uppercase tracking-[0.2em]">原材料類別</p>
                </div>
              </div>
              <button onClick={() => setEditingIngredientCategory(null)} className="p-3 bg-white/10 rounded-full hover:bg-white/20 transition-all text-white"><X size={20}/></button>
            </div>
            <div className="p-8 space-y-4">
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">類別名稱 *</label>
                <input
                  value={editingIngredientCategory.name}
                  onChange={e => setEditingIngredientCategory({ ...editingIngredientCategory, name: e.target.value })}
                  className="w-full p-3 bg-slate-50 rounded-2xl font-bold text-sm border border-slate-100"
                  placeholder="例：牛肉、海鮮、調味料..."
                  autoFocus
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Emoji 圖示</label>
                <input
                  value={editingIngredientCategory.emoji}
                  onChange={e => setEditingIngredientCategory({ ...editingIngredientCategory, emoji: e.target.value })}
                  className="w-full p-3 bg-slate-50 rounded-2xl font-bold text-sm border border-slate-100"
                  placeholder="例：🐄 🐷 🦞"
                />
              </div>
            </div>
            <div className="p-8 bg-slate-50 border-t border-slate-100 flex justify-end gap-3">
              <button onClick={() => setEditingIngredientCategory(null)} className="px-6 py-3 bg-white border border-slate-200 rounded-2xl font-black text-xs">取消</button>
              <button onClick={() => {
                if (!editingIngredientCategory.name.trim()) { showToast('請輸入類別名稱', 'error'); return; }
                upsertIngredientCategory(editingIngredientCategory);
              }} className="px-6 py-3 bg-violet-700 text-white rounded-2xl font-black text-xs active:scale-95 transition-all">保存</button>
            </div>
          </div>
        </div>
      )}

      {editingCategory && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[6000] flex items-center justify-center p-6 animate-fade-in">
          <div className="bg-white w-full max-w-xl rounded-[3rem] shadow-2xl overflow-hidden flex flex-col max-h-[90vh] animate-scale-up">
            <div className="p-8 border-b border-slate-50 flex justify-between items-center bg-slate-900 text-white">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center"><List size={20}/></div>
                <div>
                  <h4 className="text-2xl font-black tracking-tight">編輯分類</h4>
                  <p className="text-[10px] font-bold text-white/40 uppercase tracking-[0.2em]">{editingCategory.id}</p>
                </div>
              </div>
              <button onClick={() => setEditingCategory(null)} className="p-3 bg-white/10 rounded-full hover:bg-white/20 transition-all text-white"><X size={20}/></button>
            </div>
            <div className="p-10 space-y-4">
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">分類 ID</label>
                <input value={editingCategory.id} onChange={e => setEditingCategory({ ...editingCategory, id: e.target.value })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold" />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">分類名稱</label>
                <input value={editingCategory.name} onChange={e => setEditingCategory({ ...editingCategory, name: e.target.value })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold" />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">圖示</label>
                <input value={editingCategory.icon} onChange={e => setEditingCategory({ ...editingCategory, icon: e.target.value })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold" />
              </div>
            </div>
            <div className="p-8 bg-slate-50 border-t border-slate-100 flex justify-end gap-3">
              <button onClick={() => setEditingCategory(null)} className="px-6 py-3 bg-white border border-slate-200 rounded-2xl font-black text-xs">取消</button>
              <button onClick={() => {
                if (!editingCategory.name.trim()) { showToast('請輸入分類名稱', 'error'); return; }
                upsertCategory(editingCategory);
                setEditingCategory(null);
              }} className="px-6 py-3 bg-slate-900 text-white rounded-2xl font-black text-xs">保存</button>
            </div>
          </div>
        </div>
      )}

      {editingSlideshow && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[6000] flex items-center justify-center p-6 animate-fade-in">
          <div className="bg-white w-full max-w-xl rounded-[3rem] shadow-2xl overflow-hidden flex flex-col max-h-[90vh] animate-scale-up">
            <div className="p-8 border-b border-slate-50 flex justify-between items-center bg-slate-900 text-white">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center"><ImageIcon size={20}/></div>
                <div>
                  <h4 className="text-2xl font-black tracking-tight">編輯廣告</h4>
                  <p className="text-[10px] font-bold text-white/40 uppercase tracking-[0.2em]">{editingSlideshow.id}</p>
                </div>
              </div>
              <button onClick={() => setEditingSlideshow(null)} className="p-3 bg-white/10 rounded-full hover:bg-white/20 transition-all text-white"><X size={20}/></button>
            </div>
            <div className="p-10 space-y-4">
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">類型</label>
                <select value={editingSlideshow.type} onChange={e => setEditingSlideshow({ ...editingSlideshow, type: e.target.value as 'image' | 'video' })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold">
                  <option value="image">圖片</option>
                  <option value="video">影片</option>
                </select>
              </div>
              {editingSlideshow.type === 'image' ? (
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">廣告圖片</label>
                  <label className={`relative block w-full aspect-[2.5/1] rounded-2xl border-2 border-dashed ${imageUploading === `slide-${editingSlideshow.id}` ? 'border-blue-400 bg-blue-50' : 'border-slate-200 bg-slate-50'} flex items-center justify-center cursor-pointer hover:border-blue-400 hover:bg-blue-50 transition-all overflow-hidden group`}>
                    {imageUploading === `slide-${editingSlideshow.id}` ? (
                      <div className="flex flex-col items-center gap-2"><RefreshCw size={24} className="text-blue-500 animate-spin" /><span className="text-xs text-blue-500 font-bold">上傳中...</span></div>
                    ) : isMediaUrl(editingSlideshow.url) ? (
                      <>
                        <img src={editingSlideshow.url} alt="" className="w-full h-full object-cover" />
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2"><Upload size={20} className="text-white" /><span className="text-white font-bold text-sm">更換圖片</span></div>
                      </>
                    ) : (
                      <div className="flex flex-col items-center gap-2 text-slate-300"><Upload size={28} /><span className="text-xs font-bold">點擊上傳廣告圖片</span></div>
                    )}
                    <input type="file" accept="image/*" className="hidden" onChange={e => handleImageUpload(e.target.files, `slideshow/${editingSlideshow.id}`, async ([url]) => { if (isMediaUrl(editingSlideshow.url)) await deleteImage(editingSlideshow.url); setEditingSlideshow({ ...editingSlideshow, url }); }, { uploadKey: `slide-${editingSlideshow.id}` })} />
                  </label>
                  <input value={editingSlideshow.url} onChange={e => setEditingSlideshow({ ...editingSlideshow, url: e.target.value })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold text-xs" placeholder="或貼上圖片 URL" />
                </div>
              ) : (
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">影片連結 URL</label>
                  <input value={editingSlideshow.url} onChange={e => setEditingSlideshow({ ...editingSlideshow, url: e.target.value })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold" placeholder="https://..." />
                  {editingSlideshow.url && <video src={editingSlideshow.url} className="w-full aspect-[2.5/1] rounded-xl object-cover bg-slate-100 mt-2" muted controls />}
                </div>
              )}
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">標題（選填）</label>
                <input value={editingSlideshow.title || ''} onChange={e => setEditingSlideshow({ ...editingSlideshow, title: e.target.value || undefined })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold" placeholder="廣告標題" />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">順序 (數字越小越前)</label>
                <input type="number" value={editingSlideshow.sortOrder} onChange={e => setEditingSlideshow({ ...editingSlideshow, sortOrder: Number(e.target.value) || 0 })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold" />
              </div>
            </div>
            <div className="p-8 bg-slate-50 border-t border-slate-100 flex justify-end gap-3">
              <button onClick={() => setEditingSlideshow(null)} className="px-6 py-3 bg-white border border-slate-200 rounded-2xl font-black text-xs">取消</button>
              <button onClick={() => {
                if (!editingSlideshow.url.trim()) { showToast('請輸入連結', 'error'); return; }
                upsertSlideshowItem(editingSlideshow);
                setEditingSlideshow(null);
              }} className="px-6 py-3 bg-slate-900 text-white rounded-2xl font-black text-xs">保存</button>
            </div>
          </div>
        </div>
      )}

      {addressEditor && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[6000] flex items-center justify-center p-6 animate-fade-in">
          <div className="bg-white w-full max-w-xl rounded-[3rem] shadow-2xl overflow-hidden flex flex-col max-h-[90vh] animate-scale-up">
            <div className="p-8 border-b border-slate-50 flex justify-between items-center bg-slate-900 text-white">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center"><MapPin size={20}/></div>
                <div>
                  <h4 className="text-2xl font-black tracking-tight">{addressEditor.isNew ? '新增地址' : '編輯地址'}</h4>
                  <p className="text-[10px] font-bold text-white/40 uppercase tracking-[0.2em]">{addressEditor.address.id}</p>
                </div>
              </div>
              <button onClick={() => setAddressEditor(null)} className="p-3 bg-white/10 rounded-full hover:bg-white/20 transition-all text-white"><X size={20}/></button>
            </div>
            <div className="p-10 space-y-4">
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">地區 *</label>
                <select value={addressEditor.address.district ?? ''} onChange={e => setAddressEditor({ ...addressEditor, address: { ...addressEditor.address, district: e.target.value } })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold">
                  <option value="">請選擇地區</option>
                  {HK_DISTRICTS.map(d => <option key={d} value={d}>{d}</option>)}
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">地址 *</label>
                <input value={addressEditor.address.detail ?? ''} onChange={e => setAddressEditor({ ...addressEditor, address: { ...addressEditor.address, detail: e.target.value } })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold" placeholder="街道／門牌／村屋等" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">樓層 *</label>
                  <input value={addressEditor.address.floor ?? ''} onChange={e => setAddressEditor({ ...addressEditor, address: { ...addressEditor.address, floor: e.target.value } })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold" placeholder="如：3" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">室／單位 *</label>
                  <input value={addressEditor.address.flat ?? ''} onChange={e => setAddressEditor({ ...addressEditor, address: { ...addressEditor.address, flat: e.target.value } })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold" placeholder="如：B" />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">收件人名稱 *</label>
                  <input value={addressEditor.address.contactName} onChange={e => setAddressEditor({ ...addressEditor, address: { ...addressEditor.address, contactName: e.target.value } })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">手機號碼 *</label>
                  <input type="tel" value={addressEditor.address.phone} onChange={e => setAddressEditor({ ...addressEditor, address: { ...addressEditor.address, phone: e.target.value } })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold" />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">後備收件人</label>
                  <input value={addressEditor.address.altContactName ?? ''} onChange={e => setAddressEditor({ ...addressEditor, address: { ...addressEditor.address, altContactName: e.target.value } })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">後備收件人手機號碼</label>
                  <input type="tel" value={addressEditor.address.altPhone ?? ''} onChange={e => setAddressEditor({ ...addressEditor, address: { ...addressEditor.address, altPhone: e.target.value } })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold" />
                </div>
              </div>
              <label className="flex items-center gap-2 text-xs font-bold text-slate-500">
                <input type="checkbox" checked={addressEditor.address.isDefault} onChange={e => setAddressEditor({ ...addressEditor, address: { ...addressEditor.address, isDefault: e.target.checked } })} />
                設為預設地址
              </label>
            </div>
            <div className="p-8 bg-slate-50 border-t border-slate-100 flex justify-end gap-3">
              <button onClick={() => setAddressEditor(null)} className="px-6 py-3 bg-white border border-slate-200 rounded-2xl font-black text-xs">取消</button>
              <button onClick={() => {
                if (!isAddressCompleteForOrder(addressEditor.address)) { showToast('請填寫地區、地址、樓層、單位、收件人及手機號碼', 'error'); return; }
                handleSaveAddress(addressEditor.ownerId, addressEditor.address, addressEditor.isNew);
              }} className="px-6 py-3 bg-slate-900 text-white rounded-2xl font-black text-xs">保存</button>
            </div>
          </div>
        </div>
      )}

      {editingMember && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[6000] flex items-center justify-center p-6 animate-fade-in">
             <div className="bg-white w-full max-w-4xl rounded-[4rem] shadow-2xl overflow-hidden flex flex-col max-h-[95vh] animate-scale-up">
                <div className="p-8 border-b border-slate-50 flex justify-between items-center bg-slate-900 text-white flex-shrink-0">
                   <div className="flex items-center gap-5"><div className="w-14 h-14 bg-white/10 rounded-3xl flex items-center justify-center text-white shadow-inner"><UserCheck size={28}/></div><div><h4 className="text-2xl font-black tracking-tight">調整會員帳戶</h4><p className="text-[10px] font-bold text-white/40 uppercase tracking-[0.2em]">編輯: {editingMember.id}</p></div></div>
                   <button onClick={() => { setEditingMember(null); setEditingMemberPassword(''); }} className="p-3 bg-white/10 rounded-full hover:bg-white/20 transition-all text-white"><X size={20}/></button>
                </div>
                <div className="flex-1 overflow-y-auto p-12 space-y-12 hide-scrollbar">
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                      <div className="space-y-6">
                         <div className="flex items-center gap-3 mb-2 text-blue-600 font-black uppercase tracking-widest text-xs">基本資料</div>
                         <div className="p-8 bg-slate-50 rounded-[3rem] border border-slate-100 space-y-4">
                            <div><label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">姓名</label><input value={editingMember.name} onChange={e => setEditingMember({...editingMember, name: e.target.value})} className="w-full p-3 bg-white rounded-2xl font-bold border border-slate-100" placeholder="姓名" /></div>
                            <div><label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">電話</label><input type="tel" value={editingMember.phoneNumber || ''} onChange={e => setEditingMember({...editingMember, phoneNumber: e.target.value || undefined})} className="w-full p-3 bg-white rounded-2xl font-bold border border-slate-100" placeholder="電話" /></div>
                            <div><label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">電郵（選填）</label><input type="email" value={editingMember.email ?? ''} onChange={e => setEditingMember({...editingMember, email: e.target.value || undefined})} className="w-full p-3 bg-white rounded-2xl font-bold border border-slate-100" placeholder="email@example.com" /></div>
                            <div><label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">密碼（留空不更改；新會員請填）</label><input type="password" value={editingMemberPassword} onChange={e => setEditingMemberPassword(e.target.value)} className="w-full p-3 bg-white rounded-2xl font-bold border border-slate-100" placeholder="密碼" minLength={6} /></div>
                            <div><label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">會員類別</label>
                              <div className="flex gap-2">
                                {([{ id: 'retail' as const, label: '零售', icon: '🛒' }, { id: 'wholesale' as const, label: '批發', icon: '🏭' }]).map(t => (
                                  <button key={t.id} type="button" onClick={() => setEditingMember({...editingMember, memberType: t.id, wholesalePriceTier: t.id === 'wholesale' ? (editingMember.wholesalePriceTier || 'P0') : undefined, wholesaleBrand: t.id === 'wholesale' ? (editingMember.wholesaleBrand || adminWholesaleBrand) : undefined, wholesaleStatus: t.id === 'wholesale' ? (editingMember.wholesaleStatus || 'pending') : undefined, isWholesaleActive: t.id === 'wholesale' ? (editingMember.isWholesaleActive ?? true) : undefined })} className={`flex-1 py-3 rounded-2xl text-xs font-black transition-all flex items-center justify-center gap-2 ${editingMember.memberType === t.id ? (t.id === 'wholesale' ? 'bg-orange-500 text-white shadow-lg' : 'bg-blue-500 text-white shadow-lg') : 'bg-white border border-slate-100 text-slate-500'}`}>{t.icon} {t.label}</button>
                                ))}
                              </div>
                            </div>
                            {editingMember.memberType === 'wholesale' && (
                              <div><label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">批發 P 等級</label>
                                <select value={editingMember.wholesalePriceTier || 'P0'} onChange={e => setEditingMember({...editingMember, wholesalePriceTier: e.target.value})} className="w-full p-3 bg-white rounded-2xl font-bold border border-slate-100">
                                  <option value="P0">P0（直銷價 — 默認）</option>
                                  {(siteConfig.wholesalePricingRules?.priceTiers || []).map(tier => (
                                    <option key={tier.name} value={tier.name}>{tier.name}{tier.description ? ` — ${tier.description}` : ''}</option>
                                  ))}
                                </select>
                                <p className="text-[9px] text-slate-300 font-bold mt-1">決定此批發會員看到的售價等級</p>
                              </div>
                            )}
                            {editingMember.memberType === 'wholesale' && (
                              <div><label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">批發審核狀態</label>
                                <div className="flex gap-2">
                                  {([{ id: 'pending' as const, label: '待審核', color: 'bg-amber-500' }, { id: 'approved' as const, label: '已批准', color: 'bg-emerald-500' }, { id: 'rejected' as const, label: '已拒絕', color: 'bg-red-500' }]).map(s => (
                                    <button key={s.id} type="button" onClick={() => setEditingMember({...editingMember, wholesaleStatus: s.id})} className={`flex-1 py-2.5 rounded-2xl text-xs font-black transition-all ${editingMember.wholesaleStatus === s.id ? `${s.color} text-white shadow-lg` : 'bg-white border border-slate-100 text-slate-500'}`}>{s.label}</button>
                                  ))}
                                </div>
                              </div>
                            )}
                         </div>
                      </div>
                      <div className="space-y-6">
                         <div className="flex items-center gap-3 mb-2 text-blue-600 font-black uppercase tracking-widest text-xs"><Star size={18}/> 積分管理</div>
                         <div className="p-8 bg-slate-50 rounded-[3rem] border border-slate-100 space-y-6">
                            <div className="text-center"><p className="text-[9px] font-bold text-slate-300 uppercase tracking-widest">當前積分</p><p className="text-4xl font-black text-slate-900">{editingMember.points} pts</p></div>
                            <div className="grid grid-cols-3 gap-2">
                               {[50, 100, -50].map(val => (
                                  <button key={val} onClick={() => { setEditingMember({...editingMember, points: Math.max(0, editingMember.points + val)}); }} className="py-3 bg-white border border-slate-100 rounded-2xl font-black text-xs uppercase shadow-sm">{val > 0 ? `+${val}` : val}</button>
                               ))}
                            </div>
                         </div>
                         {editingMember.memberType === 'wholesale' && (
                           <div className="space-y-3">
                             <div className="flex items-center gap-3 mb-2 text-orange-500 font-black uppercase tracking-widest text-xs">批發開戶資料</div>
                             <div className="p-6 bg-orange-50 rounded-[3rem] border border-orange-100 space-y-4">
                               <div><label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">餐廳/公司</label><input value={editingMember.companyName || ''} onChange={e => setEditingMember({...editingMember, companyName: e.target.value || undefined})} className="w-full p-3 bg-white rounded-2xl font-bold border border-slate-100 text-sm" placeholder="餐廳/公司名稱" /></div>
                               <div className="grid grid-cols-2 gap-3">
                                 <div><label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">業務類型</label><input value={editingMember.businessType || ''} onChange={e => setEditingMember({...editingMember, businessType: e.target.value || undefined})} className="w-full p-3 bg-white rounded-2xl font-bold border border-slate-100 text-sm" placeholder="如：中式餐廳" /></div>
                                 <div><label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">分店數目</label><input value={editingMember.branchCount || ''} onChange={e => setEditingMember({...editingMember, branchCount: e.target.value || undefined})} className="w-full p-3 bg-white rounded-2xl font-bold border border-slate-100 text-sm" placeholder="1" /></div>
                               </div>
                               {editingMember.storefrontPreparing && <div><span className="px-2 py-1 bg-amber-100 text-amber-700 rounded-lg text-[10px] font-black">正在籌備中</span></div>}

                               <div className="pt-3 border-t border-orange-200">
                                 <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">送貨地址（按 BR 填寫）</label>
                                 <textarea value={editingMember.deliveryAddress || ''} onChange={e => {
                                   const oldAddr = members.find(m => m.id === editingMember.id)?.deliveryAddress || '';
                                   const newAddr = e.target.value;
                                   const addrChanged = oldAddr && newAddr !== oldAddr;
                                   setEditingMember({...editingMember, deliveryAddress: newAddr || undefined, brUpdateRequired: addrChanged ? true : editingMember.brUpdateRequired });
                                 }} className="w-full p-3 bg-white rounded-2xl font-bold text-sm border border-slate-100 min-h-[60px] resize-none" placeholder="請根據 BR 上的地址填寫" />
                                 {editingMember.brUpdateRequired && (
                                   <div className="mt-2 p-2.5 bg-red-50 rounded-xl border border-red-200 flex items-center justify-between gap-2">
                                     <p className="text-[10px] font-bold text-red-600">地址已更改 — 需客戶提交新 BR</p>
                                     <button type="button" onClick={() => setEditingMember({...editingMember, brUpdateRequired: false})} className="px-2 py-1 bg-white border border-red-200 rounded-lg text-[9px] font-black text-red-500 hover:bg-red-50 flex-shrink-0">已收到新 BR</button>
                                   </div>
                                 )}
                               </div>

                               <div className="pt-3 border-t border-orange-200">
                                 <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mb-2">商業登記證 (BR)</p>
                                 {editingMember.brDocUrl && (
                                   <a href={editingMember.brDocUrl} target="_blank" rel="noopener noreferrer" className="block mb-2">
                                     <img src={editingMember.brDocUrl} alt="BR" className="w-full max-w-xs rounded-xl border border-slate-200 hover:opacity-80 transition-opacity" />
                                   </a>
                                 )}
                                 <label className={`flex items-center justify-center gap-2 w-full p-3 rounded-xl border-2 border-dashed cursor-pointer transition-colors ${editingMember.brDocUrl ? 'border-slate-200 bg-white hover:border-orange-300' : 'border-orange-300 bg-orange-50 hover:border-orange-400'}`}>
                                   <span className="text-xs font-bold text-slate-500"><Upload size={14} className="inline mr-1" />{editingMember.brDocUrl ? '重新上傳 BR' : '上傳 BR'}</span>
                                   <input type="file" accept="image/*" className="hidden" onChange={async e => {
                                     const file = e.target.files?.[0];
                                     if (!file) return;
                                     try {
                                       const path = `wholesale-registrations/${editingMember.id}/br-doc-${Date.now()}.webp`;
                                       const url = await uploadImage(file, path);
                                       if (url) { setEditingMember({...editingMember, brDocUrl: url, brUpdateRequired: false}); showToast('BR 已更新'); }
                                     } catch { showToast('上傳失敗', 'error'); }
                                   }} />
                                 </label>
                               </div>

                               <div className="pt-3 border-t border-orange-200">
                                 <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mb-2">門口相片</p>
                                 {editingMember.storefrontPhotoUrl && (
                                   <a href={editingMember.storefrontPhotoUrl} target="_blank" rel="noopener noreferrer" className="block mb-2">
                                     <img src={editingMember.storefrontPhotoUrl} alt="Storefront" className="w-full max-w-xs rounded-xl border border-slate-200 hover:opacity-80 transition-opacity" />
                                   </a>
                                 )}
                                 <label className={`flex items-center justify-center gap-2 w-full p-3 rounded-xl border-2 border-dashed cursor-pointer transition-colors ${editingMember.storefrontPhotoUrl ? 'border-slate-200 bg-white hover:border-orange-300' : 'border-orange-300 bg-orange-50 hover:border-orange-400'}`}>
                                   <span className="text-xs font-bold text-slate-500"><Upload size={14} className="inline mr-1" />{editingMember.storefrontPhotoUrl ? '重新上傳門口相片' : '上傳門口相片'}</span>
                                   <input type="file" accept="image/*" className="hidden" onChange={async e => {
                                     const file = e.target.files?.[0];
                                     if (!file) return;
                                     try {
                                       const path = `wholesale-registrations/${editingMember.id}/storefront-${Date.now()}.webp`;
                                       const url = await uploadImage(file, path);
                                       if (url) { setEditingMember({...editingMember, storefrontPhotoUrl: url}); showToast('門口相片已更新'); }
                                     } catch { showToast('上傳失敗', 'error'); }
                                   }} />
                                 </label>
                               </div>
                             </div>
                           </div>
                         )}
                         {editingMember.memberType === 'wholesale' && (
                           <div className="space-y-3">
                             <div className="flex items-center gap-3 mb-2 text-blue-500 font-black uppercase tracking-widest text-xs">營運設定</div>
                             <div className="p-6 bg-blue-50 rounded-[3rem] border border-blue-100 space-y-4">
                               <div className="grid grid-cols-2 gap-3">
                                 <div><label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">客戶編號</label><input value={editingMember.clientCode || ''} onChange={e => setEditingMember({...editingMember, clientCode: e.target.value || undefined})} className="w-full p-3 bg-white rounded-2xl font-bold border border-slate-100 text-sm font-mono" placeholder="A0002-01" /></div>
                                 <div><label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">傳真</label><input value={editingMember.fax || ''} onChange={e => setEditingMember({...editingMember, fax: e.target.value || undefined})} className="w-full p-3 bg-white rounded-2xl font-bold border border-slate-100 text-sm" placeholder="2XXX XXXX" /></div>
                               </div>
                               <div><label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">地區</label><input value={editingMember.district || ''} onChange={e => setEditingMember({...editingMember, district: e.target.value || undefined})} className="w-full p-3 bg-white rounded-2xl font-bold border border-slate-100 text-sm" placeholder="觀塘" /></div>
                               <div className="grid grid-cols-2 gap-3">
                                 <div><label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">信用額度</label><input type="number" value={editingMember.creditLimit || 0} onChange={e => setEditingMember({...editingMember, creditLimit: +e.target.value})} className="w-full p-3 bg-white rounded-2xl font-bold border border-slate-100 text-sm" /></div>
                                 <div><label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">折扣 %</label><input type="number" value={editingMember.discountPercent || 0} onChange={e => setEditingMember({...editingMember, discountPercent: +e.target.value})} className="w-full p-3 bg-white rounded-2xl font-bold border border-slate-100 text-sm" /></div>
                               </div>
                               <div className="grid grid-cols-2 gap-3">
                                 <div><label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">數期類型</label>
                                   <select value={editingMember.paymentTermsType || 'cod'} onChange={e => setEditingMember({...editingMember, paymentTermsType: e.target.value as any})} className="w-full p-3 bg-white rounded-2xl font-bold border border-slate-100 text-sm">
                                     <option value="cod">C.O.D. 貨到付款</option>
                                     <option value="weekly">週結</option>
                                     <option value="biweekly">半月結</option>
                                     <option value="monthly">月結</option>
                                   </select>
                                 </div>
                                 <div><label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">數期天數</label><input type="number" value={editingMember.paymentTermsDays || 0} onChange={e => setEditingMember({...editingMember, paymentTermsDays: +e.target.value})} className="w-full p-3 bg-white rounded-2xl font-bold border border-slate-100 text-sm" /></div>
                               </div>
                               <div><label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">備註</label>
                                 <textarea value={editingMember.wholesaleNotes || ''} onChange={e => setEditingMember({...editingMember, wholesaleNotes: e.target.value || undefined})} rows={2} className="w-full p-3 bg-white rounded-2xl font-bold text-sm border border-slate-100 resize-none" placeholder="營運備註..." />
                               </div>
                               <div className="flex items-center gap-2">
                                 <button type="button" onClick={() => setEditingMember({...editingMember, isWholesaleActive: !editingMember.isWholesaleActive})} className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-black transition-colors ${editingMember.isWholesaleActive !== false ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-400'}`}>
                                   {editingMember.isWholesaleActive !== false ? '✓ 啟用中' : '已停用'}
                                 </button>
                               </div>
                             </div>
                           </div>
                         )}
                      </div>
                   </div>
                </div>
                <div className="p-10 bg-slate-50 border-t border-slate-100 flex justify-end flex-shrink-0">
                   <button onClick={async () => {
                     if (!editingMember.name.trim()) { showToast('請輸入姓名', 'error'); return; }
                     if (!editingMember.phoneNumber?.trim()) { showToast('請輸入電話', 'error'); return; }
                     const isNew = !members.some(m => m.id === editingMember.id);
                     if (isNew && !editingMemberPassword) { showToast('新會員請設定密碼（至少 6 字）', 'error'); return; }
                     if (editingMemberPassword && editingMemberPassword.length < 6) { showToast('密碼至少 6 個字元', 'error'); return; }
                     const hash = editingMemberPassword ? await hashPassword(editingMemberPassword) : undefined;
                     const ok = await upsertMember(editingMember, hash);
                     if (!ok) return;
                     setEditingMember(null);
                     setEditingMemberPassword('');
                     showToast('資料已保存');
                   }} className="px-12 py-4 bg-slate-900 text-white rounded-[2rem] font-black uppercase tracking-widest text-xs shadow-2xl active:scale-95 flex items-center gap-2"><Save size={16}/> 保存並關閉</button>
                </div>
             </div>
          </div>
      )}

      {inspectingOrder && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[6000] flex items-center justify-center p-6 animate-fade-in">
             <div className="bg-white w-full max-w-4xl rounded-[4rem] shadow-2xl overflow-hidden flex flex-col max-h-[90vh] animate-scale-up">
                <div className="p-8 border-b border-slate-50 flex justify-between items-center bg-slate-900 text-white">
                   <div className="flex items-center gap-5">
                      <div className="w-14 h-14 bg-white/10 rounded-3xl flex items-center justify-center text-white shadow-inner"><Package size={28}/></div>
                      <div><h4 className="text-2xl font-black tracking-tight">{inspectingOrder.id}</h4><p className="text-[10px] font-bold text-white/40 uppercase tracking-[0.2em]">{inspectingOrder.date} • 下單完成</p></div>
                   </div>
                   <button onClick={() => setInspectingOrder(null)} className="p-3 bg-white/10 rounded-full hover:bg-white/20 transition-all text-white"><X size={20}/></button>
                </div>
                <div className="flex-1 overflow-y-auto p-10 space-y-6 bg-white hide-scrollbar">
                  {!inspectingOrderDetails ? (
                    <div className="text-center text-slate-400 font-bold">載入中...</div>
                  ) : (
                    <>
                      {/* 1. 商品明細 — 最高 */}
                      <div className="bg-white border border-slate-100 rounded-2xl p-4">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">商品明細</p>
                        <div className="space-y-3">
                          {(inspectingOrderDetails.line_items || []).length === 0 && (
                            <p className="text-xs text-slate-400 font-bold">沒有商品明細</p>
                          )}
                          {(inspectingOrderDetails.line_items || []).map(item => (
                            <div key={`${item.product_id}-${item.name}`} className="flex items-center gap-3 text-sm font-bold text-slate-700">
                              <div className="w-14 h-14 rounded-xl bg-slate-100 overflow-hidden flex-shrink-0 border border-slate-100">
                                {item.image ? (
                                  <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                                ) : (
                                  <div className="w-full h-full flex items-center justify-center text-slate-300 text-xs">無圖</div>
                                )}
                              </div>
                              <div className="flex-1 min-w-0">
                                <span>{item.name} x {item.qty}</span>
                              </div>
                              <span className="flex-shrink-0">${formatMoney(item.line_total)}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* 2. 配送方式及聯絡人 — 合在一起，地址只顯示一次 */}
                      <div className="bg-slate-50 rounded-2xl p-4 space-y-3">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">配送方式及聯絡人</p>
                        <p className="text-sm font-bold text-slate-900">{inspectingOrderDetails.delivery_method || '未設定'}</p>
                        {(inspectingOrderDetails.delivery_district || inspectingOrderDetails.delivery_address) ? (
                          <p className="text-xs text-slate-600 font-bold">
                            {[inspectingOrderDetails.delivery_district, inspectingOrderDetails.delivery_address].filter(Boolean).join(' · ') +
                              ((inspectingOrderDetails.delivery_floor || inspectingOrderDetails.delivery_flat)
                                ? ` · ${inspectingOrderDetails.delivery_floor || ''}${inspectingOrderDetails.delivery_floor ? '樓' : ''}${inspectingOrderDetails.delivery_flat ? (inspectingOrderDetails.delivery_floor ? ' ' : '') + inspectingOrderDetails.delivery_flat + '室' : ''}`
                                : '')}
                          </p>
                        ) : (
                          <p className="text-xs text-slate-500 font-bold">未提供地址</p>
                        )}
                        <p className="text-sm font-bold text-slate-900 pt-1 border-t border-slate-200">聯絡人：{inspectingOrderDetails.contact_name || '未提供'}</p>
                      </div>

                      {/* 3. 金額明細 */}
                      <div className="bg-slate-50 rounded-2xl p-4">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">金額明細</p>
                        <p className="text-sm font-bold text-slate-900">小計 ${formatMoney(inspectingOrderDetails.subtotal ?? inspectingOrder.total)}</p>
                        <p className="text-xs text-slate-500 font-bold mt-1">運費 ${formatMoney(inspectingOrderDetails.delivery_fee ?? 0)}</p>
                        <p className="text-xs text-slate-700 font-black mt-1">總計 ${formatMoney(inspectingOrderDetails.total)}</p>
                      </div>

                      {/* 4. 客戶 */}
                      <div className="bg-slate-50 rounded-2xl p-4">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">客戶</p>
                        <p className="text-sm font-bold text-slate-900">{inspectingOrderDetails.customer_name}</p>
                        <p className="text-xs text-slate-500 font-bold mt-1">{inspectingOrderDetails.customer_phone || '未提供電話'}</p>
                      </div>

                      {/* 5. 物流資訊 */}
                      <div className="bg-slate-50 rounded-2xl p-4 space-y-2">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">物流資訊</p>
                        <p className="text-xs font-bold text-slate-700">物流公司：順豐速運</p>
                        <p className="text-xs font-bold text-slate-700">物流狀態：{getOrderStatusLabel(inspectingOrderDetails.status)}</p>
                        <p className="text-xs font-bold text-slate-700">單號：{inspectingOrderDetails.waybill_no ?? inspectingOrderDetails.tracking_number ?? '未提供'}</p>
                        <p className="text-[10px] text-slate-500 font-bold">最後更新：{inspectingOrderDetails.order_date}</p>
                      </div>

                      {isAdminRoute && (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">訂單狀態</label>
                            <select value={orderStatusDraft || inspectingOrder.status} onChange={e => setOrderStatusDraft(e.target.value as OrderStatus)} className="w-full p-3 bg-slate-50 rounded-2xl font-bold">
                              {Object.values(OrderStatus).map(s => (<option key={s} value={s}>{getOrderStatusLabel(s)}</option>))}
                            </select>
                          </div>
                          <div>
                            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">物流編號</label>
                            <input value={trackingDraft} onChange={e => setTrackingDraft(e.target.value)} className="w-full p-3 bg-slate-50 rounded-2xl font-bold" placeholder="輸入物流編號" />
                          </div>
                        </div>
                      )}
                    </>
                  )}
                </div>
                <div className="p-10 bg-slate-50 border-t border-slate-100 flex justify-between items-center">
                  <button onClick={() => setInspectingOrder(null)} className="px-8 py-3 bg-white border border-slate-200 rounded-2xl font-black text-xs">關閉</button>
                  <div className="flex items-center gap-3">
                    {isAdminRoute && inspectingOrderDetails && (
                      <button onClick={() => setRefundModal({ orderId: inspectingOrder.id, total: inspectingOrderDetails.total })}
                        className="px-6 py-3 bg-rose-600 text-white rounded-2xl font-black text-xs hover:bg-rose-500 transition-colors">
                        退款操作
                      </button>
                    )}
                    {isAdminRoute && (
                      <button onClick={() => updateOrderFields(inspectingOrder.id, { status: orderStatusDraft || inspectingOrder.status, waybill_no: trackingDraft || null })} className="px-8 py-3 bg-slate-900 text-white rounded-2xl font-black text-xs">更新訂單</button>
                    )}
                  </div>
                </div>
             </div>
          </div>
      )}

      {/* SF Validation Modal — 呼叫順豐前的地址驗證 */}
      {sfValidationModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[6500] flex items-center justify-center p-6 animate-fade-in">
          <div className="bg-white w-full max-w-lg rounded-[2rem] shadow-2xl p-8 space-y-6">
            <div className="flex items-center gap-3">
              <AlertTriangle className="text-amber-500" size={20} />
              <h4 className="text-lg font-black text-slate-900">地址驗證結果</h4>
            </div>
            {sfValidationModal.problematic.length > 0 && (
              <div className="space-y-2">
                <p className="text-sm font-bold text-slate-600">以下訂單資料不完整，將被跳過：</p>
                <div className="max-h-48 overflow-y-auto space-y-2">
                  {sfValidationModal.problematic.map(p => (
                    <div key={p.id} className="flex items-center gap-3 bg-amber-50 border border-amber-100 rounded-xl p-3">
                      <AlertTriangle className="text-amber-500 flex-shrink-0" size={14} />
                      <div>
                        <span className="text-sm font-black text-slate-900">訂單 #{p.id}</span>
                        <span className="text-xs font-bold text-amber-700 ml-2">{p.reason}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            {sfValidationModal.valid.length > 0 && (
              <p className="text-sm font-bold text-emerald-700 bg-emerald-50 rounded-xl p-3">
                可處理的訂單：{sfValidationModal.valid.length} 筆
              </p>
            )}
            <div className="flex justify-end gap-3">
              <button onClick={() => setSfValidationModal(null)} className="px-6 py-3 bg-white border border-slate-200 rounded-2xl font-black text-xs">取消</button>
              {sfValidationModal.valid.length > 0 && (
                <button
                  disabled={batchProcessing}
                  onClick={() => executeSfCalls(sfValidationModal.valid, { autoPrintLabels: true })}
                  className="px-6 py-3 bg-emerald-600 text-white rounded-2xl font-black text-xs disabled:opacity-50"
                >
                  {batchProcessing ? '處理中...' : `建立運單並打印 ${sfValidationModal.valid.length} 筆`}
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Refund Modal */}
      {refundModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[7000] flex items-center justify-center p-6 animate-fade-in">
          <div className="bg-white w-full max-w-md rounded-[2rem] shadow-2xl p-8 space-y-6">
            <div className="flex items-center gap-3">
              <CreditCard className="text-rose-500" size={20} />
              <h4 className="text-lg font-black text-slate-900">退款操作</h4>
            </div>
            <p className="text-sm font-bold text-slate-500">訂單 #{refundModal.orderId} ・ 總金額 ${formatMoney(refundModal.total)}</p>

            <div className="space-y-3">
              <label className="flex items-center gap-3 p-4 bg-slate-50 rounded-2xl cursor-pointer hover:bg-slate-100 transition-colors"
                onClick={() => { setRefundType('full'); setRefundAmount(String(refundModal.total)); }}>
                <input type="radio" name="refundType" checked={refundType === 'full'} readOnly className="accent-rose-600" />
                <div>
                  <span className="font-black text-slate-900">全額退款</span>
                  <span className="text-sm font-bold text-slate-500 ml-2">${formatMoney(refundModal.total)}</span>
                </div>
              </label>
              <label className="flex items-center gap-3 p-4 bg-slate-50 rounded-2xl cursor-pointer hover:bg-slate-100 transition-colors"
                onClick={() => setRefundType('partial')}>
                <input type="radio" name="refundType" checked={refundType === 'partial'} readOnly className="accent-rose-600" />
                <span className="font-black text-slate-900">部分退款</span>
              </label>
              {refundType === 'partial' && (
                <div className="pl-8">
                  <div className="flex items-center gap-2">
                    <span className="text-xl font-black text-slate-400">$</span>
                    <input type="number" min="0.01" max={refundModal.total} step="0.01"
                      value={refundAmount} onChange={e => setRefundAmount(e.target.value)}
                      placeholder="輸入退款金額" className="flex-1 p-3 bg-white border border-slate-200 rounded-xl font-black text-lg focus:ring-2 focus:ring-rose-100" />
                  </div>
                  <p className="text-[10px] text-slate-400 font-bold mt-1">最大退款金額：${formatMoney(refundModal.total)}</p>
                </div>
              )}
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <button onClick={() => { setRefundModal(null); setRefundAmount(''); setRefundType('full'); }}
                className="px-6 py-3 bg-white border border-slate-200 rounded-2xl font-black text-xs">取消</button>
              <button disabled={refundProcessing} onClick={handleRefund}
                className="px-6 py-3 bg-rose-600 text-white rounded-2xl font-black text-xs disabled:opacity-50 hover:bg-rose-500 transition-colors">
                {refundProcessing ? '處理中...' : '確認退款'}
              </button>
            </div>
          </div>
        </div>
      )}

      {aiPromptModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[6500] flex items-center justify-center p-6 animate-fade-in">
          <div className="bg-white w-full max-w-md rounded-[2rem] shadow-2xl p-8 space-y-5">
            <div className="flex items-center gap-3">
              <Sparkles className="text-purple-500" size={20} />
              <h4 className="text-lg font-black text-slate-900">{aiPromptModal.title}</h4>
            </div>
            <p className="text-xs text-slate-500 font-bold">可以留空直接生成，或輸入指令讓 AI 按你要求生成。</p>
            <textarea
              value={aiPromptText}
              onChange={e => setAiPromptText(e.target.value)}
              placeholder={aiPromptModal.placeholder}
              className="w-full p-4 bg-slate-50 rounded-2xl font-bold text-sm min-h-[100px] border border-slate-200 focus:border-purple-300 focus:ring-1 focus:ring-purple-200 outline-none transition-all"
            />
            <div className="flex justify-end gap-3">
              <button onClick={() => { setAiPromptModal(null); setAiPromptText(''); }} className="px-6 py-3 bg-white border border-slate-200 rounded-2xl font-black text-xs">取消</button>
              <button onClick={() => { const text = aiPromptText; setAiPromptModal(null); setAiPromptText(''); aiPromptModal.onConfirm(text); }} className="px-6 py-3 bg-purple-600 text-white rounded-2xl font-black text-xs flex items-center gap-1.5">
                <Sparkles size={12} /> 開始生成
              </button>
            </div>
          </div>
        </div>
      )}

      {confirmation && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[6500] flex items-center justify-center p-6 animate-fade-in">
          <div className="bg-white w-full max-w-md rounded-[2rem] shadow-2xl p-8 space-y-6">
            <div className="flex items-center gap-3">
              <AlertTriangle className="text-rose-500" size={20} />
              <h4 className="text-lg font-black text-slate-900">{confirmation.title}</h4>
            </div>
            <p className="text-sm text-slate-600 font-bold leading-relaxed">{confirmation.message}</p>
            <div className="flex justify-end gap-3">
              <button onClick={() => setConfirmation(null)} className="px-6 py-3 bg-white border border-slate-200 rounded-2xl font-black text-xs">取消</button>
              <button onClick={() => { confirmation.onConfirm(); setConfirmation(null); }} className="px-6 py-3 bg-rose-600 text-white rounded-2xl font-black text-xs">確認</button>
            </div>
          </div>
        </div>
      )}
    </>
  );

  // ── 免運進度提示元件（雙門檻：自提櫃 / 送貨上門）──
  const FreeShippingNudge = ({ compact = false }: { compact?: boolean }) => {
    const { subtotal, lockerThreshold, deliveryThreshold } = pricingData;

    // 三段式狀態判斷
    const tier: 'below_locker' | 'between' | 'all_free' =
      subtotal < lockerThreshold ? 'below_locker' :
      subtotal < deliveryThreshold ? 'between' : 'all_free';

    // 進度條：以最高門檻為 100%
    const progress = Math.min(1, subtotal / (deliveryThreshold || 1));
    // 中間刻度位置
    const lockerMark = deliveryThreshold > 0 ? (lockerThreshold / deliveryThreshold) * 100 : 50;

    // 進度條顏色
    const barColor = tier === 'all_free'
      ? 'bg-emerald-400'
      : tier === 'between'
      ? 'bg-gradient-to-r from-emerald-400 to-teal-300'
      : 'bg-gradient-to-r from-orange-400 to-amber-400';

    if (compact) {
      // 簡約版：嵌入購物車按鈕
      const label = tier === 'all_free'
        ? '✓ 全場免運'
        : tier === 'between'
        ? `自提免運！差$${formatMoney(Math.max(0, deliveryThreshold - subtotal))}上門免運`
        : `差$${formatMoney(Math.max(0, lockerThreshold - subtotal))}自提免運`;
      const textColor = tier === 'all_free' ? 'text-emerald-400' : tier === 'between' ? 'text-teal-300' : 'text-orange-300';

      return (
        <div className="px-1">
          <div className="flex items-center gap-2">
            <p className={`text-[9px] font-bold ${textColor} whitespace-nowrap`}>{label}</p>
            {tier !== 'all_free' && (
              <div className="flex-1 h-1 bg-white/10 rounded-full overflow-hidden min-w-[32px] relative">
                <div className={`h-full ${barColor} rounded-full transition-all duration-500 ease-out`} style={{ width: `${progress * 100}%` }} />
              </div>
            )}
          </div>
        </div>
      );
    }

    // 完整版：用於結帳金額明細區
    const bgClass = tier === 'all_free' ? 'bg-emerald-500/10' : tier === 'between' ? 'bg-teal-500/10' : 'bg-orange-500/10';

    return (
      <div className={`px-3 py-2.5 rounded-xl ${bgClass} transition-all`}>
        {tier === 'all_free' ? (
          <p className="text-[11px] font-black text-emerald-400 text-center">🎉 已享有全場免運費優惠！</p>
        ) : (
          <div className="space-y-2">
            <p className={`text-[11px] font-bold text-center ${tier === 'between' ? 'text-teal-300' : 'text-orange-300'}`}>
              {tier === 'between'
                ? <>自提櫃已免運！再買 <span className="font-black">${formatMoney(Math.max(0, deliveryThreshold - subtotal))}</span> 即享送貨上門免運 🏠</>
                : <>仲差 <span className="font-black">${formatMoney(Math.max(0, lockerThreshold - subtotal))}</span> 享自提櫃免運 📦</>
              }
            </p>
            {/* 雙門檻進度條 */}
            <div className="relative w-full h-1.5 bg-white/10 rounded-full overflow-visible">
              <div className={`h-full ${barColor} rounded-full transition-all duration-500 ease-out`} style={{ width: `${progress * 100}%` }} />
              {/* $200 刻度線 */}
              <div className="absolute top-0 h-full w-px bg-white/20" style={{ left: `${lockerMark}%` }} />
            </div>
            <div className="relative w-full h-3 text-[8px] text-white/25 font-bold">
              <span className="absolute left-0">$0</span>
              <span className="absolute" style={{ left: `${lockerMark}%`, transform: 'translateX(-50%)' }}>📦${lockerThreshold}</span>
              <span className="absolute right-0">🏠${deliveryThreshold}</span>
            </div>
          </div>
        )}
      </div>
    );
  };

  // ── 一鍵湊免運推薦區塊 ──
  const UpsellNudge = () => {
    const { subtotal, shippingThreshold, deliveryFee } = pricingData;
    const diff = shippingThreshold - subtotal;
    // 只在 1 ≤ diff ≤ 50 且有可推薦產品時顯示
    if (deliveryFee === 0 || diff < 1 || diff > 50 || upsellProducts.length === 0) return null;

    return (
      <section className="bg-white p-5 rounded-[2.5rem] border border-orange-100 shadow-sm space-y-4 animate-fade-in">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-orange-100 rounded-xl"><Zap size={14} className="text-orange-500" /></div>
          <h3 className="text-xs font-black text-orange-500 uppercase tracking-widest">差少少就免運費！加多件就可以：</h3>
        </div>
        <div className="flex gap-3 overflow-x-auto pb-1 hide-scrollbar -mx-1 px-1">
          {upsellProducts.map(p => {
            const effectivePrice = getPrice(p);
            return (
              <div key={p.id} className="flex-shrink-0 w-40 bg-slate-50 rounded-2xl border border-slate-100 p-3 space-y-2.5 hover:border-orange-200 transition-all">
                <div className="w-full h-20 bg-white rounded-xl border border-slate-50 flex items-center justify-center text-3xl overflow-hidden">
                  {isMediaUrl(p.image) ? <img src={p.image} loading="lazy" className="w-full h-full object-cover" alt={pName(p)} /> : <span>{p.image || '📦'}</span>}
                </div>
                <p className="text-xs font-black text-slate-700 truncate">{pName(p)}</p>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-black text-orange-600">${effectivePrice}</span>
                  <button
                    onClick={() => { updateCart(p, 1); showToast(`已加入 ${pName(p)}`); }}
                    className="px-3 py-1.5 bg-orange-500 text-white rounded-xl text-[10px] font-black shadow-md active:scale-90 transition-all whitespace-nowrap"
                  >
                    + 加購
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>
    );
  };

  const renderCheckoutView = () => {
    const { subtotal, deliveryFee, total } = pricingData;

    if (cart.length === 0) {
      return (
        <div className="flex-1 bg-slate-50 min-h-screen flex flex-col items-center justify-center gap-6 animate-fade-in px-6">
          <div className="w-24 h-24 bg-slate-100 rounded-full flex items-center justify-center"><ShoppingBag size={40} className="text-slate-300" /></div>
          <div className="text-center space-y-2">
            <h2 className="text-xl font-black text-slate-800">購物車是空的</h2>
            <p className="text-sm text-slate-400 font-bold">快去挑選心水凍肉吧！</p>
          </div>
          <button onClick={() => setView('store')} className="px-8 py-3 bg-blue-600 text-white rounded-2xl font-black text-sm shadow-xl active:scale-95 transition-all">返回商店</button>
        </div>
      );
    }

    // ── Wholesale Checkout UI ──
    if (isWholesaleRoute) {
      return (
        <div className="flex-1 bg-slate-100 min-h-screen pb-48 overflow-y-auto animate-fade-in">
          <header className="bg-white sticky top-0 z-40 px-4 py-3.5 border-b border-slate-200/60 flex items-center justify-between">
            <button onClick={() => setView('store')} className="p-2 -ml-1 hover:bg-slate-50 rounded-full transition-colors"><ChevronLeft size={22} className="text-slate-700" /></button>
            <h2 className="text-base font-black text-slate-900 tracking-tight">批發結帳</h2>
            <div className="w-10" />
          </header>

          <div className="p-4 sm:p-6 space-y-3">
            {/* ─── Cart Items ─── */}
            <section className="bg-white rounded-2xl shadow-sm overflow-hidden">
              <div className="px-5 pt-5 pb-3">
                <p className="text-[11px] font-bold text-slate-400 uppercase tracking-widest">訂單內容 ({cart.reduce((s, i) => s + i.qty, 0)} 件)</p>
              </div>
              <div className="px-5 pb-4 space-y-3">
                {cart.map(item => {
                  const price = getPrice(item, item.qty);
                  return (
                    <div key={item.id} className="flex items-center gap-3">
                      {item.image && <img src={item.image} alt={item.name} className="w-12 h-12 rounded-xl object-cover bg-slate-100" />}
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-bold text-slate-800 truncate">{item.name}</p>
                        <p className="text-xs text-slate-400 font-bold">${formatMoney(price)} × {item.qty}</p>
                      </div>
                      <p className="text-sm font-black text-slate-900">${formatMoney(price * item.qty)}</p>
                    </div>
                  );
                })}
              </div>
            </section>

            {/* ─── Delivery Info ─── */}
            <section className="bg-white rounded-2xl shadow-sm overflow-hidden">
              <div className="px-5 pt-5 pb-3">
                <p className="text-[11px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5"><Truck size={12} /> 送貨資料</p>
              </div>
              <div className="px-5 pb-5 space-y-3">
                <div>
                  <label className="text-[10px] font-bold text-slate-500 mb-1 block">送貨地址</label>
                  {user?.deliveryAddress ? (
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                      <p className="text-sm font-bold text-slate-800 leading-relaxed">{user.deliveryAddress}</p>
                    </div>
                  ) : (
                    <div className="p-3 bg-amber-50 rounded-xl border border-amber-100">
                      <p className="text-xs font-bold text-amber-700">送貨地址尚未設定，我們會在審核後按 BR 地址安排送貨。</p>
                    </div>
                  )}
                  <p className="text-[9px] text-slate-400 font-bold mt-1.5">如需更改送貨地址，請聯絡客服。</p>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-500 mb-1 block">送貨日期</label>
                  <input
                    type="date"
                    value={wholesaleDeliveryDate}
                    onChange={e => setWholesaleDeliveryDate(e.target.value)}
                    min={new Date().toISOString().slice(0, 10)}
                    className="w-full p-3 bg-slate-50 rounded-xl text-sm font-bold border border-slate-100"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-500 mb-1 block">備註（選填）</label>
                  <textarea
                    value={wholesaleDeliveryNote}
                    onChange={e => setWholesaleDeliveryNote(e.target.value)}
                    placeholder="送貨備註（如有特別要求）"
                    className="w-full p-3 bg-slate-50 rounded-xl text-sm font-bold border border-slate-100 min-h-[60px] resize-none"
                  />
                </div>
              </div>
            </section>

            {/* ─── Payment Method ─── */}
            <section className="bg-white rounded-2xl shadow-sm overflow-hidden">
              <div className="px-5 pt-5 pb-3">
                <p className="text-[11px] font-bold text-slate-400 uppercase tracking-widest">付款方式</p>
              </div>
              <div className="px-5 pb-5">
                <div className="grid grid-cols-2 gap-2">
                  <button onClick={() => setPaymentMethod('fps')} className={`py-3.5 px-4 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-2 ${paymentMethod === 'fps' ? 'bg-slate-900 text-white shadow-md' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'}`}>
                    <DollarSign size={14} /> FPS 轉帳
                  </button>
                  <button onClick={() => setPaymentMethod('cod')} className={`py-3.5 px-4 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-2 ${paymentMethod === 'cod' ? 'bg-slate-900 text-white shadow-md' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'}`}>
                    <Coins size={14} /> 到付 (COD)
                  </button>
                </div>
                {paymentMethod === 'fps' && (
                  <div className="mt-3 p-3 bg-blue-50 rounded-xl border border-blue-100">
                    <p className="text-xs font-bold text-blue-700">下單後請以 FPS 轉帳至指定帳號，我們確認收款後會安排送貨。</p>
                  </div>
                )}
                {paymentMethod === 'cod' && (
                  <div className="mt-3 p-3 bg-amber-50 rounded-xl border border-amber-100">
                    <p className="text-xs font-bold text-amber-700">送貨員到達時收款（現金），確認後訂單完成。</p>
                  </div>
                )}
              </div>
            </section>

            {/* ─── Order Total + Submit ─── */}
            <section className="bg-white rounded-2xl shadow-sm overflow-hidden">
              <div className="px-5 pt-5 pb-4 space-y-2">
                <div className="flex justify-between text-xs font-bold text-slate-400"><span>商品小計</span><span className="text-slate-700">${formatMoney(subtotal)}</span></div>
                <div className="flex justify-between text-xs font-bold text-slate-400"><span>運費</span><span className="text-emerald-600 font-black">免運費</span></div>
                <div className="pt-3 border-t border-slate-100 flex justify-between items-end">
                  <span className="text-xs font-black text-slate-400 uppercase tracking-widest">合計</span>
                  <span className="text-2xl font-black text-slate-900">${formatMoney(total)}</span>
                </div>
              </div>
              <div className="px-5 pb-5">
                <button
                  disabled={!user || cart.length === 0}
                  onClick={handleSubmitOrder}
                  className="w-full py-4 bg-orange-600 text-white rounded-xl font-black text-sm shadow-lg active:scale-[0.98] transition-all disabled:opacity-30 flex items-center justify-center gap-2"
                >
                  {paymentMethod === 'cod' ? <Coins size={16} /> : <DollarSign size={16} />}
                  {paymentMethod === 'cod' ? `確認訂單 (到付 $${formatMoney(total)})` : `確認訂單 (FPS $${formatMoney(total)})`}
                </button>
                {!user && <p className="text-center text-xs text-red-500 font-bold mt-2">請先登入批發帳號</p>}
              </div>
            </section>
          </div>
        </div>
      );
    }

    return (
      <div className="flex-1 bg-slate-100 min-h-screen pb-48 overflow-y-auto animate-fade-in">
        {isRedirectingToPayment && (
          <div className="fixed inset-0 bg-white/90 backdrop-blur-sm z-[8000] flex flex-col items-center justify-center gap-4 animate-fade-in">
            <RefreshCw size={32} className="animate-spin text-blue-600" />
            <p className="text-sm font-black text-slate-700">{lang === 'en' ? 'Processing payment...' : '正在處理支付...'}</p>
          </div>
        )}
        <header className="bg-white sticky top-0 z-40 px-4 py-3.5 border-b border-slate-200/60 flex items-center justify-between">
          <button onClick={() => setView('store')} className="p-2 -ml-1 hover:bg-slate-50 rounded-full transition-colors"><ChevronLeft size={22} className="text-slate-700" /></button>
          <h2 className="text-base font-black text-slate-900 tracking-tight">{lang === 'en' ? 'Checkout' : '結帳'}</h2>
          <div className="w-10" />
        </header>

        <div className="p-4 sm:p-6 space-y-3">
          {/* ─── Section 1: Delivery Method ─── */}
          <section className="bg-white rounded-2xl shadow-sm overflow-hidden">
            <div className="px-5 pt-5 pb-3">
              <p className="text-[11px] font-bold text-slate-400 uppercase tracking-widest">{lang === 'en' ? 'Delivery' : '配送方式'}</p>
            </div>
            <div className="px-5 pb-5">
              <div className="grid grid-cols-2 gap-2">
                <button onClick={() => setDeliveryMethod('home')} className={`py-3.5 px-4 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-2 ${deliveryMethod === 'home' ? 'bg-slate-900 text-white shadow-md' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'}`}>
                  <Truck size={14} /> {t.checkout.homeDelivery}
                </button>
                <button onClick={() => setDeliveryMethod('sf_locker')} className={`py-3.5 px-4 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-2 ${deliveryMethod === 'sf_locker' ? 'bg-slate-900 text-white shadow-md' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'}`}>
                  <Package size={14} /> {t.checkout.sfLocker}
                </button>
              </div>
            </div>
          </section>

          {/* ─── Section 2: Address / Locker ─── */}
          <section className="bg-white rounded-2xl shadow-sm overflow-hidden">
            <div className="px-5 pt-5 pb-3">
              <p className="text-[11px] font-bold text-slate-400 uppercase tracking-widest">{deliveryMethod === 'sf_locker' ? (lang === 'en' ? 'Pickup Point' : '自提點') : (lang === 'en' ? 'Delivery Address' : '收貨地址')}</p>
            </div>
            <div className="px-5 pb-5">
            {deliveryMethod === 'sf_locker' ? (
              <div className="space-y-3">
                <select value={selectedLockerDistrict} onChange={(e) => { setSelectedLockerDistrict(e.target.value); setSelectedLockerCode(''); }} className="w-full p-3.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold focus:ring-2 focus:ring-blue-100 focus:border-blue-300 transition-all">
                  <option value="">— {lang === 'en' ? 'Select district' : '選擇地區'} —</option>
                  {SF_COLD_DISTRICT_NAMES.map(d => <option key={d} value={d}>{d}</option>)}
                </select>
                <select value={selectedLockerCode} onChange={(e) => setSelectedLockerCode(e.target.value)} disabled={!selectedLockerDistrict} className="w-full p-3.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold focus:ring-2 focus:ring-blue-100 focus:border-blue-300 transition-all disabled:opacity-40">
                  <option value="">{selectedLockerDistrict ? `— ${lang === 'en' ? 'Select pickup point' : '選擇自提點'} —` : `— ${lang === 'en' ? 'Select district first' : '請先選擇地區'} —`}</option>
                  {lockerPointsForDistrict.map(p => (<option key={p.code} value={p.code}>{p.area} · {p.name}</option>))}
                </select>
                {selectedLockerPoint && (
                  <div className="bg-blue-50 rounded-xl p-4 space-y-1 animate-fade-in">
                    <p className="text-xs font-black text-blue-900">{selectedLockerPoint.name}</p>
                    <p className="text-[11px] font-bold text-blue-700 leading-relaxed">{selectedLockerPoint.address}</p>
                    <p className="text-[10px] font-bold text-blue-500">{selectedLockerPoint.code} · {selectedLockerPoint.hours.weekday}（平日）/ {selectedLockerPoint.hours.weekend}（週末）</p>
                  </div>
                )}
                {!user?.phoneNumber && (
                  <div className="space-y-1">
                    <label className="block text-[11px] font-bold text-slate-500">{lang === 'en' ? 'Contact phone *' : '聯絡電話 *'}</label>
                    <input
                      type="tel"
                      value={checkoutGuestPhone}
                      onChange={(e) => setCheckoutGuestPhone(e.target.value)}
                      className="w-full p-3.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold focus:ring-2 focus:ring-blue-100 focus:border-blue-300 transition-all"
                      placeholder={lang === 'en' ? 'Phone number for delivery updates' : '用作送貨通知的電話號碼'}
                    />
                  </div>
                )}
              </div>
            ) : (
              <div className="space-y-3">
                {isChangingAddress && user ? (
                  <div className="space-y-4 animate-fade-in">
                    <div className="flex items-center justify-between">
                      <p className="text-xs font-black text-slate-700">{lang === 'en' ? 'Change address' : '更改地址'}</p>
                      <button type="button" onClick={() => { setIsChangingAddress(false); setCheckoutAddressDraft(null); }} className="py-1.5 px-3 bg-slate-100 rounded-lg text-slate-500 text-[10px] font-black">{lang === 'en' ? 'Back' : '返回'}</button>
                    </div>
                    {user.addresses && user.addresses.length > 0 && (
                      <div className="space-y-2">
                        {user.addresses.map(addr => {
                          const isSelected = (checkoutSelectedAddressId ?? user.addresses!.find(a => a.isDefault)?.id) === addr.id;
                          return (
                            <button type="button" key={addr.id} onClick={() => { setCheckoutSelectedAddressId(addr.id); setIsChangingAddress(false); }} className={`w-full p-3.5 rounded-xl border-2 text-left transition-all flex items-center justify-between ${isSelected ? 'border-blue-500 bg-blue-50/50' : 'border-slate-100 hover:border-slate-200'}`}>
                              <div className="min-w-0 flex-1">
                                <p className="text-[11px] text-slate-600 font-bold leading-relaxed">{formatAddressLine(addr)}</p>
                                <p className="text-[10px] text-slate-400 font-bold mt-0.5">{addr.contactName} · {addr.phone}</p>
                              </div>
                              {isSelected && <Check size={16} className="flex-shrink-0 ml-2 text-blue-600" />}
                            </button>
                          );
                        })}
                      </div>
                    )}
                    <div className="pt-2 border-t border-slate-100">
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">{lang === 'en' ? 'New address' : '新增地址'}</p>
                      {checkoutAddressDraft && (
                        <div className="space-y-2.5">
                          <div className="flex gap-2 items-center">
                            <select value={checkoutAddressDraft.district ?? ''} onChange={e => setCheckoutAddressDraft({ ...checkoutAddressDraft, district: e.target.value })} className="flex-1 p-3 bg-slate-50 rounded-xl font-bold text-sm border border-slate-200">
                              <option value="">{lang === 'en' ? 'District *' : '選擇地區 *'}</option>
                              {HK_DISTRICTS.map(d => <option key={d} value={d}>{d}</option>)}
                            </select>
                            <button type="button" onClick={handleLocateMe} disabled={isLocatingAddress} className="flex-shrink-0 w-11 h-11 flex items-center justify-center bg-slate-50 border border-slate-200 rounded-xl text-slate-500 hover:bg-slate-100 disabled:opacity-50 transition-all"><Crosshair size={18} /></button>
                          </div>
                          <input value={checkoutAddressDraft.detail ?? ''} onChange={e => setCheckoutAddressDraft({ ...checkoutAddressDraft, detail: e.target.value })} className="w-full p-3 bg-slate-50 rounded-xl font-bold text-sm border border-slate-200" placeholder={lang === 'en' ? 'Address *' : '地址 *（街道／門牌）'} />
                          <div className="grid grid-cols-2 gap-2">
                            <input value={checkoutAddressDraft.floor ?? ''} onChange={e => setCheckoutAddressDraft({ ...checkoutAddressDraft, floor: e.target.value })} className="w-full p-3 bg-slate-50 rounded-xl font-bold text-sm border border-slate-200" placeholder={lang === 'en' ? 'Floor *' : '樓層 *'} />
                            <input value={checkoutAddressDraft.flat ?? ''} onChange={e => setCheckoutAddressDraft({ ...checkoutAddressDraft, flat: e.target.value })} className="w-full p-3 bg-slate-50 rounded-xl font-bold text-sm border border-slate-200" placeholder={lang === 'en' ? 'Unit *' : '室／單位 *'} />
                          </div>
                          <input value={checkoutAddressDraft.contactName} onChange={e => setCheckoutAddressDraft({ ...checkoutAddressDraft, contactName: e.target.value })} className="w-full p-3 bg-slate-50 rounded-xl font-bold text-sm border border-slate-200" placeholder={lang === 'en' ? 'Recipient *' : '收件人名稱 *'} />
                          <input type="tel" value={checkoutAddressDraft.phone} onChange={e => setCheckoutAddressDraft({ ...checkoutAddressDraft, phone: e.target.value })} className="w-full p-3 bg-slate-50 rounded-xl font-bold text-sm border border-slate-200" placeholder={lang === 'en' ? 'Phone *' : '手機號碼 *'} />
                          <label className="flex items-center gap-2.5 cursor-pointer"><input type="checkbox" checked={checkoutSaveNewAddressAsDefault} onChange={e => setCheckoutSaveNewAddressAsDefault(e.target.checked)} className="w-4 h-4 rounded border-slate-300 text-blue-600" /><span className="text-[11px] font-bold text-slate-500">{lang === 'en' ? 'Set as default' : '設為預設地址'}</span></label>
                          <button type="button" onClick={() => { if (!isAddressCompleteForOrder(checkoutAddressDraft)) { showToast(lang === 'en' ? 'Please fill in all required fields' : '請填寫地區、地址、樓層、單位、收件人及手機號碼', 'error'); return; } handleSaveAddress(user.id, checkoutAddressDraft, true, checkoutSaveNewAddressAsDefault); setCheckoutSelectedAddressId(checkoutAddressDraft.id); setIsChangingAddress(false); setCheckoutAddressDraft(null); showToast(lang === 'en' ? 'Address saved' : '已保存地址'); }} className="w-full py-3 bg-slate-900 text-white rounded-xl font-black text-xs">{lang === 'en' ? 'Save & Use' : '保存並使用'}</button>
                        </div>
                      )}
                    </div>
                  </div>
                ) : showCheckoutAddressForm && checkoutAddressDraft ? (
                  <div className="space-y-2.5 animate-fade-in">
                    {!user && (
                      <p className="text-[10px] text-slate-400 font-bold">
                        {lang === 'en' ? 'Register to save your address.' : '註冊會員可以記錄預設地址。'}
                        <button type="button" onClick={() => setView('profile')} className="text-blue-600 underline ml-1">{lang === 'en' ? 'Sign up' : '前往會員頁'}</button>
                      </p>
                    )}
                    <div className="flex gap-2 items-center">
                      <input value={checkoutAddressDraft.district ?? ''} onChange={e => setCheckoutAddressDraft({ ...checkoutAddressDraft, district: e.target.value })} className="flex-1 p-3 bg-slate-50 rounded-xl font-bold text-sm border border-slate-200" placeholder={lang === 'en' ? 'District' : '地區'} />
                      <button type="button" onClick={handleLocateMe} disabled={isLocatingAddress} className="flex-shrink-0 w-11 h-11 flex items-center justify-center bg-slate-50 border border-slate-200 rounded-xl text-slate-500 hover:bg-slate-100 disabled:opacity-50 transition-all">{isLocatingAddress ? <RefreshCw size={16} className="animate-spin text-blue-600" /> : <Crosshair size={18} />}</button>
                    </div>
                    <input ref={streetInputRef} value={checkoutAddressDraft.street ?? ''} onChange={e => setCheckoutAddressDraft({ ...checkoutAddressDraft, street: e.target.value })} className="w-full p-3 bg-slate-50 rounded-xl font-bold text-sm border border-slate-200" placeholder={lang === 'en' ? 'Street' : '街道／門牌'} autoComplete="off" />
                    <input value={checkoutAddressDraft.building ?? ''} onChange={e => setCheckoutAddressDraft({ ...checkoutAddressDraft, building: e.target.value })} className="w-full p-3 bg-slate-50 rounded-xl font-bold text-sm border border-slate-200" placeholder={lang === 'en' ? 'Building' : '大廈名稱'} />
                    <div className="grid grid-cols-2 gap-2">
                      <input value={checkoutAddressDraft.floor ?? ''} onChange={e => setCheckoutAddressDraft({ ...checkoutAddressDraft, floor: e.target.value })} className="w-full p-3 bg-slate-50 rounded-xl font-bold text-sm border border-slate-200" placeholder={lang === 'en' ? 'Floor' : '樓層'} />
                      <input value={checkoutAddressDraft.flat ?? ''} onChange={e => setCheckoutAddressDraft({ ...checkoutAddressDraft, flat: e.target.value })} className="w-full p-3 bg-slate-50 rounded-xl font-bold text-sm border border-slate-200" placeholder={lang === 'en' ? 'Unit' : '室／單位'} />
                    </div>
                    <input value={checkoutAddressDraft.contactName} onChange={e => setCheckoutAddressDraft({ ...checkoutAddressDraft, contactName: e.target.value })} className="w-full p-3 bg-slate-50 rounded-xl font-bold text-sm border border-slate-200" placeholder={lang === 'en' ? 'Contact name *' : '聯絡人姓名 *'} />
                    <input type="tel" value={checkoutAddressDraft.phone} onChange={e => setCheckoutAddressDraft({ ...checkoutAddressDraft, phone: e.target.value })} className="w-full p-3 bg-slate-50 rounded-xl font-bold text-sm border border-slate-200" placeholder={lang === 'en' ? 'Phone *' : '聯絡電話 *'} />
                    {user && (<label className="flex items-center gap-2.5 cursor-pointer"><input type="checkbox" checked={checkoutSaveNewAddressAsDefault} onChange={e => setCheckoutSaveNewAddressAsDefault(e.target.checked)} className="w-4 h-4 rounded border-slate-300 text-blue-600" /><span className="text-[11px] font-bold text-slate-500">{lang === 'en' ? 'Set as default' : '設為預設地址'}</span></label>)}
                    <div className="flex gap-2">
                      <button type="button" onClick={() => { setShowCheckoutAddressForm(false); setCheckoutAddressDraft(null); }} className="flex-1 py-3 bg-slate-100 rounded-xl font-black text-xs text-slate-500">{lang === 'en' ? 'Cancel' : '取消'}</button>
                      {user && (<button type="button" onClick={() => { if (!isAddressCompleteForOrder(checkoutAddressDraft)) { showToast(lang === 'en' ? 'Please fill required fields' : '請填寫聯絡人、電話及至少一項地址', 'error'); return; } handleSaveAddress(user.id, checkoutAddressDraft, true, checkoutSaveNewAddressAsDefault); setCheckoutSelectedAddressId(checkoutAddressDraft.id); setShowCheckoutAddressForm(false); setCheckoutAddressDraft(null); showToast(lang === 'en' ? 'Saved' : '已保存地址'); }} className="flex-1 py-3 bg-slate-900 text-white rounded-xl font-black text-xs">{lang === 'en' ? 'Save & Use' : '保存並使用'}</button>)}
                    </div>
                  </div>
                ) : user?.addresses && user.addresses.length > 0 ? (
                  <div className="space-y-2.5">
                    {(() => {
                      const addr = getCheckoutDeliveryAddress();
                      if (!addr) return null;
                      return (
                        <div className="p-3.5 bg-slate-50 rounded-xl">
                          <p className="text-[11px] text-slate-600 font-bold leading-relaxed">{formatAddressLine(addr)}</p>
                          <p className="text-[10px] text-slate-400 font-bold mt-0.5">{addr.contactName} · {addr.phone}</p>
                        </div>
                      );
                    })()}
                    <button type="button" onClick={() => { setIsChangingAddress(true); setCheckoutAddressDraft({ ...emptyAddress(), contactName: user?.name || '', phone: user?.phoneNumber || '' }); }} className="w-full py-3 bg-slate-100 rounded-xl text-slate-600 text-xs font-black flex items-center justify-center gap-1.5 hover:bg-slate-200 transition-colors">
                      <Edit size={13} /> {lang === 'en' ? 'Change address' : '更改地址'}
                    </button>
                  </div>
                ) : (
                  <button type="button" onClick={() => { setShowCheckoutAddressForm(true); setCheckoutAddressDraft({ ...emptyAddress(), contactName: user?.name || '', phone: user?.phoneNumber || '' }); }} className="w-full py-3.5 border-2 border-dashed border-slate-200 rounded-xl text-slate-400 text-xs font-black flex items-center justify-center gap-1.5">
                    <MapPin size={13} /> {lang === 'en' ? 'Enter delivery address' : '填寫收貨地址'}
                  </button>
                )}
              </div>
            )}
            </div>
          </section>

          {/* ─── Section 3: Order Items ─── */}
          <section className="bg-white rounded-2xl shadow-sm overflow-hidden">
            <div className="px-5 pt-5 pb-2">
              <p className="text-[11px] font-bold text-slate-400 uppercase tracking-widest">{lang === 'en' ? 'Items' : '商品明細'} · {cart.reduce((s, i) => s + i.qty, 0)}</p>
            </div>
            <div className="px-5 pb-4 divide-y divide-slate-100">
              {cart.map(item => (
                <div key={item.id} className="py-3 flex gap-3 items-center">
                  <div className="w-12 h-12 bg-slate-50 rounded-lg flex items-center justify-center flex-shrink-0 border border-slate-100 overflow-hidden">
                    {isMediaUrl(item.image) ? <img src={item.image} loading="lazy" alt="" className="w-full h-full object-cover" /> : <span className="text-xl">{item.image}</span>}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-slate-800 leading-tight">{item.name}</p>
                    <p className="text-[10px] text-slate-400 font-bold">${getPrice(item, item.qty)} x {item.qty}</p>
                  </div>
                  <div className="flex items-center gap-0.5 rounded-full border border-slate-200 p-0.5 bg-slate-50">
                    <button type="button" onClick={(e) => { e.stopPropagation(); updateCart(item, -1, e); }} className="w-7 h-7 flex items-center justify-center rounded-full text-slate-400 hover:bg-white active:scale-90 transition-all"><Minus size={12}/></button>
                    <span className="w-5 text-center text-[11px] font-black text-slate-900">{item.qty}</span>
                    <button type="button" onClick={(e) => { e.stopPropagation(); updateCart(item, 1, e); }} className="w-7 h-7 flex items-center justify-center rounded-full bg-slate-900 text-white active:scale-90 transition-all"><Plus size={12}/></button>
                  </div>
                  <p className="text-sm font-black text-slate-900 w-14 text-right">${getPrice(item, item.qty) * item.qty}</p>
                </div>
              ))}
            </div>
          </section>

          <UpsellNudge />

          {/* ─── Section 4: Coupon Selector ─── */}
          {user && (
            <section className="bg-white rounded-2xl shadow-sm overflow-hidden">
              <div className="px-5 pt-5 pb-4">
                <p className="text-[11px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5"><Ticket size={12} /> {t.coupon.selectCoupon}</p>
              </div>
              <div className="px-5 pb-5">
                {selectedCoupon ? (
                  <div className="flex items-center justify-between bg-emerald-50 border border-emerald-200 rounded-xl p-3">
                    <div className="flex items-center gap-2">
                      <Ticket size={16} className="text-emerald-600" />
                      <span className="text-xs font-black text-emerald-700">{selectedCoupon.coupon?.name}</span>
                      {selectedCoupon.coupon?.couponType === 'fixed_amount' && <span className="text-xs font-bold text-emerald-600">-${selectedCoupon.coupon.discountValue}</span>}
                      {selectedCoupon.coupon?.couponType === 'percentage' && <span className="text-xs font-bold text-emerald-600">-{selectedCoupon.coupon.discountValue}%</span>}
                      {selectedCoupon.coupon?.couponType === 'free_delivery' && <span className="text-xs font-bold text-emerald-600">{t.coupon.freeDelivery}</span>}
                      {selectedCoupon.coupon?.couponType === 'free_product' && <span className="text-xs font-bold text-emerald-600">{t.coupon.freeProduct}</span>}
                    </div>
                    <button onClick={() => { setSelectedCoupon(null); showToast(t.coupon.couponRemoved); }} className="p-1.5 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-rose-50"><X size={14}/></button>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {memberCoupons.filter(mc => {
                      if (mc.status !== 'available' || !mc.coupon) return false;
                      if (mc.expiresAt && new Date(mc.expiresAt) < new Date()) return false;
                      return subtotal >= (mc.coupon.minSpend || 0);
                    }).length === 0 ? (
                      <p className="text-xs text-slate-300 font-bold">{t.coupon.noCouponsAvailable}</p>
                    ) : (
                      memberCoupons.filter(mc => {
                        if (mc.status !== 'available' || !mc.coupon) return false;
                        if (mc.expiresAt && new Date(mc.expiresAt) < new Date()) return false;
                        return subtotal >= (mc.coupon.minSpend || 0);
                      }).map(mc => (
                        <button key={mc.id} onClick={() => { setSelectedCoupon(mc); showToast(t.coupon.couponApplied); }}
                          className="w-full flex items-center justify-between p-3 bg-slate-50 border border-slate-100 rounded-xl hover:border-blue-300 hover:bg-blue-50 transition-all">
                          <div className="flex items-center gap-2">
                            <Ticket size={14} className="text-blue-500" />
                            <span className="text-xs font-bold text-slate-700">{mc.coupon?.name}</span>
                          </div>
                          <span className="text-xs font-black text-blue-600">
                            {mc.coupon?.couponType === 'fixed_amount' && `-$${formatMoney(mc.coupon.discountValue)}`}
                            {mc.coupon?.couponType === 'percentage' && `-${mc.coupon.discountValue}%`}
                            {mc.coupon?.couponType === 'free_delivery' && t.coupon.freeDelivery}
                            {mc.coupon?.couponType === 'free_product' && t.coupon.freeProduct}
                          </span>
                        </button>
                      ))
                    )}
                  </div>
                )}
              </div>
            </section>
          )}

          {/* ─── Section 5: Summary & Pay ─── */}
          <section className="bg-white rounded-2xl shadow-sm overflow-hidden">
            <div className="px-5 pt-5 pb-5 space-y-3">
              <div className="flex justify-between text-xs font-bold text-slate-400"><span>{lang === 'en' ? 'Subtotal' : '商品小計'}</span><span className="text-slate-700">${formatMoney(subtotal)}</span></div>
              {pricingData.couponDiscount > 0 && (
                <div className="flex justify-between text-xs font-bold text-emerald-600"><span>{t.coupon.couponDiscount}</span><span>-${formatMoney(pricingData.couponDiscount)}</span></div>
              )}
              <div className="flex justify-between text-xs font-bold text-slate-400"><span>{lang === 'en' ? 'Shipping' : '運費'}</span><span className={deliveryFee === 0 ? 'text-emerald-600 font-black' : 'text-slate-700'}>{deliveryFee === 0 ? (lang === 'en' ? 'Free' : '免運費') : `$${formatMoney(deliveryFee)}`}</span></div>
              <FreeShippingNudge />
              <div className="pt-3 border-t border-slate-100 flex justify-between items-end">
                <span className="text-xs font-black text-slate-400 uppercase tracking-widest">{lang === 'en' ? 'Total' : '合計'}</span>
                <span className="text-2xl font-black text-slate-900">${formatMoney(total)}</span>
              </div>
            </div>
            <div className="px-5 pb-5">
              <button disabled={(deliveryMethod === 'home' && !getCheckoutDeliveryAddress()) || (deliveryMethod === 'sf_locker' && (!selectedLockerPoint || !(user?.phoneNumber ?? checkoutGuestPhone).trim())) || isRedirectingToPayment} onClick={handleSubmitOrder} className="w-full py-4 bg-blue-600 text-white rounded-xl font-black text-sm shadow-lg active:scale-[0.98] transition-all disabled:opacity-30 flex items-center justify-center gap-2">
                {isRedirectingToPayment ? <RefreshCw size={16} className="animate-spin" /> : <CreditCard size={16} />}
                {isRedirectingToPayment ? (lang === 'en' ? 'Processing...' : '處理中...') : (lang === 'en' ? `Pay $${formatMoney(total)}` : `前往付款 $${formatMoney(total)}`)}
              </button>
            </div>
          </section>
        </div>
      </div>
    );
  };

  const renderStoreView = () => (
    <div className="flex flex-col h-screen overflow-hidden bg-white animate-fade-in font-sans">
      <header className="bg-white/95 backdrop-blur-md sticky top-0 z-40 px-4 py-3 border-b border-slate-100 flex items-center justify-between">
        <div className="flex items-center gap-2"><div className={`w-9 h-9 ${isWholesaleRoute ? 'bg-orange-600' : 'bg-blue-600'} rounded-lg flex items-center justify-center text-white shadow-lg overflow-hidden`}>{isMediaUrl(siteConfig.logoUrl) ? <img src={siteConfig.logoUrl} alt={siteConfig.logoText} className="w-full h-full object-contain p-0.5" /> : <span>{siteConfig.logoIcon}</span>}</div><h1 className="font-bold text-lg text-slate-900 tracking-tight">{siteConfig.logoText}</h1>{isWholesaleRoute && <span className="px-2 py-0.5 bg-orange-100 text-orange-700 rounded-full text-[10px] font-black">批發</span>}</div>
        <div className="flex items-center gap-2">
          <button onClick={handleReorderClick} className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-50 text-amber-600 rounded-full border border-amber-100 active:scale-90 transition-transform"><Clock size={14} /><span className="text-xs font-bold">一鍵回購</span></button>
          <button onClick={() => setLang(lang === 'zh-HK' ? 'en' : 'zh-HK')} className="px-2.5 py-1.5 bg-slate-100 text-slate-600 rounded-full border border-slate-200 text-[10px] font-black uppercase tracking-wider hover:bg-slate-200 transition-colors">{lang === 'zh-HK' ? 'EN' : '中'}</button>
          <a href={`https://wa.me/${SHOP_WHATSAPP}`} target="_blank" rel="noreferrer" className="p-2 bg-green-50 text-green-600 rounded-full border border-green-100"><MessageCircle size={18} fill="currentColor" /></a>
          {user ? (
             <button onClick={() => setView('profile')} className="flex items-center gap-1.5 bg-slate-50 px-3 py-1.5 rounded-full border border-slate-100"><Star size={14} className={textAccentClass} /><span className="text-xs font-bold text-slate-700">{user.points} pts</span></button>
          ) : (
            <button onClick={() => setView('profile')} className={`text-xs font-bold ${textAccentClass} px-3 py-1.5 rounded-full bg-blue-50`}>{t.store.login}</button>
          )}
        </div>
      </header>
      {user && isWholesaleRoute && user.memberType === 'wholesale' && user.wholesaleStatus === 'pending' && (
        <div className="bg-orange-50 border-b border-orange-200 px-4 py-3">
          <div className="flex items-center gap-2">
            <Clock size={16} className="text-orange-500 flex-shrink-0" />
            <p className="text-xs font-bold text-orange-700">您的批發帳戶正在審核中，審核通過後即可下單。我們會在 1-2 個工作天內完成審核。</p>
          </div>
        </div>
      )}
      {user && isWholesaleRoute && user.memberType === 'wholesale' && user.wholesaleStatus === 'rejected' && (
        <div className="bg-red-50 border-b border-red-200 px-4 py-3">
          <div className="flex items-center gap-2">
            <X size={16} className="text-red-500 flex-shrink-0" />
            <p className="text-xs font-bold text-red-700">您的批發帳戶申請未獲批准，如有疑問請聯絡我們。</p>
          </div>
        </div>
      )}
      {hideWholesalePrice && (
        <div className="bg-amber-50 border-b border-amber-200 px-4 py-3">
          <div className="flex items-center justify-between gap-3">
            <p className="text-xs font-bold text-amber-700 flex-1">批發價格僅供已註冊客戶查看。登入或註冊以查看價格及下單。</p>
            <button onClick={() => setView('profile')} className="px-4 py-1.5 bg-amber-500 text-white rounded-full text-xs font-bold flex-shrink-0 active:scale-95 transition-all">登入 / 註冊</button>
          </div>
        </div>
      )}
      <div className="px-3 py-2 bg-white border-b border-slate-100">
        <div className="relative">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-300" />
          <input value={storeSearch} onChange={e => setStoreSearch(e.target.value)} placeholder={storeMode === 'recipes' ? '搜尋食譜 / 食材...' : '搜尋產品...'} className="w-full pl-9 pr-8 py-2.5 bg-slate-50 rounded-xl text-sm font-bold text-slate-800 border border-slate-100 focus:border-blue-300 focus:bg-white transition-all outline-none" />
          {storeSearch && <button onClick={() => setStoreSearch('')} className="absolute right-2.5 top-1/2 -translate-y-1/2 p-0.5 rounded-full bg-slate-200 text-slate-400 active:scale-90"><X size={12} /></button>}
        </div>
      </div>
      <div className="flex-1 flex overflow-hidden">
        <aside className="bg-white border-r border-slate-100 overflow-y-auto hide-scrollbar flex flex-col items-center py-1 w-16">
          {/* 食譜 tab - always first */}
          <button onClick={() => setStoreMode(prev => prev === 'recipes' ? 'shop' : 'recipes')} className={`flex flex-col items-center gap-0.5 w-full py-4 transition-all relative ${storeMode === 'recipes' ? 'text-amber-600 bg-amber-50/50' : 'text-slate-400'}`}>
            {storeMode === 'recipes' && <div className="absolute left-0 h-8 w-1 bg-amber-500 rounded-r-full" />}
            <span className="text-xl">📖</span><span className="text-[9px] font-bold text-center leading-tight">{t.recipes.recipes}</span>
          </button>
          <div className="w-10 border-t border-slate-100 my-0.5" />
          {categories.map(cat => (
            <button key={cat.id} onClick={() => { setStoreMode('shop'); scrollToCategory(cat.id); }} className={`flex flex-col items-center gap-0.5 w-full py-4 transition-all relative ${storeMode === 'shop' && activeCategory === cat.id ? `${textAccentClass} bg-blue-50/50` : 'text-slate-400'}`}>
              {storeMode === 'shop' && activeCategory === cat.id && <div className={`absolute left-0 h-8 w-1 ${accentClass} rounded-r-full`} />}
              <span className="text-xl">{cat.icon}</span><span className="text-[9px] font-bold text-center leading-tight uppercase">{cat.name}</span>
            </button>
          ))}
        </aside>
        <main ref={listRef} className="flex-1 overflow-y-auto hide-scrollbar bg-white p-3 pb-48">
          {storeMode === 'recipes' ? (
          /* ── 食譜列表視圖 ── */
          <div className="space-y-4">
            <div className="flex items-center gap-2 sticky top-0 bg-white py-2 z-10 border-b border-slate-50">
              <BookOpen size={16} className="text-amber-600" />
              <h3 className="font-bold text-slate-900 text-sm">{t.recipes.allRecipes}</h3>
              <span className="text-[10px] text-slate-400 font-bold">({filteredStoreRecipes.length})</span>
            </div>
            {/* Filter bars – row 1: cooking methods, row 2: meat types */}
            {recipeCategories.length > 0 && (
              <div className="space-y-1.5">
                {/* Row 1: Cooking methods */}
                {recipeCategories.some(c => c.categoryType === 'method') && (
                  <div className="flex gap-1.5 overflow-x-auto hide-scrollbar pb-0.5">
                    {recipeCategories.filter(c => c.categoryType === 'method').map(cat => {
                      const isActive = recipeCategoryFilter.includes(cat.id);
                      return (
                        <button key={cat.id} onClick={() => setRecipeCategoryFilter(prev => isActive ? prev.filter(c => c !== cat.id) : [...prev, cat.id])} className={`px-3 py-1.5 rounded-full text-[10px] font-black border whitespace-nowrap transition-all flex items-center gap-1 ${isActive ? 'bg-amber-500 text-white border-amber-500 shadow-md' : 'bg-white text-slate-500 border-slate-200'}`}>
                          <span>{cat.icon}</span> {cat.name}
                        </button>
                      );
                    })}
                  </div>
                )}
                {/* Row 2: Meat types */}
                {recipeCategories.some(c => c.categoryType === 'meat') && (
                  <div className="flex gap-1.5 overflow-x-auto hide-scrollbar pb-1">
                    {recipeCategories.filter(c => c.categoryType === 'meat').map(cat => {
                      const isActive = recipeCategoryFilter.includes(cat.id);
                      return (
                        <button key={cat.id} onClick={() => setRecipeCategoryFilter(prev => isActive ? prev.filter(c => c !== cat.id) : [...prev, cat.id])} className={`px-3 py-1.5 rounded-full text-[10px] font-black border whitespace-nowrap transition-all flex items-center gap-1 ${isActive ? 'bg-rose-500 text-white border-rose-500 shadow-md' : 'bg-white text-slate-500 border-slate-200'}`}>
                          <span>{cat.icon}</span> {cat.name}
                        </button>
                      );
                    })}
                  </div>
                )}
                {/* Clear all filters button */}
                {recipeCategoryFilter.length > 0 && (
                  <button onClick={() => setRecipeCategoryFilter([])} className="flex items-center gap-1 text-[10px] font-bold text-slate-400 hover:text-slate-600 transition-colors py-0.5">
                    <X size={10} /> 清除篩選
                  </button>
                )}
              </div>
            )}
            {(() => {
              const filtered = filteredStoreRecipes;
              if (filtered.length === 0) return (
                <div className="bg-slate-50 border border-slate-100 rounded-3xl p-8 text-center text-slate-400 font-bold">{storeSearch.trim() ? '搜尋無結果' : recipeCategoryFilter.length > 0 ? '此分類暫無食譜' : t.recipes.noRecipes}</div>
              );
              return (
                <div className="space-y-3">
                  {filtered.map(r => (
                    <div key={r.id} onClick={() => setSelectedRecipe(r)} className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden hover:shadow-md transition-all cursor-pointer group">
                      <div className="flex gap-3 p-3">
                        <div className="w-24 h-24 bg-slate-50 rounded-xl overflow-hidden flex-shrink-0 border border-slate-100">
                          {r.mediaUrl && isMediaUrl(r.mediaUrl) ? (
                            r.mediaType === 'video' ? (
                              <div className="w-full h-full flex items-center justify-center bg-slate-200"><Play size={24} className="text-slate-400" /></div>
                            ) : (
                              <img src={r.mediaUrl} alt={r.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                            )
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-4xl">📖</div>
                          )}
                        </div>
                        <div className="flex-1 min-w-0 flex flex-col justify-between py-0.5">
                          <div>
                            <h4 className="font-bold text-slate-900 text-sm leading-tight group-hover:text-amber-600 transition-colors">{r.title}</h4>
                            {r.description && <p className="text-[11px] text-slate-400 font-medium line-clamp-2 mt-1">{r.description}</p>}
                          </div>
                          <div className="flex flex-wrap gap-1.5 mt-1.5">
                            {r.cookingTime > 0 && <span className="px-2 py-0.5 bg-amber-50 text-amber-600 rounded text-[9px] font-bold border border-amber-100"><Clock size={8} className="inline mr-0.5" />{r.cookingTime}{t.recipes.minutes}</span>}
                            {r.servingSize && <span className="px-2 py-0.5 bg-slate-50 text-slate-500 rounded text-[9px] font-bold border border-slate-100">{r.servingSize}</span>}
                            {r.categoryIds.slice(0, 2).map(cid => { const c = recipeCategories.find(x => x.id === cid); return c ? <span key={cid} className="px-2 py-0.5 bg-amber-50 text-amber-700 rounded text-[9px] font-bold border border-amber-100">{c.icon}</span> : null; })}
                            {r.linkedProductIds.length > 0 && <span className="px-2 py-0.5 bg-emerald-50 text-emerald-600 rounded text-[9px] font-bold border border-emerald-100"><ShoppingBag size={8} className="inline mr-0.5" />{r.linkedProductIds.length}</span>}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              );
            })()}
          </div>
          ) : (
          /* ── 原有商店視圖 ── */
          <div className="space-y-12">
            {/* Advertisement slideshow - above categories */}
            {slideshowItems.length > 0 && (
              <div className="rounded-2xl overflow-hidden shadow-lg border border-slate-100 bg-slate-100">
                <div className="relative aspect-[2.5/1] w-full">
                  {slideshowItems.map((slide, i) => (
                    <div
                      key={slide.id}
                      className={`absolute inset-0 transition-opacity duration-500 ${i === slideshowIndex ? 'opacity-100 z-10' : 'opacity-0 z-0'}`}
                    >
                      {slide.type === 'video' ? (
                        <video src={slide.url} className="w-full h-full object-cover" muted loop autoPlay playsInline />
                      ) : (
                        <img src={slide.url} alt={slide.title || ''} className="w-full h-full object-cover" />
                      )}
                      {slide.title && (
                        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-3">
                          <p className="text-white font-bold text-sm">{slide.title}</p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
                {slideshowItems.length > 1 && (
                  <div className="flex justify-center gap-1.5 py-2 bg-white/80">
                    {slideshowItems.map((_, i) => (
                      <button key={i} onClick={() => setSlideshowIndex(i)} className={`w-2 h-2 rounded-full transition-all ${i === slideshowIndex ? 'bg-slate-900 scale-125' : 'bg-slate-300'}`} aria-label={`Slide ${i + 1}`} />
                    ))}
                  </div>
                )}
              </div>
            )}
            {categories.length === 0 && (
              <div className="bg-slate-50 border border-slate-100 rounded-3xl p-8 text-center text-slate-400 font-bold">
                {t.store.noCategories}
              </div>
            )}
            {categories.map(cat => (
              <div key={cat.id} ref={el => { catRefs.current[cat.id] = el; }}>
                <h3 className="font-bold text-slate-900 flex items-center gap-2 mb-2 text-sm sticky top-[0px] bg-white py-2 z-10 border-b border-slate-50"><span className="text-lg">{cat.icon}</span> {cat.name}</h3>
                <div className="divide-y divide-slate-100 bg-white rounded-2xl overflow-hidden shadow-sm">
                  {filteredStoreProducts.filter(p => p.categories.includes(cat.id)).length === 0 && (
                    <div className="p-6 text-center text-slate-400 font-bold">{storeSearch ? '搜尋無結果' : t.store.noCategoryProducts}</div>
                  )}
                  {filteredStoreProducts.filter(p => p.categories.includes(cat.id)).map(p => {
                    const itemInCart = cart.find(i => i.id === p.id);
                    const qty = itemInCart?.qty || 0;
                    const isOfferMet = p.bulkDiscount && qty >= p.bulkDiscount.threshold;
                    const productRecipes = getRecipesForProduct(p.id);
                    const hasRecipes = productRecipes.length > 0;
                    const isExpanded = recipeProductExpanded === p.id;
                    return (
                      <div key={p.id} className="relative">
                        <div onClick={() => setSelectedProduct(p)} className="flex gap-4 py-4 px-3 hover:bg-slate-50 transition-all cursor-pointer group">
                          <div className="w-24 h-24 bg-slate-50 rounded-xl flex items-center justify-center text-5xl relative overflow-hidden flex-shrink-0 border border-slate-100 group-hover:shadow-inner transition-all">
                             {isMediaUrl(p.image) ? <img src={p.image} loading="lazy" className="w-full h-full object-cover" alt={p.imageAlt || pName(p)} /> : <span className="text-5xl">{p.image}</span>}
                             {hasRecipes && (
                               <button onClick={(e) => { e.stopPropagation(); setRecipeProductExpanded(prev => prev === p.id ? null : p.id); }} className="absolute bottom-1 right-1 w-7 h-7 bg-amber-500 rounded-full flex items-center justify-center text-white shadow-md active:scale-90 transition-transform z-10">
                                 <BookOpen size={13}/>
                               </button>
                             )}
                          </div>
                          <div className="flex-1 flex flex-col justify-between py-0.5 min-w-0">
                             <div className="flex justify-between items-start">
                                <div className="flex-1 min-w-0"><h4 className="font-bold text-slate-900 text-[15px] leading-tight group-hover:text-blue-600 transition-colors flex items-center gap-2">{pName(p)}</h4>
                                  {p.tags && p.tags.length > 0 && (<div className="flex flex-wrap gap-1 mt-1.5">{p.tags.map(tag => (<span key={tag} className="px-1.5 py-0.5 bg-blue-50 text-blue-600 border border-blue-100 rounded text-[9px] font-bold uppercase tracking-tight">{tag}</span>))}</div>)}
                                  {p.bulkDiscount && (<p className="text-[10px] font-black text-rose-500 uppercase tracking-tight mt-1 animate-pulse">{p.bulkDiscount.threshold}件+ 即減 {p.bulkDiscount.value}{p.bulkDiscount.type === 'percent' ? '%' : '元'}</p>)}
                                  {p.purchaseLimit && (<p className="text-[10px] font-black text-orange-500 mt-1">每單只限買 {p.purchaseLimit} 件</p>)}
                                </div>
                             </div>
                             <div className="flex items-end justify-between mt-2">
                                <div className="flex items-center gap-2">
                                  {hideWholesalePrice ? (
                                    <p className="text-xs font-bold text-amber-600">登入查看批發價</p>
                                  ) : (() => {
                                    const yourPrice = getPrice(p);
                                    const showOriginal = yourPrice < p.price;
                                    return (<>
                                      <p className={`text-base font-bold ${showOriginal ? 'text-slate-300 text-xs line-through' : 'text-slate-900'}`}>${formatMoney(p.price)}</p>
                                      {showOriginal && <p className="text-base font-bold text-rose-500 animate-fade-in">${formatMoney(yourPrice)}</p>}
                                    </>);
                                  })()}
                                </div>
                                {hideWholesalePrice ? (
                                  <button onClick={(e) => { e.stopPropagation(); setView('profile'); }} className="px-3 py-1.5 bg-amber-50 text-amber-600 rounded-full border border-amber-100 text-xs font-bold">登入</button>
                                ) : (
                                <div className={`flex items-center rounded-full p-1 border transition-all ${isOfferMet ? 'bg-amber-400 border-amber-500 scale-105 shadow-md ring-2 ring-amber-200' : 'bg-white border-slate-100 shadow-sm'}`}>
                                  {qty > 0 && (
                                    <><button onClick={(e) => updateCart(p, -1, e)} className={`w-8 h-8 flex items-center justify-center transition-colors active:scale-75 ${isOfferMet ? 'text-white' : 'text-slate-300'}`}><Minus size={16}/></button><span className={`mx-2 text-sm font-black w-4 text-center ${isOfferMet ? 'text-white' : 'text-slate-900'}`}>{qty}</span></>
                                  )}
                                  <button onClick={(e) => updateCart(p, 1, e)} className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${isOfferMet ? 'bg-white text-amber-500' : accentClass + ' text-white shadow-lg'} active:scale-90 animate-pop-pulse`}><Plus size={16}/></button>
                                </div>
                                )}
                             </div>
                          </div>
                        </div>
                        {/* Expandable recipe panel */}
                        {hasRecipes && isExpanded && (
                          <div className="px-3 pb-3 animate-fade-in">
                            <div className="bg-amber-50/80 rounded-xl border border-amber-100/60 p-3 space-y-2">
                              <p className="text-[9px] font-black text-amber-600 uppercase tracking-widest flex items-center gap-1"><BookOpen size={10} /> {t.recipes.recommendedRecipes}</p>
                              {productRecipes.map(r => (
                                <button key={r.id} onClick={() => setSelectedRecipe(r)} className="w-full flex items-center gap-2.5 p-2 bg-white rounded-lg border border-amber-100/50 hover:bg-amber-50 transition-all text-left">
                                  {r.mediaUrl && isMediaUrl(r.mediaUrl) ? (
                                    <img src={r.mediaUrl} alt={r.title} className="w-9 h-9 rounded-lg object-cover flex-shrink-0" />
                                  ) : (
                                    <div className="w-9 h-9 bg-amber-100 rounded-lg flex items-center justify-center flex-shrink-0"><BookOpen size={14} className="text-amber-500" /></div>
                                  )}
                                  <div className="min-w-0 flex-1">
                                    <p className="text-xs font-bold text-slate-800 truncate">{r.title}</p>
                                    <div className="flex gap-1 mt-0.5">
                                      {r.cookingTime > 0 && <span className="text-[8px] text-amber-600 font-bold"><Clock size={7} className="inline" /> {r.cookingTime}{t.recipes.minutes}</span>}
                                    </div>
                                  </div>
                                  <ChevronRight size={12} className="text-slate-300 flex-shrink-0" />
                                </button>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
          )}
        </main>
      </div>
      {cart.length > 0 && !hideWholesalePrice && (
        <div className="fixed bottom-20 inset-x-4 z-[60]">
          <button onClick={(e) => { e.stopPropagation(); setView('checkout'); }} className="w-full bg-slate-900 text-white rounded-2xl shadow-2xl active:scale-[0.98] transition-all ring-4 ring-white/10 overflow-hidden">
            <div className="flex items-center justify-between px-5 py-3">
              <div className="flex items-center gap-3"><ShoppingBag size={18} /><span className="text-sm font-bold">${formatMoney(pricingData.subtotal)}</span></div>
              <div className="flex-1 mx-3"><FreeShippingNudge compact /></div>
              <div className="px-3 py-1.5 bg-white/10 rounded-lg flex items-center gap-1 font-bold text-[10px] uppercase tracking-wider text-white flex-shrink-0">{t.store.goCheckout} <ChevronRight size={12} /></div>
            </div>
          </button>
        </div>
      )}
    </div>
  );

  // ── Setup route: only accessible when no admin exists ──
  if (isSetupRoute) {
    return (
      <Suspense fallback={<div className="min-h-screen bg-slate-50 flex items-center justify-center"><div className="animate-spin w-8 h-8 border-4 border-slate-200 border-t-blue-600 rounded-full" /></div>}>
        <LazySetupPage />
      </Suspense>
    );
  }

  // ── Splash screen: shown while initial data loads ──
  if (isAppLoading && !isAdminRoute) {
    return (
      <div className="min-h-screen bg-white flex flex-col items-center justify-center gap-6">
        <div className="w-20 h-20 bg-blue-600 rounded-2xl flex items-center justify-center text-white shadow-2xl overflow-hidden">
          {isMediaUrl(siteConfig.logoUrl) ? <img src={siteConfig.logoUrl} alt="" className="w-full h-full object-contain p-2" /> : <span className="text-4xl">{siteConfig.logoIcon}</span>}
        </div>
        <h1 className="text-xl font-black text-slate-900 tracking-tight">{siteConfig.logoText}</h1>
        <div className="flex gap-1.5">
          <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce [animation-delay:-0.3s]" />
          <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce [animation-delay:-0.15s]" />
          <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" />
        </div>
      </div>
    );
  }

  if (isAdminRoute && !isAdminAuthenticated) return renderAdminLogin();

  // ── GH Foods domain: render dedicated wholesale storefront ──
  if (isGHFoods && !isAdminRoute) {
    return (
      <GHFoodsStorefront
        products={products}
        categories={categories}
        cart={cart}
        setCart={setCart}
        user={user}
        orders={orders.filter(o => (o.orderType || 'retail') === 'wholesale' && (user ? (o.memberId === user.id || o.customerName === user.name) : false))}
        ingredients={ingredients}
        costItems={costItems}
        wholesaleRules={siteConfig.wholesalePricingRules!}
        wholesalePriceOverrides={wholesalePriceOverrides}
        getPrice={(p, qty) => {
          const linkedIng = ingredients.find(i => i.id === p.ingredientId);
          return getWholesaleUnitPrice(p, linkedIng, costItems, siteConfig.wholesalePricingRules!, user?.wholesalePriceTier, wholesalePriceOverrides);
        }}
        onLogin={async (form) => {
          const input = form.email.trim();
          if (!input || !form.password) { showToast('請輸入電郵或電話及密碼', 'error'); return; }
          try {
            const res = await fetch('/api/customer-auth', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ action: 'login', identifier: input, password: form.password, isWholesale: true }),
            });
            const json = await res.json();
            if (!res.ok) { showToast(json.error || '登入失敗', 'error'); return; }
            const u = mapMemberRowToUser(json.user as SupabaseMemberRow);
            setUser(u);
            try {
              localStorage.setItem('coolfood_member_id', u.id);
              if (json.sessionToken) localStorage.setItem('coolfood_session_token', json.sessionToken);
              if (json.issuedAt) localStorage.setItem('coolfood_session_issued_at', String(json.issuedAt));
            } catch { /* ignore */ }
            showToast('歡迎回來！');
          } catch { showToast('登入失敗，請稍後再試', 'error'); }
        }}
        onRegister={async (form, files) => {
          if (!form.name.trim() || !form.phone.trim() || !form.password) { showToast('請填寫姓名、電話及密碼', 'error'); return; }
          if (form.password.length < 6) { showToast('密碼至少 6 個字元', 'error'); return; }
          if (!form.companyName.trim()) { showToast('請填寫餐廳/公司名稱', 'error'); return; }
          if (!files.brDoc) { showToast('請上傳商業登記證 (BR) 副本', 'error'); return; }
          if (!form.storefrontPreparing && !files.storefrontPhoto) { showToast('請上傳餐廳門口相片，或選擇「正在籌備中」', 'error'); return; }
          try {
            const timestamp = Date.now();
            const brDocUrl = await uploadImage(files.brDoc, `wholesale-registrations/${timestamp}/br-doc.webp`);
            let storefrontPhotoUrl: string | null = null;
            if (files.storefrontPhoto && !form.storefrontPreparing) {
              storefrontPhotoUrl = await uploadImage(files.storefrontPhoto, `wholesale-registrations/${timestamp}/storefront-photo.webp`);
            }
            const res = await fetch('/api/customer-auth', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                action: 'register',
                name: form.name.trim(),
                phone: form.phone.trim(),
                password: form.password,
                isWholesale: true,
                wholesaleBrand: 'GHFOODS',
                companyName: form.companyName.trim(),
                businessType: form.businessType || undefined,
                branchCount: form.branchCount,
                brDocUrl: brDocUrl || undefined,
                storefrontPhotoUrl: storefrontPhotoUrl || undefined,
                storefrontPreparing: form.storefrontPreparing || undefined,
              }),
            });
            const json = await res.json();
            if (!res.ok) { showToast(json.error || '註冊失敗', 'error'); return; }
            const u = mapMemberRowToUser(json.user as SupabaseMemberRow);
            setUser(u);
            try {
              localStorage.setItem('coolfood_member_id', u.id);
              if (json.sessionToken) localStorage.setItem('coolfood_session_token', json.sessionToken);
              if (json.issuedAt) localStorage.setItem('coolfood_session_issued_at', String(json.issuedAt));
            } catch { /* ignore */ }
            setMembers(prev => [...prev, u]);
            showToast('註冊申請已提交，我們會盡快審核！');
          } catch { showToast('註冊失敗，請稍後再試', 'error'); }
        }}
        onSubmitOrder={handleSubmitOrder}
        logoUrl={siteConfig.logoUrl}
        logoIcon={site.logoIcon}
        logoText={site.brandName}
        processingTypes={processingTypes}
        productGroups={productGroups}
        inventoryEnforcementEnabled={inventoryOn}
      />
    );
  }

  return (
    <div className={isAdminRoute ? "h-screen bg-slate-50 flex flex-row overflow-hidden font-sans" : "max-w-md mx-auto min-h-screen relative shadow-2xl overflow-hidden flex flex-col md:max-w-none bg-white font-sans"}>
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

      {/* ── 一鍵回購持久通知（手動關閉）── */}
      {reorderNotification && (
        <>
          {/* 點擊空白處關閉的透明遮罩 */}
          <div className="fixed inset-0 z-[8499]" onClick={() => setReorderNotification(null)} />
          <div className="fixed top-14 sm:top-16 inset-x-0 z-[8500] flex justify-center px-4 pointer-events-none">
            <div
              className={`pointer-events-auto w-full max-w-sm rounded-2xl shadow-xl border px-4 py-3 animate-slide-up ${
                reorderNotification.type === 'success'
                  ? 'bg-emerald-50 border-emerald-200'
                  : reorderNotification.type === 'partial'
                  ? 'bg-amber-50 border-amber-200'
                  : 'bg-rose-50 border-rose-200'
              }`}
            >
              <div className="flex items-start gap-2.5">
                <div className={`flex-shrink-0 mt-0.5 ${
                  reorderNotification.type === 'success' ? 'text-emerald-500' : reorderNotification.type === 'partial' ? 'text-amber-500' : 'text-rose-500'
                }`}>
                  {reorderNotification.type === 'success' ? <CheckCircle size={16}/> : reorderNotification.type === 'partial' ? <AlertTriangle size={16}/> : <AlertTriangle size={16}/>}
                </div>
                <div className="flex-1 min-w-0 space-y-0.5">
                  {reorderNotification.type === 'success' && (
                    <p className="text-xs font-bold text-emerald-700">已加入上次購買的 {reorderNotification.successCount} 件產品！您可以繼續選購。</p>
                  )}
                  {reorderNotification.type === 'partial' && (
                    <>
                      <p className="text-xs font-bold text-amber-700">已加入 {reorderNotification.successCount} 件，以下缺貨：</p>
                      <p className="text-[10px] text-amber-600/80 font-medium">{reorderNotification.failedNames.join('、')}</p>
                    </>
                  )}
                  {reorderNotification.type === 'fail' && (
                    <p className="text-xs font-bold text-rose-700">{reorderNotification.failedNames[0] || '上次買嘅產品已全數售罄'}</p>
                  )}
                </div>
                <button onClick={() => setReorderNotification(null)} className="flex-shrink-0 p-1 rounded-full hover:bg-black/5 active:scale-90 transition-all" aria-label="關閉">
                  <X size={14} className="text-slate-400" />
                </button>
              </div>
            </div>
          </div>
        </>
      )}
      
      {isAdminRoute ? (
        <WorkspaceProvider staffRole={(adminUser?.role as any) || 'super_admin'}>
          <AdminSidebar
            adminModule={adminModule}
            moduleWorkspace={moduleWorkspace}
            onNavigate={handleAdminModuleNav}
            adminUser={adminUser}
            isOpen={isAdminSidebarOpen}
            setIsOpen={setIsAdminSidebarOpen}
            hasAdminPermission={hasAdminPermission}
            onLogout={() => { setIsAdminAuthenticated(false); setAdminUser(null); try { localStorage.removeItem('coolfood_admin_session'); localStorage.removeItem('coolfood_admin_session_token'); localStorage.removeItem('coolfood_admin_issued_at'); } catch { /* ignore */ } window.location.hash = ''; }}
            onWorkspaceSwitch={handleWorkspaceSwitch}
            t={t}
          />
          <main className="flex-1 min-w-0 p-6 md:p-10 overflow-y-auto bg-[#f8fafc] hide-scrollbar">
            <AdminTopbar
              adminModule={adminModule}
              moduleWorkspace={moduleWorkspace}
              adminUser={adminUser}
              onWorkspaceSwitch={handleWorkspaceSwitch}
              onBrandChange={setAdminWholesaleBrand}
              showToast={showToast}
              t={t}
            />
            {mustChangePassword ? (
              <div className="flex items-center justify-center min-h-[60vh] animate-fade-in">
                <div className="bg-white rounded-[2.5rem] shadow-2xl border border-slate-100 w-full max-w-md p-10 space-y-6">
                  <div className="text-center space-y-2">
                    <div className="w-16 h-16 bg-amber-100 rounded-2xl flex items-center justify-center mx-auto text-3xl">🔐</div>
                    <h2 className="text-xl font-black text-slate-900">首次登入 — 請更改密碼</h2>
                    <p className="text-sm text-slate-500 font-bold">為保安全，您必須先設定新密碼才能使用後台功能</p>
                  </div>
                  <div className="space-y-4">
                    <div className="space-y-1">
                      <label className="text-[10px] font-black text-slate-400 uppercase">新密碼</label>
                      <input
                        type="password"
                        value={passwordChangeForm.newPassword}
                        onChange={e => setPasswordChangeForm(f => ({ ...f, newPassword: e.target.value }))}
                        placeholder="至少6個字元"
                        className="w-full p-4 bg-slate-50 rounded-2xl font-bold focus:ring-2 focus:ring-blue-100 border border-transparent transition-all"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-black text-slate-400 uppercase">確認新密碼</label>
                      <input
                        type="password"
                        value={passwordChangeForm.confirmPassword}
                        onChange={e => setPasswordChangeForm(f => ({ ...f, confirmPassword: e.target.value }))}
                        placeholder="再輸入一次新密碼"
                        className="w-full p-4 bg-slate-50 rounded-2xl font-bold focus:ring-2 focus:ring-blue-100 border border-transparent transition-all"
                      />
                    </div>
                  </div>
                  <button
                    onClick={handleForcePasswordChange}
                    className="w-full py-4 bg-blue-600 text-white rounded-2xl font-black text-sm shadow-xl active:scale-95 transition-all"
                  >
                    確認更改密碼
                  </button>
                </div>
              </div>
            ) : renderAdminModuleContent()}
          </main>
        </WorkspaceProvider>
      ) : (
        <>
          {view === 'store' && renderStoreView()}
          {view === 'checkout' && renderCheckoutView()}
          {view === 'success' && (
            <SuccessView
              successWaybill={successWaybill}
              successWaybillLoading={successWaybillLoading}
              setSuccessWaybill={setSuccessWaybill}
              setSuccessWaybillLoading={setSuccessWaybillLoading}
              highlightOrderId={highlightOrderId}
              orders={orders}
              onViewOrders={() => { if (window.history.replaceState) window.history.replaceState({}, '', '/'); setView('orders'); const latestId = orders.length > 0 ? orders[0].id : null; if (latestId) setHighlightOrderId(latestId); }}
              onRefreshOrders={fetchOrders}
            />
          )}
          {view === 'orders' && (() => {
            const myOrders = user
              ? orders.filter(o => o.memberId === user.id || (o.orderType || 'retail') === 'retail' && o.customerName === user.name)
              : [];
            return (
             <div className="flex-1 bg-slate-50 p-6 space-y-4 overflow-y-auto pb-24">
                <h2 className="text-2xl font-black text-slate-900 mb-6 tracking-tight">{t.orders.myOrders}</h2>
                {myOrders.length === 0 && (
                   <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm text-center text-slate-400 font-bold">
                      {t.orders.noOrders}
                   </div>
                )}
                {myOrders.map(o => (
                   <div
                     key={o.id}
                     className={`bg-white p-6 rounded-3xl border shadow-sm space-y-4 hover:shadow-md transition-all duration-300 ${highlightOrderId === o.id ? 'border-emerald-400 ring-2 ring-emerald-200 shadow-lg animate-order-pop' : 'border-slate-100'}`}
                   >
                      <div className="flex justify-between text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                        <span>#{o.id} • {o.date}</span>
                        <div className="flex items-center gap-2">
                          <StatusBadge status={o.status as OrderStatus} t={t} />
                          {!o.trackingNumber && ['shipping'].includes(o.status) && (
                            <span className="text-amber-600 px-2 py-0.5 bg-amber-50 rounded-md">{t.orders.noTracking}</span>
                          )}
                        </div>
                      </div>
                      <div className="flex justify-between items-center flex-wrap gap-2">
                        <p className="text-2xl font-black text-slate-900">${formatMoney(o.total)}</p>
                        <div className="flex items-center gap-2">
                          <button onClick={() => setInspectingOrder(o)} className="px-4 py-2.5 bg-slate-100 text-slate-700 rounded-xl text-[10px] font-black uppercase tracking-widest active:scale-95 transition-all border border-slate-200 hover:bg-slate-200">{t.orders.viewOrder}</button>
                          <button onClick={() => handleTrackOrder(o)} className={`px-4 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest active:scale-95 transition-all ${o.trackingNumber ? 'bg-slate-900 text-white' : 'bg-slate-200 text-slate-400 cursor-not-allowed'}`} disabled={!o.trackingNumber}><Truck size={14} className="inline mr-2"/> {t.orders.trackLogistics}</button>
                        </div>
                      </div>
                      <div className="flex flex-wrap items-center gap-3 text-xs font-bold text-slate-600">
                                                <span>{t.orders.courier}</span>
                                                <span>{t.orders.logisticsStatus}{getOrderStatusLabel(o.status, t)}</span>
                                                {o.trackingNumber && <span>{t.orders.trackingNo}{o.trackingNumber}</span>}
                      </div>
                      <div className="bg-slate-50 rounded-2xl p-3 border border-slate-100">
                        <div className="flex items-center justify-between text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                          <span>{t.orders.progress}</span>
                          <span>{getOrderStatusLabel(o.status, t)}</span>
                        </div>
                        <div className="mt-3 grid grid-cols-5 gap-2">
                          {ORDER_TIMELINE.map((step, idx) => {
                            const currentIdx = getTimelineIndex(o.status);
                            const isActive = currentIdx >= idx;
                            return (
                              <div key={step} className="flex flex-col items-center gap-2 text-[9px] font-bold text-slate-500">
                                <div className={`w-full h-1 rounded-full ${isActive ? 'bg-slate-900' : 'bg-slate-200'}`} />
                                <span className={`${isActive ? 'text-slate-700' : 'text-slate-400'}`}>{getOrderStatusLabel(step, t)}</span>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                   </div>
                ))}
             </div>
            );
          })()}
          {view === 'coupons' && (
            <div className="flex-1 bg-slate-50 p-6 overflow-y-auto pb-24 animate-fade-in">
              {!user ? (
                <div className="flex flex-col items-center justify-center gap-6 min-h-[60vh]">
                  <div className="w-24 h-24 bg-slate-100 rounded-full flex items-center justify-center"><Ticket size={40} className="text-slate-300" /></div>
                  <div className="text-center space-y-2">
                    <h2 className="text-xl font-black text-slate-800">{t.coupon.loginToView}</h2>
                  </div>
                  <button onClick={() => setView('profile')} className={`px-8 py-3 ${accentClass} text-white rounded-2xl font-black text-sm shadow-xl active:scale-95 transition-all`}>{t.coupon.loginNow}</button>
                </div>
              ) : (
                <div className="space-y-6">
                  <div className={`p-6 rounded-[2.5rem] ${accentClass} text-white shadow-xl`}>
                    <div className="flex items-center justify-between">
                      <div><h2 className="text-lg font-black">{user.name}</h2><p className="text-[10px] font-bold opacity-70 uppercase tracking-widest">{user.tier} MEMBER</p></div>
                      <div className="text-right"><p className="text-[9px] font-bold opacity-70 uppercase tracking-widest">{t.profile.points}</p><p className="text-2xl font-black">{user.points} pts</p></div>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <button onClick={() => setFrontendCouponTab('my')} className={`flex-1 py-3 rounded-2xl text-xs font-black transition-all ${frontendCouponTab === 'my' ? `${accentClass} text-white shadow-lg` : 'bg-white text-slate-400 border border-slate-200'}`}>{t.coupon.myCoupons}</button>
                    <button onClick={() => setFrontendCouponTab('shop')} className={`flex-1 py-3 rounded-2xl text-xs font-black transition-all ${frontendCouponTab === 'shop' ? `${accentClass} text-white shadow-lg` : 'bg-white text-slate-400 border border-slate-200'}`}>{t.coupon.pointsShop}</button>
                  </div>

                  {frontendCouponTab === 'my' && (
                    <div className="space-y-3">
                      {memberCoupons.length === 0 && (
                        <div className="text-center text-slate-400 font-bold py-10">{t.coupon.noCoupons}</div>
                      )}
                      {memberCoupons.filter(mc => mc.status === 'available').map(mc => {
                        const c = mc.coupon;
                        if (!c) return null;
                        const isExpired = mc.expiresAt && new Date(mc.expiresAt) < new Date();
                        if (isExpired) return null;
                        return (
                          <div key={mc.id} className="bg-white rounded-[2rem] border border-slate-100 shadow-sm overflow-hidden">
                            <div className="flex">
                              <div className={`w-24 flex-shrink-0 flex flex-col items-center justify-center ${accentClass} text-white p-4`}>
                                {c.couponType === 'fixed_amount' && <><p className="text-2xl font-black">${c.discountValue}</p><p className="text-[8px] font-bold uppercase">{t.coupon.off}</p></>}
                                {c.couponType === 'percentage' && <><p className="text-2xl font-black">{c.discountValue}%</p><p className="text-[8px] font-bold uppercase">{t.coupon.off}</p></>}
                                {c.couponType === 'free_delivery' && <><Truck size={28}/><p className="text-[8px] font-bold uppercase mt-1">{t.coupon.freeDelivery}</p></>}
                                {c.couponType === 'free_product' && <><Gift size={28}/><p className="text-[8px] font-bold uppercase mt-1">{t.coupon.freeProduct}</p></>}
                              </div>
                              <div className="flex-1 p-4">
                                <p className="font-black text-slate-900 text-sm">{c.name}</p>
                                {c.description && <p className="text-[11px] text-slate-400 font-bold mt-1">{c.description}</p>}
                                <div className="flex items-center gap-2 mt-2 flex-wrap">
                                  <span className="text-[9px] font-bold text-slate-300 bg-slate-50 px-2 py-0.5 rounded-full">{t.coupon.minSpend.replace('${min}', String(c.minSpend))}</span>
                                  {mc.expiresAt && <span className="text-[9px] font-bold text-slate-300 bg-slate-50 px-2 py-0.5 rounded-full">{t.coupon.expiresAt.replace('{date}', new Date(mc.expiresAt).toLocaleDateString())}</span>}
                                </div>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {frontendCouponTab === 'shop' && (
                    <div className="space-y-3">
                      {coupons.filter(c => c.isPointsShop && c.isActive && (c.pointsCost ?? 0) > 0).length === 0 && (
                        <div className="text-center text-slate-400 font-bold py-10">暫時沒有可兌換的優惠券</div>
                      )}
                      {coupons.filter(c => c.isPointsShop && c.isActive && (c.pointsCost ?? 0) > 0).map(c => {
                        const canAfford = user.points >= (c.pointsCost ?? 0);
                        const alreadyRedeemed = memberCoupons.some(mc => mc.couponId === c.id && mc.source === 'points_shop');
                        return (
                          <div key={c.id} className="bg-white rounded-[2rem] border border-slate-100 shadow-sm overflow-hidden">
                            <div className="flex">
                              <div className="w-24 flex-shrink-0 flex flex-col items-center justify-center bg-amber-500 text-white p-4">
                                <Star size={24}/>
                                <p className="text-sm font-black mt-1">{c.pointsCost}</p>
                                <p className="text-[8px] font-bold uppercase">pts</p>
                              </div>
                              <div className="flex-1 p-4">
                                <p className="font-black text-slate-900 text-sm">{c.name}</p>
                                {c.description && <p className="text-[11px] text-slate-400 font-bold mt-1">{c.description}</p>}
                                <div className="flex items-center gap-2 mt-2 flex-wrap">
                                  {c.couponType === 'fixed_amount' && <span className="text-[9px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">-${c.discountValue}</span>}
                                  {c.couponType === 'percentage' && <span className="text-[9px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">-{c.discountValue}%</span>}
                                  {c.couponType === 'free_delivery' && <span className="text-[9px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">{t.coupon.freeDelivery}</span>}
                                  {c.couponType === 'free_product' && <span className="text-[9px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">{t.coupon.freeProduct}</span>}
                                  <span className="text-[9px] font-bold text-slate-300 bg-slate-50 px-2 py-0.5 rounded-full">{t.coupon.minSpend.replace('${min}', String(c.minSpend))}</span>
                                </div>
                                <button
                                  disabled={!canAfford || alreadyRedeemed}
                                  onClick={async () => {
                                    if (!canAfford || alreadyRedeemed) return;
                                    if (!confirm(t.coupon.redeemConfirm.replace('{points}', String(c.pointsCost)))) return;
                                    try {
                                      const mId = localStorage.getItem('coolfood_member_id') || '';
                                      const sToken = localStorage.getItem('coolfood_session_token') || '';
                                      const res = await fetch('/api/coupon-api', {
                                        method: 'POST',
                                        headers: { 'Content-Type': 'application/json', 'x-member-id': mId, 'x-session-token': sToken },
                                        body: JSON.stringify({ action: 'redeem-points', couponId: c.id }),
                                      });
                                      const json = await res.json();
                                      if (res.ok && json.success) {
                                        setUser({ ...user, points: json.newPoints });
                                        showToast(t.coupon.redeemed);
                                      } else {
                                        showToast(json.error || 'Failed', 'error');
                                      }
                                    } catch { showToast('Error', 'error'); }
                                  }}
                                  className={`mt-3 w-full py-2.5 rounded-xl text-xs font-black transition-all ${
                                    alreadyRedeemed ? 'bg-slate-100 text-slate-300' :
                                    canAfford ? `${accentClass} text-white shadow-md active:scale-95` : 'bg-slate-100 text-slate-300'
                                  }`}
                                >
                                  {alreadyRedeemed ? '已兌換' : canAfford ? t.coupon.redeem : t.coupon.notEnoughPoints}
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
          {view === 'profile' && !user && (
             <div className="flex-1 bg-slate-50 p-6 overflow-y-auto pb-24 animate-fade-in">
                <div className="max-w-md mx-auto pt-4">
                  <h2 className="text-xl font-black text-slate-900 mb-6 tracking-tight">{t.profile.loginSignup}</h2>
                  <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden">
                    <div className="flex gap-0 border-b border-slate-100">
                                            <button type="button" onClick={() => setAuthMode('login')} className={`flex-1 py-4 font-bold text-sm ${authMode === 'login' ? 'text-blue-600 border-b-2 border-blue-600 bg-blue-50/30' : 'text-slate-400'}`}>{t.profile.loginTab}</button>
                                            <button type="button" onClick={() => setAuthMode('signup')} className={`flex-1 py-4 font-bold text-sm ${authMode === 'signup' ? 'text-blue-600 border-b-2 border-blue-600 bg-blue-50/30' : 'text-slate-400'}`}>{t.profile.signupTab}</button>
                    </div>
                    <div className="p-6 space-y-4">
                      {authMode === 'login' ? (
                        <form onSubmit={handleLogin} className="space-y-4">
                          <div>
                            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">{t.profile.emailOrPhone}</label>
                            <input type="text" value={authForm.email} onChange={e => setAuthForm({ ...authForm, email: e.target.value })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold border border-slate-100" placeholder={t.profile.emailOrPhone} required />
                          </div>
                          <div>
                            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">{t.profile.password}</label>
                            <input type="password" value={authForm.password} onChange={e => setAuthForm({ ...authForm, password: e.target.value })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold border border-slate-100" placeholder={t.profile.password} required />
                          </div>
                          <button type="submit" className="w-full py-3 bg-slate-900 text-white rounded-2xl font-black text-sm">{t.profile.loginBtn}</button>
                        </form>
                      ) : (
                        <form onSubmit={handleSignup} className="space-y-4">
                          <div>
                            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">{isWholesaleRoute ? '聯絡人姓名 *' : t.profile.name}</label>
                            <input value={authForm.name} onChange={e => setAuthForm({ ...authForm, name: e.target.value })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold border border-slate-100" placeholder={isWholesaleRoute ? '聯絡人姓名' : t.profile.name} required />
                          </div>
                          <div>
                            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">{t.profile.phone}</label>
                            <input type="tel" value={authForm.phone} onChange={e => setAuthForm({ ...authForm, phone: e.target.value })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold border border-slate-100" placeholder={t.profile.phone} required />
                          </div>
                          <div>
                            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">{t.profile.emailOptional}</label>
                            <input type="email" value={authForm.email} onChange={e => setAuthForm({ ...authForm, email: e.target.value })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold border border-slate-100" placeholder="your@email.com" />
                          </div>
                          <div>
                            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">{t.profile.passwordMin6}</label>
                            <input type="password" value={authForm.password} onChange={e => setAuthForm({ ...authForm, password: e.target.value })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold border border-slate-100" placeholder={t.profile.password} minLength={6} required />
                          </div>
                          {isWholesaleRoute && (
                            <>
                              <div className="pt-2 border-t border-slate-100">
                                <p className="text-[10px] font-black text-orange-500 uppercase tracking-widest mb-3">批發開戶資料</p>
                              </div>
                              <div>
                                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">餐廳 / 公司名稱 *</label>
                                <input value={authForm.companyName} onChange={e => setAuthForm({ ...authForm, companyName: e.target.value })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold border border-slate-100" placeholder="貴餐廳或公司名稱" required />
                              </div>
                              <div>
                                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">業務類型</label>
                                <select value={authForm.businessType} onChange={e => setAuthForm({ ...authForm, businessType: e.target.value })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold border border-slate-100">
                                  <option value="">請選擇</option>
                                  <option value="餐廳">餐廳</option>
                                  <option value="茶餐廳/冰室">茶餐廳 / 冰室</option>
                                  <option value="酒樓">酒樓</option>
                                  <option value="咖啡店/甜品店">咖啡店 / 甜品店</option>
                                  <option value="外賣店">外賣店</option>
                                  <option value="食品加工/中央廚房">食品加工 / 中央廚房</option>
                                  <option value="其他">其他</option>
                                </select>
                              </div>
                              <div>
                                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">分店數目</label>
                                <select value={authForm.branchCount} onChange={e => setAuthForm({ ...authForm, branchCount: e.target.value })} className="w-full p-3 bg-slate-50 rounded-2xl font-bold border border-slate-100">
                                  <option value="1">1 間</option>
                                  <option value="2-3">2–3 間</option>
                                  <option value="4-10">4–10 間</option>
                                  <option value="10+">10 間以上</option>
                                </select>
                              </div>
                              <div>
                                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">上傳商業登記證 (BR) 副本 *</label>
                                <label className={`flex items-center justify-center gap-2 w-full p-4 rounded-2xl border-2 border-dashed cursor-pointer transition-colors ${wholesaleRegFiles.brDoc ? 'border-emerald-300 bg-emerald-50' : 'border-slate-200 bg-slate-50 hover:border-orange-300'}`}>
                                  {wholesaleRegFiles.brDoc ? (
                                    <span className="text-xs font-bold text-emerald-600">✓ {wholesaleRegFiles.brDoc.name}</span>
                                  ) : (
                                    <span className="text-xs font-bold text-slate-400">點擊上傳 BR 圖片 / 相片</span>
                                  )}
                                  <input type="file" accept="image/*" className="hidden" onChange={e => { if (e.target.files?.[0]) setWholesaleRegFiles(prev => ({ ...prev, brDoc: e.target.files![0] })); }} />
                                </label>
                              </div>
                              <div>
                                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">門口 / 招牌相片 {authForm.storefrontPreparing ? '' : '*'}</label>
                                <p className="text-[9px] text-slate-400 mb-2">用於核實經營地址，請拍攝清晰的門口招牌相片</p>
                                {!authForm.storefrontPreparing && (
                                  <label className={`flex items-center justify-center gap-2 w-full p-4 rounded-2xl border-2 border-dashed cursor-pointer transition-colors ${wholesaleRegFiles.storefrontPhoto ? 'border-emerald-300 bg-emerald-50' : 'border-slate-200 bg-slate-50 hover:border-orange-300'}`}>
                                    {wholesaleRegFiles.storefrontPhoto ? (
                                      <span className="text-xs font-bold text-emerald-600">✓ {wholesaleRegFiles.storefrontPhoto.name}</span>
                                    ) : (
                                      <span className="text-xs font-bold text-slate-400">點擊上傳餐廳門口相片</span>
                                    )}
                                    <input type="file" accept="image/*" className="hidden" onChange={e => { if (e.target.files?.[0]) setWholesaleRegFiles(prev => ({ ...prev, storefrontPhoto: e.target.files![0] })); }} />
                                  </label>
                                )}
                                <label className="flex items-center gap-2 mt-2 cursor-pointer">
                                  <input type="checkbox" checked={authForm.storefrontPreparing} onChange={e => setAuthForm({ ...authForm, storefrontPreparing: e.target.checked })} className="w-4 h-4 rounded border-slate-300 text-orange-500 focus:ring-orange-400" />
                                  <span className="text-xs font-bold text-slate-500">正在籌備中（暫未有門口相片）</span>
                                </label>
                              </div>
                              <div className="bg-slate-50 rounded-xl p-3 space-y-1">
                                <p className="text-[9px] text-slate-500 text-center font-bold">送貨地址將按商業登記證上的地址安排，無需另外填寫。</p>
                                <p className="text-[9px] text-slate-400 text-center">提交後，我們會在 1-2 個工作天內審核您的申請，届時會以電話通知。</p>
                              </div>
                            </>
                          )}
                          <button type="submit" disabled={wholesaleRegUploading} className="w-full py-3 bg-slate-900 text-white rounded-2xl font-black text-sm disabled:opacity-50">
                            {wholesaleRegUploading ? '提交中...' : isWholesaleRoute ? '提交批發開戶申請' : t.profile.signupBtn}
                          </button>
                        </form>
                      )}
                    </div>
                  </div>
                  {!isWholesaleRoute && claimStep === 'idle' && (
                    <button
                      type="button"
                      onClick={() => { setClaimStep('email'); setClaimEmail(''); setClaimPhone(''); setClaimPassword(''); setClaimData(null); }}
                      className="flex items-center justify-center gap-2 mt-6 w-full px-5 py-3.5 bg-amber-50 border-2 border-amber-200 rounded-2xl text-sm font-bold text-amber-700 hover:bg-amber-100 hover:border-amber-300 transition-all shadow-sm"
                    >
                      <UserCheck size={16} /> 舊網站會員？按此啟用帳戶
                    </button>
                  )}
                  {claimStep !== 'idle' && claimStep !== 'success' && (
                    <div className="mt-6 bg-white rounded-[2.5rem] border-2 border-amber-200 shadow-sm overflow-hidden animate-fade-in">
                      <div className="bg-amber-50 px-6 py-4 border-b border-amber-100 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <UserCheck size={18} className="text-amber-600" />
                          <span className="font-black text-amber-800 text-sm">啟用舊網站帳戶</span>
                        </div>
                        <button type="button" onClick={() => { setClaimStep('idle'); setClaimData(null); }} className="text-amber-400 hover:text-amber-600 transition-colors">
                          <X size={18} />
                        </button>
                      </div>
                      <div className="p-6">
                        {claimStep === 'email' && (
                          <form onSubmit={handleClaimLookup} className="space-y-4">
                            <p className="text-xs text-slate-500 font-bold leading-relaxed">請輸入你在舊網站 (Shopline) 註冊的電郵地址，我們會查找你的會員記錄。</p>
                            <div>
                              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">舊網站電郵</label>
                              <input type="email" value={claimEmail} onChange={e => setClaimEmail(e.target.value)} className="w-full p-3 bg-slate-50 rounded-2xl font-bold border border-slate-100" placeholder="your@email.com" required />
                            </div>
                            <button type="submit" disabled={claimLoading} className="w-full py-3 bg-amber-500 text-white rounded-2xl font-black text-sm disabled:opacity-50 hover:bg-amber-600 transition-colors">
                              {claimLoading ? '查詢中...' : '查找我的帳戶'}
                            </button>
                          </form>
                        )}
                        {claimStep === 'confirm' && claimData && (
                          <div className="space-y-4">
                            <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 text-center">
                              <CheckCircle size={28} className="text-emerald-500 mx-auto mb-2" />
                              <p className="font-black text-emerald-800 text-sm">找到你的舊帳戶！</p>
                              <p className="text-lg font-black text-slate-900 mt-1">{claimData.name}</p>
                              {claimData.shoplineJoinDate && <p className="text-[10px] text-slate-400 mt-1">加入日期：{claimData.shoplineJoinDate.split(' ')[0]}</p>}
                              {claimData.shoplineOrders !== '0' && <p className="text-[10px] text-slate-400">過往訂單：{claimData.shoplineOrders} 單</p>}
                            </div>
                            <p className="text-xs text-slate-500 font-bold text-center">這是你嗎？請設定新的電話號碼和密碼以啟用帳戶。</p>
                            <form onSubmit={handleClaimSubmit} className="space-y-4">
                              <div>
                                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">手機號碼 *</label>
                                <input type="tel" value={claimPhone} onChange={e => setClaimPhone(e.target.value)} className="w-full p-3 bg-slate-50 rounded-2xl font-bold border border-slate-100" placeholder="例如：91234567" minLength={4} required />
                                {claimData.hasRealPhone && <p className="text-[9px] text-slate-400 mt-1">已自動填入你的舊電話，如需更改可直接修改</p>}
                              </div>
                              <div>
                                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">設定新密碼 *（至少 6 字）</label>
                                <input type="password" value={claimPassword} onChange={e => setClaimPassword(e.target.value)} className="w-full p-3 bg-slate-50 rounded-2xl font-bold border border-slate-100" placeholder="輸入新密碼" minLength={6} required />
                              </div>
                              <button type="submit" disabled={claimLoading} className="w-full py-3 bg-emerald-500 text-white rounded-2xl font-black text-sm disabled:opacity-50 hover:bg-emerald-600 transition-colors">
                                {claimLoading ? '啟用中...' : '啟用我的帳戶'}
                              </button>
                              <button type="button" onClick={() => { setClaimStep('email'); setClaimData(null); }} className="w-full py-2 text-slate-400 text-xs font-bold hover:text-slate-600 transition-colors">
                                不是我，重新查找
                              </button>
                            </form>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                  {claimStep === 'success' && (
                    <div className="mt-6 bg-emerald-50 border-2 border-emerald-200 rounded-[2.5rem] p-8 text-center animate-fade-in">
                      <CheckCircle size={48} className="text-emerald-500 mx-auto mb-3" />
                      <p className="font-black text-emerald-800 text-lg">帳戶啟用成功！</p>
                      <p className="text-sm text-emerald-600 mt-1">歡迎回來，正在跳轉...</p>
                    </div>
                  )}
                  {!isWholesaleRoute && claimStep === 'idle' && (
                    <a href="/wholesale" className="flex items-center justify-center gap-2 mt-4 px-5 py-3.5 bg-orange-50 border-2 border-orange-200 rounded-2xl text-sm font-bold text-orange-600 hover:bg-orange-100 hover:border-orange-300 transition-all shadow-sm">
                      <Store size={16} /> 餐廳/公司客戶？前往批發平台 →
                    </a>
                  )}
                </div>
             </div>
          )}
          {view === 'profile' && user && (
             <div className="flex-1 bg-slate-50 p-6 space-y-6 overflow-y-auto pb-24">
                <div className={`p-8 rounded-[3rem] ${accentClass} text-white shadow-2xl relative overflow-hidden group`}>
                   <div className="relative z-10"><h2 className="text-2xl font-black mb-2 tracking-tight">{user.name}</h2><p className="text-[10px] font-black uppercase tracking-[0.2em] opacity-60 mb-8">{user.tier} MEMBER</p>
                      <div className="grid grid-cols-1 gap-4">
                        <div className="bg-white/10 p-5 rounded-3xl border border-white/10 backdrop-blur-sm shadow-inner group-hover:bg-white/20 transition-colors"><p className="text-[9px] font-bold uppercase mb-1 tracking-widest">{t.profile.points}</p><p className="text-2xl font-black">{user.points} pts</p></div>
                      </div>
                   </div>
                   <div className="absolute -bottom-10 -right-10 opacity-10 group-hover:rotate-12 transition-transform duration-1000"><ShoppingBag size={200}/></div>
                </div>
                <div className="space-y-3">
                  {isWholesaleRoute ? (
                    <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden p-6 space-y-3">
                      <div className="flex items-center gap-3"><MapPin size={20} className="text-orange-500"/><span className="font-bold text-slate-700">送貨地址</span></div>
                      {user.deliveryAddress ? (
                        <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                          <p className="text-sm font-bold text-slate-800 leading-relaxed">{user.deliveryAddress}</p>
                        </div>
                      ) : (
                        <div className="p-4 bg-amber-50 rounded-2xl border border-amber-100">
                          <p className="text-xs font-bold text-amber-700">送貨地址尚未設定，我們會在審核後按 BR 地址安排。</p>
                        </div>
                      )}
                      <p className="text-[9px] text-slate-400 font-bold">如需更改送貨地址，請聯絡客服。</p>
                      {user.companyName && <div className="pt-2 border-t border-slate-100"><p className="text-[10px] text-slate-400 font-bold">公司：{user.companyName}</p></div>}
                    </div>
                  ) : (
                  <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden transition-all">
                    <button onClick={() => setShowAddressDropdown(!showAddressDropdown)} className="w-full flex justify-between items-center p-6 font-bold text-slate-700 hover:bg-slate-50 transition-colors">
                      <div className="flex items-center gap-3"><MapPin size={20} className="text-blue-500"/> {t.profile.addresses}</div>
                      <ChevronDown size={18} className={`text-slate-300 transition-transform duration-300 ${showAddressDropdown ? 'rotate-180' : ''}`}/>
                    </button>
                    {showAddressDropdown && (
                      <div className="p-4 bg-slate-50 border-t border-slate-100 space-y-4 animate-fade-in">
                        {user.addresses?.map(addr => (
                          <div key={addr.id} onClick={() => handleSetDefaultAddress(user.id, addr.id)} className={`p-5 rounded-[2rem] border transition-all cursor-pointer group relative ${addr.isDefault ? 'bg-white border-blue-400 shadow-lg ring-1 ring-blue-400' : 'bg-white border-slate-100 hover:border-blue-200'}`}>
                            <div className="flex justify-between items-start mb-2">
                              <div className="flex items-center gap-2"><span className="font-black text-slate-900 text-xs">{addr.isDefault ? '預設地址' : '其他地址'}</span>{addr.isDefault && <span className="px-2 py-0.5 bg-blue-600 text-white text-[8px] font-black uppercase rounded-full">{t.profile.default}</span>}</div>
                              <div className="flex items-center gap-1" onClick={e => e.stopPropagation()}>
                                <button type="button" onClick={() => setAddressEditor({ address: { ...addr }, isNew: false, ownerId: user.id })} className="p-2 rounded-xl text-slate-400 hover:bg-slate-100 hover:text-slate-600 transition-colors" aria-label="編輯"><Edit size={14}/></button>
                                <button type="button" onClick={() => handleDeleteAddress(user.id, addr.id)} className="p-2 rounded-xl text-slate-400 hover:bg-rose-50 hover:text-rose-500 transition-colors" aria-label="刪除"><Trash2 size={14}/></button>
                              </div>
                            </div>
                            <p className="text-[11px] text-slate-500 font-bold leading-relaxed mb-3 line-clamp-2">{formatAddressLine(addr)}</p>
                          </div>
                        ))}
                        <button onClick={() => setAddressEditor({ address: emptyAddress(), isNew: true, ownerId: user.id })} className="w-full py-4 border-2 border-dashed border-slate-200 rounded-[2rem] text-slate-300 font-black uppercase text-[10px] tracking-widest hover:border-blue-400 hover:text-blue-500 transition-all flex items-center justify-center gap-2"><Plus size={16}/> {t.profile.addAddress}</button>
                      </div>
                    )}
                  </div>
                  )}
                  {/* Admin access: navigate to yoursite.com/#admin */}
                </div>
                <button onClick={() => { setUser(null); try { localStorage.removeItem('coolfood_member_id'); localStorage.removeItem('coolfood_session_token'); localStorage.removeItem('coolfood_session_issued_at'); } catch { /* ignore */ } setView('store'); showToast(t.profile.loggedOut); }} className="w-full py-5 bg-white text-rose-500 rounded-[2rem] font-black border border-rose-50 shadow-sm active:scale-95 transition-all hover:bg-rose-50">{t.profile.logout}</button>
                {!isWholesaleRoute && (
                  <a href="/wholesale" className="flex items-center justify-center gap-2 mt-6 px-5 py-3.5 bg-orange-50 border-2 border-orange-200 rounded-2xl text-sm font-bold text-orange-600 hover:bg-orange-100 hover:border-orange-300 transition-all shadow-sm">
                    <Store size={16} /> 餐廳/公司客戶？前往批發平台 →
                  </a>
                )}
             </div>
          )}
          {!isAdminRoute && (
            <nav className="fixed bottom-0 inset-x-0 h-16 bg-white/95 backdrop-blur-xl border-t border-slate-100 flex items-center justify-around z-50">
              {[
                { id: 'store', label: t.nav.store, icon: <ShoppingBag size={22} strokeWidth={2.5} /> },
                { id: 'orders', label: t.nav.orders, icon: <Clock size={22} strokeWidth={2.5} /> },
                { id: 'coupons', label: t.nav.coupons, icon: <Ticket size={22} strokeWidth={2.5} /> },
                { id: 'profile', label: t.nav.profile, icon: <User size={22} strokeWidth={2.5} /> }
              ].map(item => (<button key={item.id} onClick={() => setView(item.id as any)} className={`flex flex-col items-center gap-1.5 transition-all duration-300 ${view === item.id ? `${textAccentClass} scale-110` : 'text-slate-300 hover:text-slate-400'}`}>{item.icon}<span className="text-[8px] font-black uppercase tracking-widest">{item.label}</span></button>))}
            </nav>
          )}
        </>
      )}
      {(aiRecipeLoading || aiDescLoading || isAnalyzing) && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-[9999] flex items-center justify-center" onClick={e => e.stopPropagation()}>
          <div className="bg-white rounded-3xl p-8 shadow-2xl flex flex-col items-center gap-4 max-w-sm mx-auto w-full">
            <div className="flex gap-2">
              <div className="w-3 h-3 bg-purple-400 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
              <div className="w-3 h-3 bg-purple-400 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
              <div className="w-3 h-3 bg-purple-400 rounded-full animate-bounce"></div>
            </div>
            {aiBatchProgress ? (
              <>
                <p className="text-sm font-black text-slate-700">{aiBatchProgress.label}</p>
                <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                  <div
                    className="bg-purple-500 h-full rounded-full transition-all duration-500"
                    style={{ width: `${Math.round((aiBatchProgress.current / aiBatchProgress.total) * 100)}%` }}
                  />
                </div>
                <p className="text-[10px] text-slate-400 font-bold text-center">Vertex AI (Paid) · 每個請求間隔 1 秒</p>
              </>
            ) : (
              <>
                <p className="text-sm font-black text-slate-700">AI 正在構思中...</p>
                <p className="text-[10px] text-slate-400 font-bold text-center">請稍候</p>
              </>
            )}
          </div>
        </div>
      )}
      {renderGlobalModals()}
    </div>
  );
};

const editingMember: any = null; // Placeholder for scope check if needed outside, though it's state-managed
export default App;
